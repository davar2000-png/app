import { useState } from 'react';
import { Customer, CustomerGroup, Document, Guarantor } from './types';
import { generateId, getTodayString } from './utils';
import SimpleImageUpload from './SimpleImageUpload';

interface CustomerFormProps {
  onAdd: (customer: Customer) => void;
  groups: CustomerGroup[];
}

export default function CustomerForm({ onAdd, groups }: CustomerFormProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [nationalId, setNationalId] = useState('');
  const [job, setJob] = useState('');
  const [employeeId, setEmployeeId] = useState('');
  const [bankCardNumber, setBankCardNumber] = useState('');
  const [groupId, setGroupId] = useState('');
  const [notes, setNotes] = useState('');
  const [image, setImage] = useState<string>('');

  // ضامن
  const [hasGuarantor, setHasGuarantor] = useState(false);
  const [guarantorName, setGuarantorName] = useState('');
  const [guarantorPhone, setGuarantorPhone] = useState('');
  const [guarantorAddress, setGuarantorAddress] = useState('');
  const [guarantorJob, setGuarantorJob] = useState('');
  const [guarantorNationalId, setGuarantorNationalId] = useState('');
  const [guarantorImage, setGuarantorImage] = useState<string>('');
  const [guarantorDocuments, setGuarantorDocuments] = useState<Document[]>([]);

  // مدارک
  const [documents, setDocuments] = useState<Document[]>([]);

  const handleImageChange = (newImage: string) => {
    setImage(newImage);
  };

  const handleDocumentUpload = (e: React.ChangeEvent<HTMLInputElement>, isGuarantor: boolean = false) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const doc: Document = {
          id: generateId(),
          name: file.name,
          type: file.type,
          data: ev.target?.result as string,
          date: getTodayString(),
        };
        if (isGuarantor) {
          setGuarantorDocuments(prev => [...prev, doc]);
        } else {
          setDocuments(prev => [...prev, doc]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removeDocument = (id: string, isGuarantor: boolean = false) => {
    if (isGuarantor) {
      setGuarantorDocuments(prev => prev.filter(d => d.id !== id));
    } else {
      setDocuments(prev => prev.filter(d => d.id !== id));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;

    // عیب‌یابی: بررسی تصویر
    console.log('📸 تصویر قبل از ذخیره:', {
      hasImage: !!image,
      imageLength: image?.length || 0,
      imagePreview: image?.substring(0, 50) + '...' || 'بدون تصویر'
    });

    let guarantor: Guarantor | undefined;
    if (hasGuarantor && guarantorName && guarantorPhone) {
      console.log('🛡️ ضامن قبل از ذخیره:', {
        hasGuarantor,
        guarantorName,
        guarantorPhone,
        hasImage: !!guarantorImage,
        imageLength: guarantorImage?.length || 0,
        documents: guarantorDocuments.length,
      });
      
      guarantor = {
        id: generateId(),
        name: guarantorName,
        phone: guarantorPhone,
        address: guarantorAddress,
        job: guarantorJob,
        nationalId: guarantorNationalId,
        image: guarantorImage,
        documents: guarantorDocuments,
      };
      
      console.log('✅ ضامن ذخیره شد:', {
        id: guarantor.id,
        name: guarantor.name,
        hasImage: !!guarantor.image,
        imageLength: guarantor.image?.length || 0,
      });
    }

    const customer: Customer = {
      id: generateId(),
      name,
      phone,
      address,
      nationalId,
      job,
      employeeId,
      bankCardNumber,
      image,
      documents,
      groupId: groupId || undefined,
      guarantor,
      notes,
      createdAt: getTodayString(),
    };

    onAdd(customer);
    resetForm();
    setIsOpen(false);
  };

  const resetForm = () => {
    setName('');
    setPhone('');
    setAddress('');
    setNationalId('');
    setJob('');
    setEmployeeId('');
    setBankCardNumber('');
    setGroupId('');
    setNotes('');
    setImage('');
    setDocuments([]);
    setHasGuarantor(false);
    setGuarantorName('');
    setGuarantorPhone('');
    setGuarantorAddress('');
    setGuarantorJob('');
    setGuarantorNationalId('');
    setGuarantorImage('');
    setGuarantorDocuments([]);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-2xl p-4 flex items-center justify-center gap-3 shadow-lg shadow-blue-500/20 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
      >
        <span className="text-2xl">👤</span>
        <span className="text-lg font-bold">افزودن شخص جدید</span>
      </button>
    );
  }

  return (
    <div className="bg-slate-800/80 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50 shadow-xl animate-fadeIn">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">ثبت شخص جدید</h3>
        <button
          onClick={() => { setIsOpen(false); resetForm(); }}
          className="text-slate-400 hover:text-white transition-colors w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-700"
        >
          ✕
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* تصویر و اطلاعات اصلی */}
        <div className="flex flex-col sm:flex-row gap-4">
          {/* آپلود تصویر */}
          <SimpleImageUpload 
            currentImage={image} 
            onImageChange={handleImageChange} 
          />

          {/* اطلاعات اصلی */}
          <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 text-sm mb-2">نام و نام خانوادگی *</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="مثلاً: علی احمدی"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
                required
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-2">شماره تماس *</label>
              <input
                type="tel"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
                required
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-2">کد ملی</label>
              <input
                type="text"
                value={nationalId}
                onChange={e => setNationalId(e.target.value)}
                placeholder="۰۰۱۲۳۴۵۶۷۸"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-2">شغل</label>
              <input
                type="text"
                value={job}
                onChange={e => setJob(e.target.value)}
                placeholder="مثلاً: مهندس"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-2">شماره کارمندی</label>
              <input
                type="text"
                value={employeeId}
                onChange={e => setEmployeeId(e.target.value)}
                placeholder="شماره کارمندی"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-2">شماره کارت بانکی</label>
              <input
                type="text"
                value={bankCardNumber}
                onChange={e => setBankCardNumber(e.target.value)}
                placeholder="۶۰۳۷-۹۹۱۸-..."
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
              />
            </div>
          </div>
        </div>

        {/* آدرس */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">آدرس</label>
          <textarea
            value={address}
            onChange={e => setAddress(e.target.value)}
            placeholder="آدرس کامل..."
            rows={2}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all resize-none"
          />
        </div>

        {/* گروه‌بندی */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">گروه</label>
          <select
            value={groupId}
            onChange={e => setGroupId(e.target.value)}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
          >
            <option value="">بدون گروه</option>
            {groups.map(g => (
              <option key={g.id} value={g.id}>{g.icon} {g.name}</option>
            ))}
          </select>
        </div>

        {/* مدارک */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">مدارک (قرارداد، کارت ملی، کارت کارمندی و...)</label>
          <div className="bg-slate-700/30 rounded-xl p-4">
            <label className="flex items-center justify-center gap-2 bg-slate-600/50 border border-dashed border-slate-500 rounded-xl p-3 cursor-pointer hover:bg-slate-600 transition-all">
              <span>📎</span>
              <span className="text-sm text-slate-300">انتخاب فایل‌ها</span>
              <input
                type="file"
                multiple
                accept="image/*,.pdf,.doc,.docx"
                onChange={e => handleDocumentUpload(e, false)}
                className="hidden"
              />
            </label>
            {documents.length > 0 && (
              <div className="mt-3 space-y-2">
                {documents.map(doc => (
                  <div key={doc.id} className="flex items-center justify-between bg-slate-700/50 rounded-lg p-2">
                    <div className="flex items-center gap-2">
                      <span>{doc.type.includes('image') ? '🖼️' : '📄'}</span>
                      <span className="text-sm text-slate-300 truncate max-w-[200px]">{doc.name}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeDocument(doc.id, false)}
                      className="text-rose-400 hover:text-rose-300 text-sm"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* دکمه ضامن */}
        <div className="border border-slate-600 rounded-xl overflow-hidden">
          <button
            type="button"
            onClick={() => setHasGuarantor(!hasGuarantor)}
            className={`w-full py-3 px-4 flex items-center justify-between transition-all ${
              hasGuarantor ? 'bg-amber-600/20 text-amber-400' : 'bg-slate-700/30 text-slate-300'
            }`}
          >
            <span className="flex items-center gap-2">
              <span>🛡️</span>
              <span className="font-medium">ضامن</span>
            </span>
            <span>{hasGuarantor ? '▼' : '◀'}</span>
          </button>

          {hasGuarantor && (
            <div className="p-4 space-y-3 bg-slate-700/20">
              {/* تصویر و اطلاعات ضامن */}
              <div className="flex flex-col sm:flex-row gap-4">
                <SimpleImageUpload 
                  currentImage={guarantorImage} 
                  onImageChange={setGuarantorImage} 
                />
                <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 text-sm mb-2">نام ضامن *</label>
                    <input
                      type="text"
                      value={guarantorName}
                      onChange={e => setGuarantorName(e.target.value)}
                      placeholder="نام و نام خانوادگی ضامن"
                      className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 text-sm mb-2">تلفن ضامن *</label>
                    <input
                      type="tel"
                      value={guarantorPhone}
                      onChange={e => setGuarantorPhone(e.target.value)}
                      placeholder="شماره تماس ضامن"
                      className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 text-sm mb-2">شغل ضامن</label>
                    <input
                      type="text"
                      value={guarantorJob}
                      onChange={e => setGuarantorJob(e.target.value)}
                      placeholder="شغل ضامن"
                      className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 text-sm mb-2">کد ملی ضامن</label>
                    <input
                      type="text"
                      value={guarantorNationalId}
                      onChange={e => setGuarantorNationalId(e.target.value)}
                      placeholder="کد ملی ضامن"
                      className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-all"
                    />
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-slate-300 text-sm mb-2">آدرس ضامن</label>
                <textarea
                  value={guarantorAddress}
                  onChange={e => setGuarantorAddress(e.target.value)}
                  placeholder="آدرس ضامن..."
                  rows={2}
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-all resize-none"
                />
              </div>
              {/* مدارک ضامن */}
              <div>
                <label className="block text-slate-300 text-sm mb-2">مدارک ضامن</label>
                <label className="flex items-center justify-center gap-2 bg-slate-600/50 border border-dashed border-amber-500/50 rounded-xl p-3 cursor-pointer hover:bg-slate-600 transition-all">
                  <span>📎</span>
                  <span className="text-sm text-slate-300">بارگذاری مدارک ضامن</span>
                  <input
                    type="file"
                    multiple
                    accept="image/*,.pdf,.doc,.docx"
                    onChange={e => handleDocumentUpload(e, true)}
                    className="hidden"
                  />
                </label>
                {guarantorDocuments.length > 0 && (
                  <div className="mt-3 space-y-2">
                    {guarantorDocuments.map(doc => (
                      <div key={doc.id} className="flex items-center justify-between bg-slate-700/50 rounded-lg p-2">
                        <div className="flex items-center gap-2">
                          <span>{doc.type.includes('image') ? '🖼️' : '📄'}</span>
                          <span className="text-sm text-slate-300 truncate max-w-[200px]">{doc.name}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeDocument(doc.id, true)}
                          className="text-rose-400 hover:text-rose-300 text-sm"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* یادداشت */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">یادداشت (اختیاری)</label>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            placeholder="توضیحات اضافی..."
            rows={2}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all resize-none"
          />
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-blue-600 to-indigo-700 py-3 rounded-xl font-bold text-white shadow-lg shadow-blue-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all"
        >
          ✓ ثبت شخص
        </button>
      </form>
    </div>
  );
}
