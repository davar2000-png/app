import { useState } from 'react';
import { Reminder, DailyNote } from './types';
import { generateId, getTodayString, formatDate } from './utils';

interface RemindersAndNotesProps {
  reminders: Reminder[];
  notes: DailyNote[];
  onAddReminder: (reminder: Reminder) => void;
  onUpdateReminder: (reminder: Reminder) => void;
  onDeleteReminder: (id: string) => void;
  onAddNote: (note: DailyNote) => void;
  onUpdateNote: (note: DailyNote) => void;
  onDeleteNote: (id: string) => void;
}

export default function RemindersAndNotes({
  reminders,
  notes,
  onAddReminder,
  onUpdateReminder,
  onDeleteReminder,
  onAddNote,
  onUpdateNote,
  onDeleteNote,
}: RemindersAndNotesProps) {
  const [showReminderForm, setShowReminderForm] = useState(false);
  const [showNoteForm, setShowNoteForm] = useState(false);
  
  // فرم یادآوری
  const [reminderTitle, setReminderTitle] = useState('');
  const [reminderDesc, setReminderDesc] = useState('');
  const [reminderDate, setReminderDate] = useState(getTodayString());
  const [reminderTime, setReminderTime] = useState('');
  const [reminderPriority, setReminderPriority] = useState<'low' | 'medium' | 'high'>('medium');
  
  // فرم یادداشت
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  
  // ویرایش
  const [editingReminder, setEditingReminder] = useState<string | null>(null);
  const [editingNote, setEditingNote] = useState<string | null>(null);

  const handleAddReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reminderTitle) return;

    const reminder: Reminder = {
      id: generateId(),
      title: reminderTitle,
      description: reminderDesc,
      date: reminderDate,
      time: reminderTime,
      priority: reminderPriority,
      isDone: false,
      createdAt: new Date().toISOString(),
    };

    onAddReminder(reminder);
    resetReminderForm();
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle || !noteContent) return;

    const note: DailyNote = {
      id: generateId(),
      title: noteTitle,
      content: noteContent,
      date: getTodayString(),
      createdAt: new Date().toISOString(),
    };

    onAddNote(note);
    resetNoteForm();
  };

  const resetReminderForm = () => {
    setReminderTitle('');
    setReminderDesc('');
    setReminderDate(getTodayString());
    setReminderTime('');
    setReminderPriority('medium');
    setShowReminderForm(false);
    setEditingReminder(null);
  };

  const resetNoteForm = () => {
    setNoteTitle('');
    setNoteContent('');
    setShowNoteForm(false);
    setEditingNote(null);
  };

  const handleEditReminder = (reminder: Reminder) => {
    setEditingReminder(reminder.id);
    setReminderTitle(reminder.title);
    setReminderDesc(reminder.description || '');
    setReminderDate(reminder.date);
    setReminderTime(reminder.time || '');
    setReminderPriority(reminder.priority);
    setShowReminderForm(true);
  };

  const handleUpdateReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reminderTitle || !editingReminder) return;

    const updated: Reminder = {
      id: editingReminder,
      title: reminderTitle,
      description: reminderDesc,
      date: reminderDate,
      time: reminderTime,
      priority: reminderPriority,
      isDone: reminders.find(r => r.id === editingReminder)?.isDone || false,
      createdAt: reminders.find(r => r.id === editingReminder)?.createdAt || new Date().toISOString(),
    };

    onUpdateReminder(updated);
    resetReminderForm();
  };

  const handleEditNote = (note: DailyNote) => {
    setEditingNote(note.id);
    setNoteTitle(note.title);
    setNoteContent(note.content);
    setShowNoteForm(true);
  };

  const handleUpdateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle || !noteContent || !editingNote) return;

    const updated: DailyNote = {
      id: editingNote,
      title: noteTitle,
      content: noteContent,
      date: notes.find(n => n.id === editingNote)?.date || getTodayString(),
      createdAt: notes.find(n => n.id === editingNote)?.createdAt || new Date().toISOString(),
    };

    onUpdateNote(updated);
    resetNoteForm();
  };

  const getPriorityColor = (priority: 'low' | 'medium' | 'high') => {
    switch (priority) {
      case 'high': return 'rose';
      case 'medium': return 'amber';
      case 'low': return 'emerald';
    }
  };

  const getPriorityLabel = (priority: 'low' | 'medium' | 'high') => {
    switch (priority) {
      case 'high': return 'فوری';
      case 'medium': return 'معمولی';
      case 'low': return 'کم';
    }
  };

  // مرتب‌سازی یادآوری‌ها: اول آنهایی که تمام نشده‌اند، بعد بر اساس تاریخ
  const sortedReminders = [...reminders].sort((a, b) => {
    if (a.isDone !== b.isDone) return a.isDone ? 1 : -1;
    return new Date(a.date).getTime() - new Date(b.date).getTime();
  });

  // مرتب‌سازی یادداشت‌ها بر اساس تاریخ
  const sortedNotes = [...notes].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* یادآوری‌ها */}
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            ⏰ یادآوری‌ها
            <span className="text-sm text-slate-400 font-normal">
              ({reminders.filter(r => !r.isDone).length} فعال)
            </span>
          </h3>
          <button
            onClick={() => { setShowReminderForm(!showReminderForm); if (showReminderForm) resetReminderForm(); }}
            className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700 transition-all"
          >
            {showReminderForm ? '✕ بستن' : '+ یادآوری جدید'}
          </button>
        </div>

        {/* فرم یادآوری */}
        {showReminderForm && (
          <form onSubmit={editingReminder ? handleUpdateReminder : handleAddReminder} className="mb-4 bg-slate-700/30 rounded-xl p-4 space-y-3 animate-fadeIn">
            <div>
              <label className="block text-slate-300 text-sm mb-1">عنوان *</label>
              <input
                type="text"
                value={reminderTitle}
                onChange={e => setReminderTitle(e.target.value)}
                placeholder="مثلاً: تماس با مشتری"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                required
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-1">توضیحات</label>
              <textarea
                value={reminderDesc}
                onChange={e => setReminderDesc(e.target.value)}
                placeholder="توضیحات بیشتر..."
                rows={2}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-300 text-sm mb-1">تاریخ</label>
                <input
                  type="date"
                  value={reminderDate}
                  onChange={e => setReminderDate(e.target.value)}
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-slate-300 text-sm mb-1">ساعت</label>
                <input
                  type="time"
                  value={reminderTime}
                  onChange={e => setReminderTime(e.target.value)}
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-1">اولویت</label>
              <div className="flex gap-2">
                {(['low', 'medium', 'high'] as const).map(p => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setReminderPriority(p)}
                    className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
                      reminderPriority === p
                        ? `bg-${getPriorityColor(p)}-600 text-white`
                        : 'bg-slate-700/50 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    {getPriorityLabel(p)}
                  </button>
                ))}
              </div>
            </div>
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-2 rounded-lg font-bold hover:bg-blue-700 transition-all"
            >
              {editingReminder ? '✓ ذخیره تغییرات' : '+ افزودن یادآوری'}
            </button>
          </form>
        )}

        {/* لیست یادآوری‌ها */}
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {sortedReminders.length === 0 ? (
            <p className="text-slate-500 text-center py-6 text-sm">هنوز یادآوری ثبت نشده</p>
          ) : (
            sortedReminders.map(reminder => {
              const isOverdue = !reminder.isDone && new Date(reminder.date) < new Date(getTodayString());
              return (
                <div
                  key={reminder.id}
                  className={`p-3 rounded-xl border transition-all ${
                    reminder.isDone
                      ? 'bg-slate-700/20 border-slate-600/50 opacity-60'
                      : isOverdue
                      ? 'bg-rose-500/10 border-rose-500/30'
                      : 'bg-slate-700/30 border-slate-600/50'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      checked={reminder.isDone}
                      onChange={() => onUpdateReminder({ ...reminder, isDone: !reminder.isDone })}
                      className="mt-1 w-5 h-5 rounded cursor-pointer"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`font-medium ${reminder.isDone ? 'line-through text-slate-400' : 'text-white'}`}>
                          {reminder.title}
                        </span>
                        <span className={`text-xs px-2 py-0.5 rounded-full bg-${getPriorityColor(reminder.priority)}-500/20 text-${getPriorityColor(reminder.priority)}-400`}>
                          {getPriorityLabel(reminder.priority)}
                        </span>
                        {isOverdue && (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400">
                            ⚠️ گذشته
                          </span>
                        )}
                      </div>
                      {reminder.description && (
                        <p className="text-slate-400 text-xs mt-1">{reminder.description}</p>
                      )}
                      <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                        <span>📅 {formatDate(reminder.date)}</span>
                        {reminder.time && <span>⏰ {reminder.time}</span>}
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <button
                        onClick={() => handleEditReminder(reminder)}
                        className="text-blue-400 hover:text-blue-300 text-sm"
                        title="ویرایش"
                      >
                        ✏️
                      </button>
                      <button
                        onClick={() => {
                          if (confirm('آیا از حذف این یادآوری مطمئن هستید؟')) {
                            onDeleteReminder(reminder.id);
                          }
                        }}
                        className="text-rose-400 hover:text-rose-300 text-sm"
                        title="حذف"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* یادداشت‌های روزانه */}
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            📝 یادداشت‌های روزانه
            <span className="text-sm text-slate-400 font-normal">({notes.length} یادداشت)</span>
          </h3>
          <button
            onClick={() => { setShowNoteForm(!showNoteForm); if (showNoteForm) resetNoteForm(); }}
            className="px-3 py-1.5 bg-violet-600 text-white rounded-lg text-sm hover:bg-violet-700 transition-all"
          >
            {showNoteForm ? '✕ بستن' : '+ یادداشت جدید'}
          </button>
        </div>

        {/* فرم یادداشت */}
        {showNoteForm && (
          <form onSubmit={editingNote ? handleUpdateNote : handleAddNote} className="mb-4 bg-slate-700/30 rounded-xl p-4 space-y-3 animate-fadeIn">
            <div>
              <label className="block text-slate-300 text-sm mb-1">عنوان *</label>
              <input
                type="text"
                value={noteTitle}
                onChange={e => setNoteTitle(e.target.value)}
                placeholder="مثلاً: نکات مهم جلسه"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-violet-500"
                required
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-1">متن یادداشت *</label>
              <textarea
                value={noteContent}
                onChange={e => setNoteContent(e.target.value)}
                placeholder="متن یادداشت را بنویسید..."
                rows={4}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-violet-500 resize-none"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-violet-600 text-white py-2 rounded-lg font-bold hover:bg-violet-700 transition-all"
            >
              {editingNote ? '✓ ذخیره تغییرات' : '+ افزودن یادداشت'}
            </button>
          </form>
        )}

        {/* لیست یادداشت‌ها */}
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {sortedNotes.length === 0 ? (
            <p className="text-slate-500 text-center py-6 text-sm">هنوز یادداشتی ثبت نشده</p>
          ) : (
            sortedNotes.map(note => (
              <div
                key={note.id}
                className="p-3 bg-slate-700/30 rounded-xl border border-slate-600/50 hover:bg-slate-700/40 transition-all"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <h4 className="text-white font-medium">{note.title}</h4>
                    <p className="text-slate-400 text-sm mt-1 whitespace-pre-wrap">{note.content}</p>
                    <p className="text-slate-500 text-xs mt-2">📅 {formatDate(note.date)}</p>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => handleEditNote(note)}
                      className="text-blue-400 hover:text-blue-300 text-sm"
                      title="ویرایش"
                    >
                      ✏️
                    </button>
                    <button
                      onClick={() => {
                        if (confirm('آیا از حذف این یادداشت مطمئن هستید؟')) {
                          onDeleteNote(note.id);
                        }
                      }}
                      className="text-rose-400 hover:text-rose-300 text-sm"
                      title="حذف"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
