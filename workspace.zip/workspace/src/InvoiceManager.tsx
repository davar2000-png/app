import { useState } from 'react';
import { Product, Customer, Invoice, InvoiceType } from './types';
import { formatNumber, formatJalaliDate, generateInvoiceNumber } from './utils';

interface InvoiceManagerProps {
  products: Product[];
  customers: Customer[];
  invoices: Invoice[];
  onSaveInvoice: (invoice: Invoice) => void;
  onDeleteInvoice: (id: string) => void;
}

export default function InvoiceManager({
  products,
  customers,
  invoices,
  onSaveInvoice,
  onDeleteInvoice,
}: InvoiceManagerProps) {
  const [showForm, setShowForm] = useState(false);
  const [selectedType, setSelectedType] = useState<InvoiceType>('sale');

  const invoiceTypes = [
    { id: 'sale' as InvoiceType, label: 'فاکتور فروش', icon: '💰', color: 'from-emerald-600 to-emerald-800' },
    { id: 'purchase' as InvoiceType, label: 'فاکتور خرید', icon: '🛒', color: 'from-blue-600 to-blue-800' },
    { id: 'return_sale' as InvoiceType, label: 'برگشت از فروش', icon: '↩️', color: 'from-rose-600 to-rose-800' },
    { id: 'return_purchase' as InvoiceType, label: 'برگشت از خرید', icon: '↩️', color: 'from-orange-600 to-orange-800' },
    { id: 'pre_invoice' as InvoiceType, label: 'پیش‌فاکتور', icon: '📋', color: 'from-violet-600 to-violet-800' },
  ];

  const stats = {
    totalSales: invoices.filter(inv => inv.type === 'sale').reduce((sum, inv) => sum + inv.total, 0),
    totalPurchases: invoices.filter(inv => inv.type === 'purchase').reduce((sum, inv) => sum + inv.total, 0),
    totalReturns: invoices.filter(inv => inv.type === 'return_sale' || inv.type === 'return_purchase').reduce((sum, inv) => sum + inv.total, 0),
    pendingInvoices: invoices.filter(inv => inv.status !== 'completed').length,
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* هدر */}
      <div className="bg-gradient-to-br from-blue-600 to-violet-600 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">📄 مدیریت فاکتورها</h2>
        <p className="text-blue-100">ثبت و مدیریت فاکتورهای خرید، فروش و برگشت</p>
      </div>

      {/* آمار */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-emerald-600 to-emerald-800 rounded-2xl p-5 text-white">
          <div className="flex items-center justify-between mb-2">
            <span className="text-emerald-200 text-sm">کل فروش</span>
            <span className="text-2xl">💰</span>
          </div>
          <p className="text-2xl font-bold">{formatNumber(stats.totalSales)}</p>
          <p className="text-emerald-200 text-xs mt-1">تومان</p>
        </div>

        <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl p-5 text-white">
          <div className="flex items-center justify-between mb-2">
            <span className="text-blue-200 text-sm">کل خرید</span>
            <span className="text-2xl">🛒</span>
          </div>
          <p className="text-2xl font-bold">{formatNumber(stats.totalPurchases)}</p>
          <p className="text-blue-200 text-xs mt-1">تومان</p>
        </div>

        <div className="bg-gradient-to-br from-rose-600 to-rose-800 rounded-2xl p-5 text-white">
          <div className="flex items-center justify-between mb-2">
            <span className="text-rose-200 text-sm">برگشت‌ها</span>
            <span className="text-2xl">↩️</span>
          </div>
          <p className="text-2xl font-bold">{formatNumber(stats.totalReturns)}</p>
          <p className="text-rose-200 text-xs mt-1">تومان</p>
        </div>

        <div className="bg-gradient-to-br from-amber-600 to-amber-800 rounded-2xl p-5 text-white">
          <div className="flex items-center justify-between mb-2">
            <span className="text-amber-200 text-sm">در انتظار</span>
            <span className="text-2xl">⏳</span>
          </div>
          <p className="text-2xl font-bold">{stats.pendingInvoices}</p>
          <p className="text-amber-200 text-xs mt-1">فاکتور</p>
        </div>
      </div>

      {/* انتخاب نوع فاکتور */}
      {!showForm && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {invoiceTypes.map(type => (
            <button
              key={type.id}
              onClick={() => {
                setSelectedType(type.id);
                setShowForm(true);
              }}
              className={`bg-gradient-to-br ${type.color} rounded-2xl p-6 text-white text-right hover:scale-105 transition-all shadow-lg`}
            >
              <div className="text-4xl mb-3">{type.icon}</div>
              <h3 className="text-xl font-bold mb-1">{type.label}</h3>
              <p className="text-sm opacity-80">ثبت فاکتور جدید</p>
            </button>
          ))}
        </div>
      )}

      {/* فرم فاکتور */}
      {showForm && (
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-white">
              {invoiceTypes.find(t => t.id === selectedType)?.icon}{' '}
              {invoiceTypes.find(t => t.id === selectedType)?.label}
            </h3>
            <button
              onClick={() => setShowForm(false)}
              className="text-slate-400 hover:text-white w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-700"
            >
              ✕
            </button>
          </div>

          <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
            <p className="text-blue-300 text-sm">
              💡 برای ثبت فاکتور، به تب "فروش" در منوی اصلی بروید و از فرم فاکتور استفاده کنید.
            </p>
            <p className="text-blue-200 text-xs mt-2">
              شماره فاکتور: {generateInvoiceNumber(selectedType)}
            </p>
          </div>

          <div className="mt-6 space-y-3">
            <h4 className="text-white font-bold">فاکتورهای اخیر:</h4>
            {invoices.filter(inv => inv.type === selectedType).length === 0 ? (
              <p className="text-slate-500 text-sm">هنوز فاکتوری ثبت نشده است</p>
            ) : (
              <div className="space-y-2">
                {invoices
                  .filter(inv => inv.type === selectedType)
                  .slice(0, 5)
                  .map(invoice => (
                    <div
                      key={invoice.id}
                      className="bg-slate-700/30 rounded-xl p-3 flex items-center justify-between"
                    >
                      <div>
                        <p className="text-white font-medium">{invoice.invoiceNumber}</p>
                        <p className="text-slate-400 text-sm">{invoice.personName}</p>
                      </div>
                      <div className="text-left">
                        <p className="text-emerald-400 font-bold">{formatNumber(invoice.total)}</p>
                        <p className="text-slate-500 text-xs">{formatJalaliDate(invoice.date)}</p>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* لیست فاکتورها */}
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-6">
        <h3 className="text-xl font-bold text-white mb-4">📋 همه فاکتورها</h3>
        {invoices.length === 0 ? (
          <p className="text-slate-500 text-center py-8">هنوز فاکتوری ثبت نشده است</p>
        ) : (
          <div className="space-y-3">
            {invoices.slice(0, 10).map(invoice => (
              <div
                key={invoice.id}
                className="bg-slate-700/30 rounded-xl p-4 flex items-center justify-between hover:bg-slate-700/50 transition-all"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl ${
                    invoice.type === 'sale' ? 'bg-emerald-500/20' :
                    invoice.type === 'purchase' ? 'bg-blue-500/20' :
                    'bg-rose-500/20'
                  }`}>
                    {invoice.type === 'sale' ? '💰' :
                     invoice.type === 'purchase' ? '🛒' : '↩️'}
                  </div>
                  <div>
                    <p className="text-white font-medium">{invoice.invoiceNumber}</p>
                    <p className="text-slate-400 text-sm">{invoice.personName}</p>
                    <p className="text-slate-500 text-xs">{formatJalaliDate(invoice.date)}</p>
                  </div>
                </div>
                <div className="text-left">
                  <p className="text-emerald-400 font-bold text-lg">{formatNumber(invoice.total)}</p>
                  <span className={`text-xs px-2 py-1 rounded-lg ${
                    invoice.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400' :
                    invoice.status === 'partial' ? 'bg-amber-500/20 text-amber-400' :
                    'bg-rose-500/20 text-rose-400'
                  }`}>
                    {invoice.status === 'completed' ? 'تسویه شده' :
                     invoice.status === 'partial' ? 'جزئی' : 'پرداخت نشده'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
