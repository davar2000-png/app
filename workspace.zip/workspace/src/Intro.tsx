export default function Intro() {
  return (
    <div className="space-y-6 animate-fadeIn">
      {/* هدر */}
      <div className="bg-gradient-to-br from-blue-600 to-violet-600 rounded-2xl p-8 text-white shadow-2xl">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center text-5xl backdrop-blur-sm">
            🏪
          </div>
          <div>
            <h1 className="text-3xl font-bold">حسابداری فروشگاه</h1>
            <p className="text-blue-100 mt-1">سیستم مدیریت جامع فروشگاه</p>
          </div>
        </div>
        <p className="text-blue-50 leading-relaxed">
          یک سیستم حسابداری کامل و حرفه‌ای برای مدیریت فروشگاه‌های خرید و فروش نقد و اقساط گوشی موبایل، لپ‌تاپ و کنسول بازی.
        </p>
      </div>

      {/* ویژگی‌های اصلی */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-3xl">📦</span>
            <h3 className="text-xl font-bold text-white">مدیریت کالا و انبار</h3>
          </div>
          <ul className="space-y-2 text-slate-300 text-sm">
            <li>✓ مدیریت گروه‌ها، برندها و مدل‌ها</li>
            <li>✓ کنترل موجودی و نقطه سفارش</li>
            <li>✓ شماره سریال و بارکد</li>
            <li>✓ گزارش کمبود کالا</li>
          </ul>
        </div>

        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-3xl">👥</span>
            <h3 className="text-xl font-bold text-white">مدیریت اشخاص</h3>
          </div>
          <ul className="space-y-2 text-slate-300 text-sm">
            <li>✓ اطلاعات کامل مشتریان</li>
            <li>✓ تصویر پروفایل و مدارک</li>
            <li>✓ مدیریت ضامن</li>
            <li>✓ گروه‌بندی و جستجو</li>
          </ul>
        </div>

        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-3xl">📄</span>
            <h3 className="text-xl font-bold text-white">سیستم فاکتور</h3>
          </div>
          <ul className="space-y-2 text-slate-300 text-sm">
            <li>✓ فاکتور خرید و فروش</li>
            <li>✓ برگشت از خرید و فروش</li>
            <li>✓ پیش‌فاکتور</li>
            <li>✓ کنترل هوشمند قیمت و موجودی</li>
          </ul>
        </div>

        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-3xl">💳</span>
            <h3 className="text-xl font-bold text-white">مدیریت مالی</h3>
          </div>
          <ul className="space-y-2 text-slate-300 text-sm">
            <li>✓ پرداخت نقد، کارت، چک، اقساط</li>
            <li>✓ مدیریت چک‌های دریافتی و پرداختی</li>
            <li>✓ سیستم اقساط با سررسید</li>
            <li>✓ تسویه حساب ترکیبی</li>
          </ul>
        </div>

        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-3xl">🤖</span>
            <h3 className="text-xl font-bold text-white">دستیار هوش مصنوعی</h3>
          </div>
          <ul className="space-y-2 text-slate-300 text-sm">
            <li>✓ تحلیل هوشمند فروش و خرید</li>
            <li>✓ گزارش‌گیری خودکار</li>
            <li>✓ تحلیل مشتریان و کالاها</li>
            <li>✓ هشدارهای هوشمند</li>
          </ul>
        </div>

        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-3xl">📊</span>
            <h3 className="text-xl font-bold text-white">گزارش‌ها و آمار</h3>
          </div>
          <ul className="space-y-2 text-slate-300 text-sm">
            <li>✓ داشبورد لحظه‌ای</li>
            <li>✓ گزارش روزانه، هفتگی، ماهانه</li>
            <li>✓ نمودارهای تحلیلی</li>
            <li>✓ کاردکس کالا و مشتری</li>
          </ul>
        </div>
      </div>

      {/* ویژگی‌های فنی */}
      <div className="bg-gradient-to-br from-emerald-900/30 to-teal-900/30 rounded-2xl p-6 border border-emerald-500/30">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <span>🔧</span>
          ویژگی‌های فنی
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-slate-800/60 rounded-xl p-4">
            <div className="text-3xl mb-2">🔒</div>
            <h4 className="text-white font-bold mb-1">آفلاین و امن</h4>
            <p className="text-slate-400 text-sm">
              تمام داده‌ها در مرورگر شما ذخیره می‌شوند و نیازی به اینترنت ندارند
            </p>
          </div>
          <div className="bg-slate-800/60 rounded-xl p-4">
            <div className="text-3xl mb-2">📱</div>
            <h4 className="text-white font-bold mb-1">ریسپانسیو</h4>
            <p className="text-slate-400 text-sm">
              در موبایل، تبلت و کامپیوتر به خوبی کار می‌کند
            </p>
          </div>
          <div className="bg-slate-800/60 rounded-xl p-4">
            <div className="text-3xl mb-2">🇮🇷</div>
            <h4 className="text-white font-bold mb-1">کاملاً فارسی</h4>
            <p className="text-slate-400 text-sm">
              تاریخ شمسی، اعداد فارسی و رابط کاربری راست‌چین
            </p>
          </div>
        </div>
      </div>

      {/* راهنمای شروع */}
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <span>🚀</span>
          شروع کار
        </h3>
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold shrink-0">
              1
            </div>
            <div>
              <p className="text-white font-medium">ثبت کالاها</p>
              <p className="text-slate-400 text-sm">ابتدا گروه‌ها، برندها و مدل‌ها را تعریف کنید</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold shrink-0">
              2
            </div>
            <div>
              <p className="text-white font-medium">ثبت اشخاص</p>
              <p className="text-slate-400 text-sm">مشتریان و فروشندگان را ثبت کنید</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold shrink-0">
              3
            </div>
            <div>
              <p className="text-white font-medium">ثبت فاکتور</p>
              <p className="text-slate-400 text-sm">فاکتورهای خرید و فروش را ثبت کنید</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold shrink-0">
              4
            </div>
            <div>
              <p className="text-white font-medium">مشاهده گزارش‌ها</p>
              <p className="text-slate-400 text-sm">از دستیار هوش مصنوعی برای تحلیل استفاده کنید</p>
            </div>
          </div>
        </div>
      </div>

      {/* اطلاعات نسخه */}
      <div className="text-center text-slate-500 text-sm py-4">
        <p>نسخه 2.0.0 | ساخته شده با ❤️ برای فروشگاه‌های ایرانی</p>
      </div>
    </div>
  );
}
