import { useState } from 'react';
import { Product, Customer, Invoice, InvoiceItem, Payment, InvoiceType } from './types';
import { generateId, getTodayString, formatNumber, formatJalaliDate, generateInvoiceNumber } from './utils';

interface PurchaseInvoiceFormProps {
  products: Product[];
  customers: Customer[];
  invoices: Invoice[];
  onSaveInvoice: (invoice: Invoice) => void;
  onUpdateProduct: (product: Product) => void;
}

export default function PurchaseInvoiceForm({
  products,
  customers,
  invoices,
  onSaveInvoice,
  onUpdateProduct,
}: PurchaseInvoiceFormProps) {
  const [invoiceNumber, setInvoiceNumber] = useState(generateInvoiceNumber('purchase'));
  const [date, setDate] = useState(getTodayString());
  const [supplierId, setSupplierId] = useState('');
  const [items, setItems] = useState<InvoiceItem[]>([]);
  const [discount, setDiscount] = useState(0);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [description, setDescription] = useState('');
  
  // اطلاعات اضافی
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [orderNumber, setOrderNumber] = useState('');
  const [siteImage, setSiteImage] = useState('');
  const [deliveryStatus, setDeliveryStatus] = useState<'pending' | 'received' | 'partial'>('pending');
  const [deliveryDate, setDeliveryDate] = useState('');
  const [deliveryNotes, setDeliveryNotes] = useState('');

  // فرم افزودن آیتم
  const [selectedProductId, setSelectedProductId] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [buyPrice, setBuyPrice] = useState('');
  const [itemDiscount, setItemDiscount] = useState(0);

  // فرم طرف حساب جدید
  const [showSupplierForm, setShowSupplierForm] = useState(false);
  const [newSupplierName, setNewSupplierName] = useState('');
  const [newSupplierPhone, setNewSupplierPhone] = useState('');
  const [newSupplierAddress, setNewSupplierAddress] = useState('');

  // ویرایش طرف حساب
  const [editingSupplier, setEditingSupplier] = useState<string | null>(null);
  const [editSupplierName, setEditSupplierName] = useState('');
  const [editSupplierPhone, setEditSupplierPhone] = useState('');
  const [editSupplierAddress, setEditSupplierAddress] = useState('');

  // ویرایش کالا
  const [editingItem, setEditingItem] = useState<string | null>(null);
  const [editItemQuantity, setEditItemQuantity] = useState(1);
  const [editItemPrice, setEditItemPrice] = useState('');
  const [editItemDiscount, setEditItemDiscount] = useState(0);

  // فرم تسویه
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'check' | 'transfer'>('cash');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentDescription, setPaymentDescription] = useState('');
  const [paymentDate, setPaymentDate] = useState(getTodayString());

  // آپلود تصویر سایت
  const handleSiteImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      alert('⚠️ حجم فایل خیلی زیاد است!');
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      setSiteImage(ev.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // افزودن طرف حساب جدید
  const handleAddSupplier = () => {
    if (!newSupplierName || !newSupplierPhone) return;
    const newCustomer: Customer = {
      id: generateId(),
      name: newSupplierName,
      phone: newSupplierPhone,
      address: newSupplierAddress,
      documents: [],
      createdAt: getTodayString(),
    };
    // ذخیره در localStorage
    const customers = JSON.parse(localStorage.getItem('store-customers') || '[]');
    customers.unshift(newCustomer);
    localStorage.setItem('store-customers', JSON.stringify(customers));
    setSupplierId(newCustomer.id);
    setShowSupplierForm(false);
    setNewSupplierName('');
    setNewSupplierPhone('');
    setNewSupplierAddress('');
  };

  // ویرایش طرف حساب
  const handleEditSupplier = (id: string) => {
    const customer = customers.find(c => c.id === id);
    if (!customer) return;
    setEditingSupplier(id);
    setEditSupplierName(customer.name);
    setEditSupplierPhone(customer.phone);
    setEditSupplierAddress(customer.address || '');
  };

  const handleSaveEditSupplier = () => {
    if (!editingSupplier || !editSupplierName) return;
    const customers = JSON.parse(localStorage.getItem('store-customers') || '[]');
    const updated = customers.map((c: Customer) => 
      c.id === editingSupplier ? { ...c, name: editSupplierName, phone: editSupplierPhone, address: editSupplierAddress } : c
    );
    localStorage.setItem('store-customers', JSON.stringify(updated));
    setEditingSupplier(null);
  };

  // حذف طرف حساب
  const handleDeleteSupplier = (id: string) => {
    if (!confirm('آیا از حذف این طرف حساب مطمئن هستید؟')) return;
    const customers = JSON.parse(localStorage.getItem('store-customers') || '[]');
    const updated = customers.filter((c: Customer) => c.id !== id);
    localStorage.setItem('store-customers', JSON.stringify(updated));
    if (supplierId === id) setSupplierId('');
  };

  // افزودن کالا
  const handleAddItem = () => {
    if (!selectedProductId || quantity <= 0) return;
    const product = products.find(p => p.id === selectedProductId);
    if (!product) return;

    const price = Number(buyPrice) || product.buyPrice;
    const total = (price * quantity) - itemDiscount;

    const item: InvoiceItem = {
      id: generateId(),
      productId: product.id,
      productName: product.name,
      quantity,
      buyPrice: price,
      sellPrice: product.sellPrice,
      discount: itemDiscount,
      total,
    };

    setItems([...items, item]);
    setSelectedProductId('');
    setQuantity(1);
    setBuyPrice('');
    setItemDiscount(0);
  };

  // ویرایش کالا
  const handleEditItem = (id: string) => {
    const item = items.find(i => i.id === id);
    if (!item) return;
    setEditingItem(id);
    setEditItemQuantity(item.quantity);
    setEditItemPrice(item.buyPrice.toString());
    setEditItemDiscount(item.discount);
  };

  const handleSaveEditItem = () => {
    if (!editingItem) return;
    setItems(items.map(item => {
      if (item.id === editingItem) {
        const newTotal = (Number(editItemPrice) * editItemQuantity) - editItemDiscount;
        return { ...item, quantity: editItemQuantity, buyPrice: Number(editItemPrice), discount: editItemDiscount, total: newTotal };
      }
      return item;
    }));
    setEditingItem(null);
  };

  // حذف کالا
  const handleRemoveItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  // افزودن تسویه
  const handleAddPayment = () => {
    if (!paymentAmount || Number(paymentAmount) <= 0) return;
    const payment: Payment = {
      id: generateId(),
      method: paymentMethod,
      amount: Number(paymentAmount),
      date: paymentDate,
      description: paymentDescription,
    };
    setPayments([...payments, payment]);
    setPaymentAmount('');
    setPaymentDescription('');
    setShowPaymentForm(false);
  };

  // حذف تسویه
  const handleRemovePayment = (id: string) => {
    setPayments(payments.filter(p => p.id !== id));
  };

  // محاسبات
  const subtotal = items.reduce((sum, item) => sum + item.total, 0);
  const total = subtotal - discount;
  const paidAmount = payments.reduce((sum, p) => sum + p.amount, 0);
  const remaining = total - paidAmount;

  // چاپ فاکتور
  const handlePrint = () => {
    const supplier = customers.find(c => c.id === supplierId);
    const printContent = `
      <!DOCTYPE html>
      <html dir="rtl" lang="fa">
      <head>
        <meta charset="UTF-8">
        <title>فاکتور خرید ${invoiceNumber}</title>
        <style>
          * { font-family: Tahoma, Arial, sans-serif; }
          body { padding: 20px; direction: rtl; }
          .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
          .info { display: flex; justify-content: space-between; margin-bottom: 20px; }
          .info-box { border: 1px solid #ccc; padding: 10px; border-radius: 5px; }
          table { width: 100%; border-collapse: collapse; margin: 20px 0; }
          th, td { border: 1px solid #ccc; padding: 8px; text-align: right; }
          th { background: #f0f0f0; }
          .total { text-align: left; font-weight: bold; font-size: 18px; }
          .footer { margin-top: 30px; border-top: 1px solid #ccc; padding-top: 10px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>فاکتور خرید</h1>
          <p>شماره: ${invoiceNumber}</p>
          <p>تاریخ: ${formatJalaliDate(date)}</p>
        </div>
        <div class="info">
          <div class="info-box">
            <strong>طرف حساب:</strong><br>
            ${supplier?.name || '-'}<br>
            تلفن: ${supplier?.phone || '-'}<br>
            آدرس: ${supplier?.address || '-'}
          </div>
          <div class="info-box">
            ${websiteUrl ? `<strong>سایت:</strong> ${websiteUrl}<br>` : ''}
            ${orderNumber ? `<strong>شماره سفارش:</strong> ${orderNumber}<br>` : ''}
            <strong>وضعیت دریافت:</strong> ${deliveryStatus === 'received' ? 'دریافت شده ✓' : deliveryStatus === 'partial' ? 'جزئی' : 'دریافت نشده'}
            ${deliveryDate ? `<br><strong>تاریخ دریافت:</strong> ${formatJalaliDate(deliveryDate)}` : ''}
          </div>
        </div>
        <table>
          <thead>
            <tr>
              <th>ردیف</th>
              <th>کالا</th>
              <th>تعداد</th>
              <th>قیمت خرید</th>
              <th>تخفیف</th>
              <th>جمع</th>
            </tr>
          </thead>
          <tbody>
            ${items.map((item, i) => `
              <tr>
                <td>${i + 1}</td>
                <td>${item.productName}</td>
                <td>${item.quantity}</td>
                <td>${Number(item.buyPrice).toLocaleString('fa-IR')}</td>
                <td>${Number(item.discount).toLocaleString('fa-IR')}</td>
                <td>${Number(item.total).toLocaleString('fa-IR')}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        <div class="total">
          <p>جمع کل: ${Number(subtotal).toLocaleString('fa-IR')} تومان</p>
          <p>تخفیف: ${Number(discount).toLocaleString('fa-IR')} تومان</p>
          <p>مبلغ نهایی: ${Number(total).toLocaleString('fa-IR')} تومان</p>
          <p>پرداخت شده: ${Number(paidAmount).toLocaleString('fa-IR')} تومان</p>
          <p>باقیمانده: ${Number(remaining).toLocaleString('fa-IR')} تومان</p>
        </div>
        ${description ? `<div class="footer"><strong>توضیحات:</strong> ${description}</div>` : ''}
        ${payments.length > 0 ? `
          <div class="footer">
            <strong>تسویه‌ها:</strong><br>
            ${payments.map(p => `
              • ${p.method === 'cash' ? 'نقدی' : p.method === 'check' ? 'چک' : 'حواله'}: ${Number(p.amount).toLocaleString('fa-IR')} تومان
              ${p.description ? ` - ${p.description}` : ''}
            `).join('<br>')}
          </div>
        ` : ''}
      </body>
      </html>
    `;
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  // ثبت فاکتور
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supplierId || items.length === 0) {
      alert('لطفاً طرف حساب و حداقل یک کالا انتخاب کنید');
      return;
    }

    const supplier = customers.find(c => c.id === supplierId);
    if (!supplier) return;

    const invoice: Invoice = {
      id: generateId(),
      invoiceNumber,
      type: 'purchase',
      date,
      personId: supplierId,
      personName: supplier.name,
      items,
      subtotal,
      discount,
      tax: 0,
      total,
      paid: paidAmount,
      remaining,
      payments,
      status: remaining === 0 ? 'completed' : paidAmount > 0 ? 'partial' : 'pending',
      description: `${description}${websiteUrl ? ` | سایت: ${websiteUrl}` : ''}${orderNumber ? ` | سفارش: ${orderNumber}` : ''}${deliveryNotes ? ` | دریافت: ${deliveryNotes}` : ''}`,
      createdAt: new Date().toISOString(),
    };

    onSaveInvoice(invoice);

    // به‌روزرسانی موجودی
    items.forEach(item => {
      const product = products.find(p => p.id === item.productId);
      if (product) {
        onUpdateProduct({
          ...product,
          stock: product.stock + item.quantity,
          buyPrice: item.buyPrice,
        });
      }
    });

    alert(`✅ فاکتور خرید ${invoiceNumber} با موفقیت ثبت شد!`);
  };

  const getPaymentMethodLabel = (method: string) => {
    switch (method) {
      case 'cash': return '💵 نقدی';
      case 'check': return '📝 چک';
      case 'transfer': return '🏦 حواله';
      default: return method;
    }
  };

  return (
    <div className="bg-slate-800/80 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50 shadow-xl">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
          🛒 فاکتور خرید - {invoiceNumber}
        </h3>
        <button
          onClick={handlePrint}
          className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm hover:bg-emerald-700 transition-all flex items-center gap-2"
        >
          <span>🖨️</span>
          <span>چاپ</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* اطلاعات اصلی */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-slate-300 text-sm mb-2">تاریخ</label>
            <input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500"
            />
            <p className="text-xs text-slate-400 mt-1">{formatJalaliDate(date)}</p>
          </div>
          <div>
            <label className="block text-slate-300 text-sm mb-2">شماره فاکتور (شماره سفارش خرید)</label>
            <input
              type="text"
              value={invoiceNumber}
              onChange={e => setInvoiceNumber(e.target.value)}
              placeholder="شماره سفارش خرید را وارد کنید"
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <p className="text-xs text-slate-400 mt-1">💡 می‌توانید شماره سفارش خرید را به عنوان شماره فاکتور وارد کنید</p>
          </div>
          <div>
            <label className="block text-slate-300 text-sm mb-2">وضعیت دریافت</label>
            <select
              value={deliveryStatus}
              onChange={e => setDeliveryStatus(e.target.value as any)}
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500"
            >
              <option value="pending">دریافت نشده</option>
              <option value="partial">دریافت جزئی</option>
              <option value="received">دریافت شده ✓</option>
            </select>
          </div>
        </div>

        {/* طرف حساب */}
        <div className="bg-slate-700/30 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-white font-bold flex items-center gap-2">
              👤 طرف حساب (فروشنده)
            </h4>
            <button
              type="button"
              onClick={() => setShowSupplierForm(!showSupplierForm)}
              className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700"
            >
              + طرف حساب جدید
            </button>
          </div>

          {/* فرم طرف حساب جدید */}
          {showSupplierForm && (
            <div className="bg-slate-700/50 rounded-xl p-4 mb-3 space-y-3 animate-fadeIn">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <input
                  type="text"
                  value={newSupplierName}
                  onChange={e => setNewSupplierName(e.target.value)}
                  placeholder="نام طرف حساب *"
                  className="bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
                <input
                  type="tel"
                  value={newSupplierPhone}
                  onChange={e => setNewSupplierPhone(e.target.value)}
                  placeholder="شماره تماس *"
                  className="bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
                <input
                  type="text"
                  value={newSupplierAddress}
                  onChange={e => setNewSupplierAddress(e.target.value)}
                  placeholder="آدرس"
                  className="bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleAddSupplier}
                  className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm hover:bg-emerald-700"
                >
                  ✓ ثبت
                </button>
                <button
                  type="button"
                  onClick={() => setShowSupplierForm(false)}
                  className="px-4 py-2 bg-slate-600 text-white rounded-lg text-sm hover:bg-slate-500"
                >
                  انصراف
                </button>
              </div>
            </div>
          )}

          {/* انتخاب طرف حساب */}
          <select
            value={supplierId}
            onChange={e => setSupplierId(e.target.value)}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500"
            required
          >
            <option value="">انتخاب طرف حساب...</option>
            {customers.map(c => (
              <option key={c.id} value={c.id}>{c.name} - {c.phone}</option>
            ))}
          </select>

          {/* دکمه‌های ویرایش و حذف */}
          {supplierId && (
            <div className="flex gap-2 mt-3">
              <button
                type="button"
                onClick={() => handleEditSupplier(supplierId)}
                className="px-3 py-1.5 bg-blue-600/20 text-blue-400 rounded-lg text-sm hover:bg-blue-600/30 flex items-center gap-1"
              >
                ✏️ ویرایش
              </button>
              <button
                type="button"
                onClick={() => handleDeleteSupplier(supplierId)}
                className="px-3 py-1.5 bg-rose-600/20 text-rose-400 rounded-lg text-sm hover:bg-rose-600/30 flex items-center gap-1"
              >
                🗑️ حذف
              </button>
            </div>
          )}

          {/* فرم ویرایش طرف حساب */}
          {editingSupplier && (
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4 mt-3 space-y-3 animate-fadeIn">
              <h5 className="text-blue-400 font-bold">ویرایش طرف حساب</h5>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <input
                  type="text"
                  value={editSupplierName}
                  onChange={e => setEditSupplierName(e.target.value)}
                  className="bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
                <input
                  type="tel"
                  value={editSupplierPhone}
                  onChange={e => setEditSupplierPhone(e.target.value)}
                  className="bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
                <input
                  type="text"
                  value={editSupplierAddress}
                  onChange={e => setEditSupplierAddress(e.target.value)}
                  className="bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleSaveEditSupplier}
                  className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm hover:bg-emerald-700"
                >
                  ✓ ذخیره
                </button>
                <button
                  type="button"
                  onClick={() => setEditingSupplier(null)}
                  className="px-4 py-2 bg-slate-600 text-white rounded-lg text-sm hover:bg-slate-500"
                >
                  انصراف
                </button>
              </div>
            </div>
          )}
        </div>

        {/* اطلاعات سایت و سفارش */}
        <div className="bg-slate-700/30 rounded-xl p-4">
          <h4 className="text-white font-bold mb-3">🌐 اطلاعات سفارش آنلاین</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 text-sm mb-2">آدرس سایت</label>
              <input
                type="url"
                value={websiteUrl}
                onChange={e => setWebsiteUrl(e.target.value)}
                placeholder="https://example.com"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-2">شماره سفارش</label>
              <input
                type="text"
                value={orderNumber}
                onChange={e => setOrderNumber(e.target.value)}
                placeholder="شماره سفارش سایت"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* تصویر خرید از سایت */}
          <div className="mt-3">
            <label className="block text-slate-300 text-sm mb-2">تصویر خرید از سایت</label>
            <div className="flex items-center gap-3">
              {siteImage ? (
                <div className="relative">
                  <img src={siteImage} alt="تصویر خرید" className="w-32 h-20 object-cover rounded-lg border-2 border-blue-500/30" />
                  <button
                    type="button"
                    onClick={() => setSiteImage('')}
                    className="absolute -top-2 -right-2 w-6 h-6 bg-rose-600 text-white rounded-full text-xs flex items-center justify-center"
                  >
                    ✕
                  </button>
                </div>
              ) : (
                <label className="w-32 h-20 bg-slate-700/50 border-2 border-dashed border-slate-600 rounded-lg flex items-center justify-center cursor-pointer hover:border-blue-500/50">
                  <span className="text-slate-400 text-sm">📷 آپلود</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleSiteImageUpload}
                    className="hidden"
                  />
                </label>
              )}
            </div>
          </div>

          {/* اطلاعات دریافت */}
          <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 text-sm mb-2">تاریخ دریافت کالا</label>
              <input
                type="date"
                value={deliveryDate}
                onChange={e => setDeliveryDate(e.target.value)}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-2">توضیحات دریافت</label>
              <input
                type="text"
                value={deliveryNotes}
                onChange={e => setDeliveryNotes(e.target.value)}
                placeholder="توضیحات دریافت کالا"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
        </div>

        {/* افزودن کالا */}
        <div className="bg-slate-700/30 rounded-xl p-4">
          <h4 className="text-white font-bold mb-3">➕ افزودن کالا</h4>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="md:col-span-2">
              <label className="block text-slate-300 text-xs mb-1">کالا</label>
              <select
                value={selectedProductId}
                onChange={e => {
                  setSelectedProductId(e.target.value);
                  const p = products.find(pr => pr.id === e.target.value);
                  if (p) setBuyPrice(p.buyPrice.toString());
                }}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
              >
                <option value="">انتخاب کالا...</option>
                {products.map(p => (
                  <option key={p.id} value={p.id}>{p.name} (موجودی: {p.stock})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-300 text-xs mb-1">تعداد</label>
              <input
                type="number"
                value={quantity}
                onChange={e => setQuantity(Number(e.target.value))}
                min="1"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 text-xs mb-1">قیمت خرید</label>
              <input
                type="number"
                value={buyPrice}
                onChange={e => setBuyPrice(e.target.value)}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
            <div>
              <label className="block text-slate-300 text-xs mb-1">تخفیف</label>
              <input
                type="number"
                value={itemDiscount}
                onChange={e => setItemDiscount(Number(e.target.value))}
                min="0"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
          <button
            type="button"
            onClick={handleAddItem}
            className="mt-3 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-all"
          >
            ➕ افزودن به فاکتور
          </button>
        </div>

        {/* لیست کالاها */}
        {items.length > 0 && (
          <div className="bg-slate-700/30 rounded-xl p-4">
            <h4 className="text-white font-bold mb-3">📋 اقلام فاکتور</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-700/50">
                  <tr>
                    <th className="px-3 py-2 text-right text-slate-300">کالا</th>
                    <th className="px-3 py-2 text-right text-slate-300">تعداد</th>
                    <th className="px-3 py-2 text-right text-slate-300">قیمت</th>
                    <th className="px-3 py-2 text-right text-slate-300">تخفیف</th>
                    <th className="px-3 py-2 text-right text-slate-300">جمع</th>
                    <th className="px-3 py-2 text-center text-slate-300">عملیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700/50">
                  {items.map(item => (
                    <tr key={item.id}>
                      {editingItem === item.id ? (
                        <>
                          <td className="px-3 py-2 text-white">{item.productName}</td>
                          <td className="px-3 py-2">
                            <input
                              type="number"
                              value={editItemQuantity}
                              onChange={e => setEditItemQuantity(Number(e.target.value))}
                              className="w-16 bg-slate-700/50 border border-slate-600 rounded px-2 py-1 text-white text-sm"
                            />
                          </td>
                          <td className="px-3 py-2">
                            <input
                              type="number"
                              value={editItemPrice}
                              onChange={e => setEditItemPrice(e.target.value)}
                              className="w-24 bg-slate-700/50 border border-slate-600 rounded px-2 py-1 text-white text-sm"
                            />
                          </td>
                          <td className="px-3 py-2">
                            <input
                              type="number"
                              value={editItemDiscount}
                              onChange={e => setEditItemDiscount(Number(e.target.value))}
                              className="w-20 bg-slate-700/50 border border-slate-600 rounded px-2 py-1 text-white text-sm"
                            />
                          </td>
                          <td className="px-3 py-2 text-emerald-400 font-bold">
                            {(Number(editItemPrice) * editItemQuantity - editItemDiscount).toLocaleString('fa-IR')}
                          </td>
                          <td className="px-3 py-2 text-center">
                            <div className="flex gap-1 justify-center">
                              <button
                                type="button"
                                onClick={handleSaveEditItem}
                                className="text-emerald-400 hover:text-emerald-300"
                              >
                                ✓
                              </button>
                              <button
                                type="button"
                                onClick={() => setEditingItem(null)}
                                className="text-slate-400 hover:text-slate-300"
                              >
                                ✕
                              </button>
                            </div>
                          </td>
                        </>
                      ) : (
                        <>
                          <td className="px-3 py-2 text-white">{item.productName}</td>
                          <td className="px-3 py-2 text-white">{item.quantity}</td>
                          <td className="px-3 py-2 text-white">{formatNumber(item.buyPrice)}</td>
                          <td className="px-3 py-2 text-white">{formatNumber(item.discount)}</td>
                          <td className="px-3 py-2 text-emerald-400 font-bold">{formatNumber(item.total)}</td>
                          <td className="px-3 py-2 text-center">
                            <div className="flex gap-1 justify-center">
                              <button
                                type="button"
                                onClick={() => handleEditItem(item.id)}
                                className="text-blue-400 hover:text-blue-300"
                              >
                                ✏️
                              </button>
                              <button
                                type="button"
                                onClick={() => handleRemoveItem(item.id)}
                                className="text-rose-400 hover:text-rose-300"
                              >
                                🗑️
                              </button>
                            </div>
                          </td>
                        </>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* محاسبات */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-slate-700/30 rounded-xl p-4 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">جمع کل:</span>
              <span className="text-white font-bold">{formatNumber(subtotal)} تومان</span>
            </div>
            <div>
              <label className="block text-slate-300 text-xs mb-1">تخفیف کل</label>
              <input
                type="number"
                value={discount}
                onChange={e => setDiscount(Number(e.target.value))}
                min="0"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>
            <div className="flex justify-between text-lg border-t border-slate-600 pt-3">
              <span className="text-white font-bold">مبلغ نهایی:</span>
              <span className="text-emerald-400 font-bold">{formatNumber(total)} تومان</span>
            </div>
          </div>

          <div className="bg-slate-700/30 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-white font-bold">💳 تسویه حساب</h4>
              <button
                type="button"
                onClick={() => setShowPaymentForm(!showPaymentForm)}
                className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700"
              >
                + افزودن
              </button>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">پرداخت شده:</span>
              <span className="text-emerald-400 font-bold">{formatNumber(paidAmount)} تومان</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">باقیمانده:</span>
              <span className={`font-bold ${remaining > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {formatNumber(remaining)} تومان
              </span>
            </div>

            {/* فرم تسویه */}
            {showPaymentForm && (
              <div className="bg-slate-700/50 rounded-xl p-3 space-y-2 animate-fadeIn">
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('cash')}
                    className={`py-2 rounded-lg text-sm ${paymentMethod === 'cash' ? 'bg-emerald-600 text-white' : 'bg-slate-600 text-slate-300'}`}
                  >
                    💵 نقدی
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('check')}
                    className={`py-2 rounded-lg text-sm ${paymentMethod === 'check' ? 'bg-violet-600 text-white' : 'bg-slate-600 text-slate-300'}`}
                  >
                    📝 چک
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('transfer')}
                    className={`py-2 rounded-lg text-sm ${paymentMethod === 'transfer' ? 'bg-blue-600 text-white' : 'bg-slate-600 text-slate-300'}`}
                  >
                    🏦 حواله
                  </button>
                </div>
                <input
                  type="number"
                  value={paymentAmount}
                  onChange={e => setPaymentAmount(e.target.value)}
                  placeholder="مبلغ"
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
                <input
                  type="text"
                  value={paymentDescription}
                  onChange={e => setPaymentDescription(e.target.value)}
                  placeholder="توضیحات (شماره چک، شماره حواله و...)"
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
                <button
                  type="button"
                  onClick={handleAddPayment}
                  className="w-full bg-emerald-600 text-white py-2 rounded-lg text-sm hover:bg-emerald-700"
                >
                  ✓ ثبت تسویه
                </button>
              </div>
            )}

            {/* لیست تسویه‌ها */}
            {payments.length > 0 && (
              <div className="space-y-2 mt-2">
                {payments.map(payment => (
                  <div key={payment.id} className="bg-slate-700/50 rounded-lg p-2 flex items-center justify-between">
                    <div>
                      <span className="text-white text-sm">{getPaymentMethodLabel(payment.method)}</span>
                      <span className="text-slate-400 text-xs mx-2">|</span>
                      <span className="text-emerald-400 font-bold text-sm">{formatNumber(payment.amount)}</span>
                      {payment.description && (
                        <p className="text-slate-400 text-xs mt-1">{payment.description}</p>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemovePayment(payment.id)}
                      className="text-rose-400 hover:text-rose-300 text-sm"
                    >
                      🗑️
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* توضیحات */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">توضیحات</label>
          <textarea
            value={description}
            onChange={e => setDescription(e.target.value)}
            rows={2}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none"
          />
        </div>

        {/* دکمه‌ها */}
        <div className="flex gap-3">
          <button
            type="submit"
            className="flex-1 bg-gradient-to-r from-blue-600 to-blue-800 py-3 rounded-xl font-bold text-white shadow-lg hover:scale-[1.02] active:scale-[0.98] transition-all"
          >
            ✓ ثبت فاکتور خرید
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="px-6 bg-emerald-600 text-white py-3 rounded-xl font-bold hover:bg-emerald-700 transition-all flex items-center gap-2"
          >
            <span>🖨️</span>
            <span>چاپ</span>
          </button>
        </div>
      </form>
    </div>
  );
}
