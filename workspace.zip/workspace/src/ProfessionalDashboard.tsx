import { Product, Customer, Invoice, Check, InstallmentPlan } from './types';
import { formatNumber, formatJalaliDate, isOverdue, daysUntilDue } from './utils';

interface ProfessionalDashboardProps {
  products: Product[];
  customers: Customer[];
  invoices: Invoice[];
  checks: Check[];
  installmentPlans: InstallmentPlan[];
}

export default function ProfessionalDashboard({
  products,
  customers,
  invoices,
  checks,
  installmentPlans,
}: ProfessionalDashboardProps) {
  // محاسبات
  const today = new Date().toISOString().split('T')[0];
  
  // فروش امروز
  const todayInvoices = invoices.filter(inv => inv.date === today && inv.type === 'sale');
  const todaySales = todayInvoices.reduce((sum, inv) => sum + inv.total, 0);
  const todayProfit = todayInvoices.reduce((sum, inv) => {
    const profit = inv.items.reduce((itemSum, item) => {
      return itemSum + ((item.sellPrice - item.buyPrice) * item.quantity);
    }, 0);
    return sum + profit;
  }, 0);

  // دریافتی و پرداختی امروز
  const todayReceived = invoices.reduce((sum, inv) => sum + inv.paid, 0);
  const todayPaid = invoices.filter(inv => inv.type === 'purchase').reduce((sum, inv) => sum + inv.paid, 0);

  // بدهی کل
  const totalDebt = invoices.reduce((sum, inv) => sum + inv.remaining, 0);

  // اقساط سررسید شده
  const overdueInstallments = installmentPlans
    .flatMap(plan => plan.installments)
    .filter(inst => inst.status === 'pending' && isOverdue(inst.dueDate));
  const overdueAmount = overdueInstallments.reduce((sum, inst) => sum + inst.amount, 0);

  // چک‌های نزدیک سررسید (7 روز آینده)
  const upcomingChecks = checks
    .filter(check => check.status === 'pending' && !isOverdue(check.dueDate) && daysUntilDue(check.dueDate) <= 7);

  // کالاهای کم‌موجود
  const lowStockProducts = products.filter(p => p.stock <= p.minStock);

  // فروش این ماه
  const thisMonth = new Date().getMonth();
  const thisYear = new Date().getFullYear();
  const monthInvoices = invoices.filter(inv => {
    const d = new Date(inv.date);
    return d.getMonth() === thisMonth && d.getFullYear() === thisYear && inv.type === 'sale';
  });
  const monthSales = monthInvoices.reduce((sum, inv) => sum + inv.total, 0);

  return (
    <div className="space-y-6">
      {/* کارت‌های اصلی */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-emerald-600 to-emerald-800 rounded-2xl p-5 text-white shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-emerald-200 text-sm">فروش امروز</span>
            <span className="text-2xl">💰</span>
          </div>
          <p className="text-2xl font-bold">{formatNumber(todaySales)}</p>
          <p className="text-emerald-200 text-xs mt-1">تومان</p>
        </div>

        <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl p-5 text-white shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-blue-200 text-sm">سود امروز</span>
            <span className="text-2xl">📈</span>
          </div>
          <p className="text-2xl font-bold">{formatNumber(todayProfit)}</p>
          <p className="text-blue-200 text-xs mt-1">تومان</p>
        </div>

        <div className="bg-gradient-to-br from-violet-600 to-violet-800 rounded-2xl p-5 text-white shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-violet-200 text-sm">دریافتی امروز</span>
            <span className="text-2xl">💵</span>
          </div>
          <p className="text-2xl font-bold">{formatNumber(todayReceived)}</p>
          <p className="text-violet-200 text-xs mt-1">تومان</p>
        </div>

        <div className="bg-gradient-to-br from-rose-600 to-rose-800 rounded-2xl p-5 text-white shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-rose-200 text-sm">پرداختی امروز</span>
            <span className="text-2xl">💸</span>
          </div>
          <p className="text-2xl font-bold">{formatNumber(todayPaid)}</p>
          <p className="text-rose-200 text-xs mt-1">تومان</p>
        </div>
      </div>

      {/* کارت‌های وضعیت */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-5 border border-slate-700/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">بدهی کل</span>
            <span className="text-2xl">💳</span>
          </div>
          <p className="text-xl font-bold text-rose-400">{formatNumber(totalDebt)}</p>
          <p className="text-slate-500 text-xs mt-1">تومان</p>
        </div>

        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-5 border border-slate-700/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">اقساط معوق</span>
            <span className="text-2xl">⚠️</span>
          </div>
          <p className="text-xl font-bold text-amber-400">{overdueInstallments.length}</p>
          <p className="text-slate-500 text-xs mt-1">{formatNumber(overdueAmount)} تومان</p>
        </div>

        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-5 border border-slate-700/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">چک‌های نزدیک</span>
            <span className="text-2xl">📝</span>
          </div>
          <p className="text-xl font-bold text-blue-400">{upcomingChecks.length}</p>
          <p className="text-slate-500 text-xs mt-1">7 روز آینده</p>
        </div>

        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-5 border border-slate-700/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">کم‌موجود</span>
            <span className="text-2xl">📦</span>
          </div>
          <p className="text-xl font-bold text-orange-400">{lowStockProducts.length}</p>
          <p className="text-slate-500 text-xs mt-1">کالا</p>
        </div>
      </div>

      {/* هشدارها */}
      {(overdueInstallments.length > 0 || upcomingChecks.length > 0 || lowStockProducts.length > 0) && (
        <div className="bg-gradient-to-br from-amber-900/30 to-orange-900/30 rounded-2xl p-6 border border-amber-500/30">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            ⚠️ هشدارها
          </h3>
          <div className="space-y-3">
            {overdueInstallments.length > 0 && (
              <div className="bg-rose-500/10 border border-rose-500/30 rounded-xl p-3">
                <p className="text-rose-400 font-bold">🔴 اقساط سررسید شده</p>
                <p className="text-slate-300 text-sm mt-1">
                  {overdueInstallments.length} قسط به مبلغ {formatNumber(overdueAmount)} تومان سررسید شده است
                </p>
              </div>
            )}
            {upcomingChecks.length > 0 && (
              <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-3">
                <p className="text-blue-400 font-bold">🔵 چک‌های نزدیک سررسید</p>
                <p className="text-slate-300 text-sm mt-1">
                  {upcomingChecks.length} چک در 7 روز آینده سررسید می‌شود
                </p>
              </div>
            )}
            {lowStockProducts.length > 0 && (
              <div className="bg-orange-500/10 border border-orange-500/30 rounded-xl p-3">
                <p className="text-orange-400 font-bold">🟠 کالاهای کم‌موجود</p>
                <p className="text-slate-300 text-sm mt-1">
                  {lowStockProducts.length} کالا به حداقل موجودی رسیده است
                </p>
                <div className="mt-2 space-y-1">
                  {lowStockProducts.slice(0, 3).map(p => (
                    <p key={p.id} className="text-slate-400 text-xs">
                      • {p.name} - موجودی: {p.stock}
                    </p>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* آمار ماهانه */}
      <div className="bg-gradient-to-br from-teal-900/30 to-cyan-900/30 rounded-2xl p-6 border border-teal-500/30">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          📊 آمار این ماه
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-slate-800/60 rounded-xl p-4">
            <p className="text-slate-400 text-sm mb-1">فروش ماه</p>
            <p className="text-xl font-bold text-emerald-400">{formatNumber(monthSales)}</p>
            <p className="text-slate-500 text-xs mt-1">تومان</p>
          </div>
          <div className="bg-slate-800/60 rounded-xl p-4">
            <p className="text-slate-400 text-sm mb-1">تعداد فاکتور</p>
            <p className="text-xl font-bold text-blue-400">{monthInvoices.length}</p>
            <p className="text-slate-500 text-xs mt-1">فاکتور</p>
          </div>
          <div className="bg-slate-800/60 rounded-xl p-4">
            <p className="text-slate-400 text-sm mb-1">میانگین فاکتور</p>
            <p className="text-xl font-bold text-violet-400">
              {formatNumber(monthInvoices.length > 0 ? Math.round(monthSales / monthInvoices.length) : 0)}
            </p>
            <p className="text-slate-500 text-xs mt-1">تومان</p>
          </div>
        </div>
      </div>
    </div>
  );
}
