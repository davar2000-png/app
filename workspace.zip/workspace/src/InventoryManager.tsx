import { useState } from 'react';
import { Product, ProductCategory, ProductBrand, ProductModel, ProductColor } from './types';
import { generateId } from './utils';

interface InventoryManagerProps {
  products: Product[];
  categories: ProductCategory[];
  brands: ProductBrand[];
  models: ProductModel[];
  colors: ProductColor[];
  onAddProduct: (product: Product) => void;
  onUpdateCategories: (categories: ProductCategory[]) => void;
  onUpdateBrands: (brands: ProductBrand[]) => void;
  onUpdateModels: (models: ProductModel[]) => void;
  onUpdateColors: (colors: ProductColor[]) => void;
}

export default function InventoryManager({
  products,
  categories,
  brands,
  models,
  colors,
  onAddProduct,
  onUpdateCategories,
  onUpdateBrands,
  onUpdateModels,
  onUpdateColors,
}: InventoryManagerProps) {
  const [activeSection, setActiveSection] = useState<'form' | 'categories' | 'brands' | 'models' | 'colors'>('form');
  
  // فرم کالا
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('');
  const [selectedModel, setSelectedModel] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [ram, setRam] = useState('');
  const [storage, setStorage] = useState('');
  const [buyPrice, setBuyPrice] = useState('');
  const [sellPrice, setSellPrice] = useState('');
  const [stock, setStock] = useState('0');
  const [minStock, setMinStock] = useState('0');
  const [reorderPoint, setReorderPoint] = useState('0');
  const [allowNegativeStock, setAllowNegativeStock] = useState(false);
  const [serialNumbers, setSerialNumbers] = useState('');
  const [description, setDescription] = useState('');

  // مدیریت گروه‌ها
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryIcon, setNewCategoryIcon] = useState('📦');
  const [editingCategory, setEditingCategory] = useState<string | null>(null);
  const [editCategoryName, setEditCategoryName] = useState('');
  const [editCategoryIcon, setEditCategoryIcon] = useState('');

  // مدیریت برندها
  const [newBrandName, setNewBrandName] = useState('');
  const [newBrandCategory, setNewBrandCategory] = useState('');
  const [editingBrand, setEditingBrand] = useState<string | null>(null);
  const [editBrandName, setEditBrandName] = useState('');
  const [editBrandCategory, setEditBrandCategory] = useState('');

  // مدیریت مدل‌ها
  const [newModelName, setNewModelName] = useState('');
  const [newModelBrand, setNewModelBrand] = useState('');
  const [editingModel, setEditingModel] = useState<string | null>(null);
  const [editModelName, setEditModelName] = useState('');
  const [editModelBrand, setEditModelBrand] = useState('');

  // مدیریت رنگ‌ها
  const [newColorName, setNewColorName] = useState('');
  const [newColorCode, setNewColorCode] = useState('#ffffff');
  const [editingColor, setEditingColor] = useState<string | null>(null);
  const [editColorName, setEditColorName] = useState('');
  const [editColorCode, setEditColorCode] = useState('');

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCategory || !selectedBrand || !selectedModel || !buyPrice || !sellPrice) return;

    const category = categories.find(c => c.id === selectedCategory);
    const brand = brands.find(b => b.id === selectedBrand);
    const model = models.find(m => m.id === selectedModel);
    const color = colors.find(c => c.id === selectedColor);

    const productName = [
      brand?.name,
      model?.name,
      color?.name,
      ram && `${ram} RAM`,
      storage && `${storage} حافظه`,
    ].filter(Boolean).join(' - ');

    // تعیین نوع دسته‌بندی
    let categoryType: 'phone' | 'laptop' | 'console' | 'printer' | 'misc' = 'misc';
    if (category?.name.toLowerCase().includes('گوشی')) {
      categoryType = 'phone';
    } else if (category?.name.toLowerCase().includes('لپ')) {
      categoryType = 'laptop';
    } else if (category?.name.toLowerCase().includes('کنسول')) {
      categoryType = 'console';
    } else if (category?.name.toLowerCase().includes('پرینتر')) {
      categoryType = 'printer';
    } else {
      categoryType = 'misc';
    }

    const product: Product = {
      id: generateId(),
      code: `PRD-${Date.now()}`,
      name: productName,
      category: categoryType,
      categoryId: selectedCategory,
      brand: brand?.name || '',
      brandId: selectedBrand,
      model: model?.name || '',
      modelId: selectedModel,
      color: color?.name,
      ram,
      storage,
      buyPrice: Number(buyPrice),
      sellPrice: Number(sellPrice),
      stock: Number(stock),
      minStock: Number(minStock),
      reorderPoint: Number(reorderPoint),
      allowNegativeStock,
      serialNumbers: serialNumbers.split('\n').filter(s => s.trim()),
      description,
      createdAt: new Date().toISOString(),
    };

    onAddProduct(product);
    
    // ریست فرم
    setSelectedCategory('');
    setSelectedBrand('');
    setSelectedModel('');
    setSelectedColor('');
    setRam('');
    setStorage('');
    setBuyPrice('');
    setSellPrice('');
    setStock('0');
    setMinStock('0');
    setReorderPoint('0');
    setAllowNegativeStock(false);
    setSerialNumbers('');
    setDescription('');
  };

  const filteredBrands = brands.filter(b => b.categoryId === selectedCategory);
  const filteredModels = models.filter(m => m.brandId === selectedBrand);

  return (
    <div className="space-y-6">
      {/* منوی بخش‌ها */}
      <div className="flex gap-2 flex-wrap">
        <button
          onClick={() => setActiveSection('form')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
            activeSection === 'form'
              ? 'bg-blue-600 text-white'
              : 'bg-slate-700/50 text-slate-300 hover:bg-slate-600'
          }`}
        >
          ➕ ثبت کالا
        </button>
        <button
          onClick={() => setActiveSection('categories')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
            activeSection === 'categories'
              ? 'bg-blue-600 text-white'
              : 'bg-slate-700/50 text-slate-300 hover:bg-slate-600'
          }`}
        >
          📁 گروه‌ها
        </button>
        <button
          onClick={() => setActiveSection('brands')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
            activeSection === 'brands'
              ? 'bg-blue-600 text-white'
              : 'bg-slate-700/50 text-slate-300 hover:bg-slate-600'
          }`}
        >
          🏷️ برندها
        </button>
        <button
          onClick={() => setActiveSection('models')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
            activeSection === 'models'
              ? 'bg-blue-600 text-white'
              : 'bg-slate-700/50 text-slate-300 hover:bg-slate-600'
          }`}
        >
          📱 مدل‌ها
        </button>
        <button
          onClick={() => setActiveSection('colors')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
            activeSection === 'colors'
              ? 'bg-blue-600 text-white'
              : 'bg-slate-700/50 text-slate-300 hover:bg-slate-600'
          }`}
        >
          🎨 رنگ‌ها
        </button>
      </div>

      {/* فرم ثبت کالا */}
      {activeSection === 'form' && (
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-6">
          <h3 className="text-xl font-bold text-white mb-4">➕ ثبت کالای جدید</h3>
          <form onSubmit={handleAddProduct} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* گروه کالا */}
              <div>
                <label className="block text-slate-300 text-sm mb-2">گروه کالا *</label>
                <select
                  value={selectedCategory}
                  onChange={e => { setSelectedCategory(e.target.value); setSelectedBrand(''); setSelectedModel(''); }}
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500"
                  required
                >
                  <option value="">انتخاب گروه...</option>
                  {categories.map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.icon} {cat.name}</option>
                  ))}
                </select>
              </div>

              {/* برند */}
              <div>
                <label className="block text-slate-300 text-sm mb-2">برند *</label>
                <select
                  value={selectedBrand}
                  onChange={e => { setSelectedBrand(e.target.value); setSelectedModel(''); }}
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500"
                  required
                  disabled={!selectedCategory}
                >
                  <option value="">انتخاب برند...</option>
                  {filteredBrands.map(brand => (
                    <option key={brand.id} value={brand.id}>{brand.name}</option>
                  ))}
                </select>
              </div>

              {/* مدل */}
              <div>
                <label className="block text-slate-300 text-sm mb-2">مدل *</label>
                <select
                  value={selectedModel}
                  onChange={e => setSelectedModel(e.target.value)}
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500"
                  required
                  disabled={!selectedBrand}
                >
                  <option value="">انتخاب مدل...</option>
                  {filteredModels.map(model => (
                    <option key={model.id} value={model.id}>{model.name}</option>
                  ))}
                </select>
              </div>

              {/* رنگ */}
              <div>
                <label className="block text-slate-300 text-sm mb-2">رنگ</label>
                <select
                  value={selectedColor}
                  onChange={e => setSelectedColor(e.target.value)}
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="">انتخاب رنگ...</option>
                  {colors.map(color => (
                    <option key={color.id} value={color.id}>{color.name}</option>
                  ))}
                </select>
              </div>

              {/* رم */}
              <div>
                <label className="block text-slate-300 text-sm mb-2">رم (GB)</label>
                <input
                  type="text"
                  value={ram}
                  onChange={e => setRam(e.target.value)}
                  placeholder="مثلاً: 8"
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* حافظه */}
              <div>
                <label className="block text-slate-300 text-sm mb-2">حافظه (GB)</label>
                <input
                  type="text"
                  value={storage}
                  onChange={e => setStorage(e.target.value)}
                  placeholder="مثلاً: 128"
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* قیمت خرید */}
              <div>
                <label className="block text-slate-300 text-sm mb-2">قیمت خرید (تومان) *</label>
                <input
                  type="number"
                  value={buyPrice}
                  onChange={e => setBuyPrice(e.target.value)}
                  placeholder="0"
                  min="0"
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              {/* قیمت فروش */}
              <div>
                <label className="block text-slate-300 text-sm mb-2">قیمت فروش (تومان) *</label>
                <input
                  type="number"
                  value={sellPrice}
                  onChange={e => setSellPrice(e.target.value)}
                  placeholder="0"
                  min="0"
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              {/* موجودی */}
              <div>
                <label className="block text-slate-300 text-sm mb-2">موجودی اولیه</label>
                <input
                  type="number"
                  value={stock}
                  onChange={e => setStock(e.target.value)}
                  min="0"
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* حداقل موجودی */}
              <div>
                <label className="block text-slate-300 text-sm mb-2">حداقل موجودی</label>
                <input
                  type="number"
                  value={minStock}
                  onChange={e => setMinStock(e.target.value)}
                  min="0"
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* نقطه سفارش */}
              <div>
                <label className="block text-slate-300 text-sm mb-2">نقطه سفارش</label>
                <input
                  type="number"
                  value={reorderPoint}
                  onChange={e => setReorderPoint(e.target.value)}
                  min="0"
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* اجازه موجودی منفی */}
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="allowNegative"
                  checked={allowNegativeStock}
                  onChange={e => setAllowNegativeStock(e.target.checked)}
                  className="w-5 h-5 rounded"
                />
                <label htmlFor="allowNegative" className="text-slate-300 text-sm">
                  اجازه فروش با موجودی منفی
                </label>
              </div>
            </div>

            {/* شماره سریال */}
            <div>
              <label className="block text-slate-300 text-sm mb-2">شماره سریال‌ها (هر خط یک شماره)</label>
              <textarea
                value={serialNumbers}
                onChange={e => setSerialNumbers(e.target.value)}
                placeholder="IMEI123456789&#10;IMEI987654321"
                rows={3}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none"
              />
            </div>

            {/* توضیحات */}
            <div>
              <label className="block text-slate-300 text-sm mb-2">توضیحات</label>
              <textarea
                value={description}
                onChange={e => setDescription(e.target.value)}
                rows={2}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-700 py-3 rounded-xl font-bold text-white shadow-lg shadow-blue-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all"
            >
              ✓ ثبت کالا
            </button>
          </form>
        </div>
      )}

      {/* مدیریت گروه‌ها */}
      {activeSection === 'categories' && (
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-6">
          <h3 className="text-xl font-bold text-white mb-4">📁 مدیریت گروه‌های کالا</h3>
          
          <div className="mb-4 flex gap-2">
            <input
              type="text"
              value={newCategoryName}
              onChange={e => setNewCategoryName(e.target.value)}
              placeholder="نام گروه"
              className="flex-1 bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <input
              type="text"
              value={newCategoryIcon}
              onChange={e => setNewCategoryIcon(e.target.value)}
              placeholder="📦"
              className="w-20 bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-2 text-white text-center focus:outline-none focus:border-blue-500"
            />
            <button
              onClick={() => {
                if (newCategoryName) {
                  onUpdateCategories([...categories, { id: generateId(), name: newCategoryName, icon: newCategoryIcon }]);
                  setNewCategoryName('');
                  setNewCategoryIcon('📦');
                }
              }}
              className="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all"
            >
              ➕ افزودن
            </button>
          </div>

          <div className="space-y-2">
            {categories.map(cat => (
              <div key={cat.id} className="bg-slate-700/30 rounded-xl p-3">
                {editingCategory === cat.id ? (
                  <div className="flex gap-2 items-center">
                    <input
                      type="text"
                      value={editCategoryIcon}
                      onChange={e => setEditCategoryIcon(e.target.value)}
                      className="w-16 bg-slate-700/50 border border-slate-600 rounded-lg px-2 py-1 text-white text-center focus:outline-none focus:border-blue-500"
                    />
                    <input
                      type="text"
                      value={editCategoryName}
                      onChange={e => setEditCategoryName(e.target.value)}
                      className="flex-1 bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-1 text-white focus:outline-none focus:border-blue-500"
                    />
                    <button
                      onClick={() => {
                        if (editCategoryName) {
                          onUpdateCategories(categories.map(c => 
                            c.id === cat.id ? { ...c, name: editCategoryName, icon: editCategoryIcon } : c
                          ));
                          setEditingCategory(null);
                        }
                      }}
                      className="px-3 py-1 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-all text-sm"
                    >
                      ✓
                    </button>
                    <button
                      onClick={() => setEditingCategory(null)}
                      className="px-3 py-1 bg-slate-600 text-white rounded-lg hover:bg-slate-500 transition-all text-sm"
                    >
                      ✕
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <span className="text-white">{cat.icon} {cat.name}</span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setEditingCategory(cat.id);
                          setEditCategoryName(cat.name);
                          setEditCategoryIcon(cat.icon);
                        }}
                        className="text-blue-400 hover:text-blue-300"
                        title="ویرایش"
                      >
                        ✏️
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`آیا از حذف گروه "${cat.name}" مطمئن هستید؟`)) {
                            onUpdateCategories(categories.filter(c => c.id !== cat.id));
                          }
                        }}
                        className="text-rose-400 hover:text-rose-300"
                        title="حذف"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* مدیریت برندها */}
      {activeSection === 'brands' && (
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-6">
          <h3 className="text-xl font-bold text-white mb-4">🏷️ مدیریت برندها</h3>
          
          <div className="mb-4 flex gap-2">
            <select
              value={newBrandCategory}
              onChange={e => setNewBrandCategory(e.target.value)}
              className="flex-1 bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-2 text-white focus:outline-none focus:border-blue-500"
            >
              <option value="">انتخاب گروه...</option>
              {categories.map(cat => (
                <option key={cat.id} value={cat.id}>{cat.name}</option>
              ))}
            </select>
            <input
              type="text"
              value={newBrandName}
              onChange={e => setNewBrandName(e.target.value)}
              placeholder="نام برند"
              className="flex-1 bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <button
              onClick={() => {
                if (newBrandCategory && newBrandName) {
                  onUpdateBrands([...brands, { id: generateId(), categoryId: newBrandCategory, name: newBrandName }]);
                  setNewBrandName('');
                  setNewBrandCategory('');
                }
              }}
              className="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all"
            >
              ➕ افزودن
            </button>
          </div>

          <div className="space-y-2">
            {brands.map(brand => {
              const category = categories.find(c => c.id === brand.categoryId);
              return (
                <div key={brand.id} className="bg-slate-700/30 rounded-xl p-3">
                  {editingBrand === brand.id ? (
                    <div className="flex gap-2 items-center">
                      <select
                        value={editBrandCategory}
                        onChange={e => setEditBrandCategory(e.target.value)}
                        className="flex-1 bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-1 text-white focus:outline-none focus:border-blue-500"
                      >
                        {categories.map(cat => (
                          <option key={cat.id} value={cat.id}>{cat.name}</option>
                        ))}
                      </select>
                      <input
                        type="text"
                        value={editBrandName}
                        onChange={e => setEditBrandName(e.target.value)}
                        className="flex-1 bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-1 text-white focus:outline-none focus:border-blue-500"
                      />
                      <button
                        onClick={() => {
                          if (editBrandName && editBrandCategory) {
                            onUpdateBrands(brands.map(b => 
                              b.id === brand.id ? { ...b, name: editBrandName, categoryId: editBrandCategory } : b
                            ));
                            setEditingBrand(null);
                          }
                        }}
                        className="px-3 py-1 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-all text-sm"
                      >
                        ✓
                      </button>
                      <button
                        onClick={() => setEditingBrand(null)}
                        className="px-3 py-1 bg-slate-600 text-white rounded-lg hover:bg-slate-500 transition-all text-sm"
                      >
                        ✕
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <span className="text-white">{category?.icon} {category?.name} - {brand.name}</span>
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            setEditingBrand(brand.id);
                            setEditBrandName(brand.name);
                            setEditBrandCategory(brand.categoryId);
                          }}
                          className="text-blue-400 hover:text-blue-300"
                          title="ویرایش"
                        >
                          ✏️
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`آیا از حذف برند "${brand.name}" مطمئن هستید؟`)) {
                              onUpdateBrands(brands.filter(b => b.id !== brand.id));
                            }
                          }}
                          className="text-rose-400 hover:text-rose-300"
                          title="حذف"
                        >
                          🗑️
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* مدیریت مدل‌ها */}
      {activeSection === 'models' && (
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-6">
          <h3 className="text-xl font-bold text-white mb-4">📱 مدیریت مدل‌ها</h3>
          
          <div className="mb-4 flex gap-2">
            <select
              value={newModelBrand}
              onChange={e => setNewModelBrand(e.target.value)}
              className="flex-1 bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-2 text-white focus:outline-none focus:border-blue-500"
            >
              <option value="">انتخاب برند...</option>
              {brands.map(brand => {
                const category = categories.find(c => c.id === brand.categoryId);
                return (
                  <option key={brand.id} value={brand.id}>{category?.name} - {brand.name}</option>
                );
              })}
            </select>
            <input
              type="text"
              value={newModelName}
              onChange={e => setNewModelName(e.target.value)}
              placeholder="نام مدل"
              className="flex-1 bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <button
              onClick={() => {
                if (newModelBrand && newModelName) {
                  onUpdateModels([...models, { id: generateId(), brandId: newModelBrand, name: newModelName }]);
                  setNewModelName('');
                  setNewModelBrand('');
                }
              }}
              className="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all"
            >
              ➕ افزودن
            </button>
          </div>

          <div className="space-y-2">
            {models.map(model => {
              const brand = brands.find(b => b.id === model.brandId);
              const category = categories.find(c => c.id === brand?.categoryId);
              return (
                <div key={model.id} className="bg-slate-700/30 rounded-xl p-3">
                  {editingModel === model.id ? (
                    <div className="flex gap-2 items-center">
                      <select
                        value={editModelBrand}
                        onChange={e => setEditModelBrand(e.target.value)}
                        className="flex-1 bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-1 text-white focus:outline-none focus:border-blue-500"
                      >
                        {brands.map(b => {
                          const cat = categories.find(c => c.id === b.categoryId);
                          return (
                            <option key={b.id} value={b.id}>{cat?.name} - {b.name}</option>
                          );
                        })}
                      </select>
                      <input
                        type="text"
                        value={editModelName}
                        onChange={e => setEditModelName(e.target.value)}
                        className="flex-1 bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-1 text-white focus:outline-none focus:border-blue-500"
                      />
                      <button
                        onClick={() => {
                          if (editModelName && editModelBrand) {
                            onUpdateModels(models.map(m => 
                              m.id === model.id ? { ...m, name: editModelName, brandId: editModelBrand } : m
                            ));
                            setEditingModel(null);
                          }
                        }}
                        className="px-3 py-1 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-all text-sm"
                      >
                        ✓
                      </button>
                      <button
                        onClick={() => setEditingModel(null)}
                        className="px-3 py-1 bg-slate-600 text-white rounded-lg hover:bg-slate-500 transition-all text-sm"
                      >
                        ✕
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <span className="text-white">{category?.icon} {brand?.name} - {model.name}</span>
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            setEditingModel(model.id);
                            setEditModelName(model.name);
                            setEditModelBrand(model.brandId);
                          }}
                          className="text-blue-400 hover:text-blue-300"
                          title="ویرایش"
                        >
                          ✏️
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`آیا از حذف مدل "${model.name}" مطمئن هستید؟`)) {
                              onUpdateModels(models.filter(m => m.id !== model.id));
                            }
                          }}
                          className="text-rose-400 hover:text-rose-300"
                          title="حذف"
                        >
                          🗑️
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* مدیریت رنگ‌ها */}
      {activeSection === 'colors' && (
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-6">
          <h3 className="text-xl font-bold text-white mb-4">🎨 مدیریت رنگ‌ها</h3>
          
          <div className="mb-4 flex gap-2">
            <input
              type="text"
              value={newColorName}
              onChange={e => setNewColorName(e.target.value)}
              placeholder="نام رنگ"
              className="flex-1 bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <input
              type="color"
              value={newColorCode}
              onChange={e => setNewColorCode(e.target.value)}
              className="w-20 h-10 bg-slate-700/50 border border-slate-600 rounded-xl cursor-pointer"
            />
            <button
              onClick={() => {
                if (newColorName) {
                  onUpdateColors([...colors, { id: generateId(), name: newColorName, code: newColorCode }]);
                  setNewColorName('');
                  setNewColorCode('#ffffff');
                }
              }}
              className="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all"
            >
              ➕ افزودن
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {colors.map(color => (
              <div key={color.id} className="bg-slate-700/30 rounded-xl p-3">
                {editingColor === color.id ? (
                  <div className="flex gap-2 items-center">
                    <input
                      type="text"
                      value={editColorName}
                      onChange={e => setEditColorName(e.target.value)}
                      className="flex-1 bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-1 text-white focus:outline-none focus:border-blue-500"
                    />
                    <input
                      type="color"
                      value={editColorCode}
                      onChange={e => setEditColorCode(e.target.value)}
                      className="w-12 h-8 bg-slate-700/50 border border-slate-600 rounded-lg cursor-pointer"
                    />
                    <button
                      onClick={() => {
                        if (editColorName) {
                          onUpdateColors(colors.map(c => 
                            c.id === color.id ? { ...c, name: editColorName, code: editColorCode } : c
                          ));
                          setEditingColor(null);
                        }
                      }}
                      className="px-3 py-1 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-all text-sm"
                    >
                      ✓
                    </button>
                    <button
                      onClick={() => setEditingColor(null)}
                      className="px-3 py-1 bg-slate-600 text-white rounded-lg hover:bg-slate-500 transition-all text-sm"
                    >
                      ✕
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full border-2 border-white" style={{ backgroundColor: color.code }} />
                      <span className="text-white text-sm">{color.name}</span>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setEditingColor(color.id);
                          setEditColorName(color.name);
                          setEditColorCode(color.code);
                        }}
                        className="text-blue-400 hover:text-blue-300"
                        title="ویرایش"
                      >
                        ✏️
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`آیا از حذف رنگ "${color.name}" مطمئن هستید؟`)) {
                            onUpdateColors(colors.filter(c => c.id !== color.id));
                          }
                        }}
                        className="text-rose-400 hover:text-rose-300"
                        title="حذف"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
