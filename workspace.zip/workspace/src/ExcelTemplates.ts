import * as XLSX from 'xlsx';

export function downloadSampleCustomers() {
  const data = [
    ['نام', 'موبایل', 'آدرس', 'کد ملی', 'شغل', 'شهر', 'بستانکار', 'بدهکار', 'توضیحات'],
    ['علی احمدی', '09123456789', 'تهران، خیابان ولیعصر', '0012345678', 'مهندس', 'تهران', '0', '0', ''],
    ['مریم رضایی', '09351234567', 'اصفهان، خیابان چهارباغ', '0023456789', 'دکتر', 'اصفهان', '0', '0', ''],
    ['فروشگاه تکنولایف', '', 'https://technolife.ir/', '', 'فروشگاه', '', '0', '5000000', 'همکار'],
  ];

  const ws = XLSX.utils.aoa_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'اشخاص');
  XLSX.writeFile(wb, 'sample-customers.xlsx');
}

export function downloadSampleProducts() {
  const data = [
    ['نام', 'دسته', 'برند', 'مدل', 'قیمت خرید', 'قیمت فروش', 'موجودی', 'توضیحات'],
    ['آیفون 15 پرو مکس', 'گوشی', 'Apple', 'iPhone 15 Pro Max 256GB', 70000000, 80000000, 5, 'رنگ تیتانیوم طبیعی'],
    ['لپ‌تاپ ایسوس', 'لپ‌تاپ', 'ASUS', 'ROG Strix G15', 45000000, 55000000, 3, 'RAM 16GB, SSD 512GB'],
    ['پلی‌استیشن 5', 'کنسول', 'Sony', 'PS5 Disc Edition', 25000000, 32000000, 10, 'نسخه دیسک‌خور'],
  ];

  const ws = XLSX.utils.aoa_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'کالاها');
  XLSX.writeFile(wb, 'sample-products.xlsx');
}

export function downloadSampleSales() {
  const data = [
    ['محصول', 'مشتری', 'تعداد', 'قیمت واحد', 'مبلغ کل', 'نوع پرداخت', 'پیش پرداخت', 'تاریخ'],
    ['آیفون 15 پرو مکس', 'علی احمدی', 1, 80000000, 80000000, 'نقدی', 80000000, '2024-01-15'],
    ['لپ‌تاپ ایسوس', 'مریم رضایی', 1, 55000000, 55000000, 'اقساطی', 20000000, '2024-01-20'],
  ];

  const ws = XLSX.utils.aoa_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'فاکتورها');
  XLSX.writeFile(wb, 'sample-sales.xlsx');
}
