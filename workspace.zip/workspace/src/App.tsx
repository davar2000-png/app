import { useState } from 'react';
import { Product, Customer, Sale, CustomerGroup, ProductCategory, ProductBrand, ProductModel, ProductColor, Reminder, DailyNote, Invoice, Check, InstallmentPlan } from './types';
import { useLocalStorage } from './useLocalStorage';
import StoreDashboard from './StoreDashboard';
import ProductForm from './ProductForm';
import ProductList from './ProductList';
import CustomerForm from './CustomerForm';
import CustomerList from './CustomerList';
import GroupManager from './GroupManager';
import SaleForm from './SaleForm';
import SalesList from './SalesList';
import ImportExcel from './ImportExcel';
import InventoryManager from './InventoryManager';
import RemindersAndNotes from './RemindersAndNotes';
import AIAssistant from './AIAssistant';
import Sidebar from './Sidebar';
import PurchaseInvoiceForm from './PurchaseInvoiceForm';
import { downloadSampleCustomers, downloadSampleProducts, downloadSampleSales } from './ExcelTemplates';

export default function App() {
  const [products, setProducts] = useLocalStorage<Product[]>('store-products', []);
  const [customers, setCustomers] = useLocalStorage<Customer[]>('store-customers', []);
  const [sales, setSales] = useLocalStorage<Sale[]>('store-sales', []);
  const [groups, setGroups] = useLocalStorage<CustomerGroup[]>('store-groups', [
    { id: 'vip', name: 'مشتریان VIP', icon: '💎', color: '#f59e0b' },
    { id: 'regular', name: 'مشتریان عادی', icon: '👥', color: '#3b82f6' },
    { id: 'employee', name: 'کارمندان', icon: '🏢', color: '#10b981' },
  ]);
  
  const [categories, setCategories] = useLocalStorage<ProductCategory[]>('store-categories', [
    { id: 'phone', name: 'گوشی موبایل', icon: '📱' },
    { id: 'laptop', name: 'لپ‌تاپ', icon: '💻' },
    { id: 'console', name: 'کنسول بازی', icon: '🎮' },
    { id: 'printer', name: 'پرینتر', icon: '🖨️' },
    { id: 'misc', name: 'متفرقه', icon: '📦' },
  ]);
  const [brands, setBrands] = useLocalStorage<ProductBrand[]>('store-brands', [
    { id: 'apple', categoryId: 'phone', name: 'Apple' },
    { id: 'samsung', categoryId: 'phone', name: 'Samsung' },
    { id: 'xiaomi', categoryId: 'phone', name: 'Xiaomi' },
    { id: 'hp', categoryId: 'laptop', name: 'HP' },
    { id: 'dell', categoryId: 'laptop', name: 'Dell' },
    { id: 'asus', categoryId: 'laptop', name: 'ASUS' },
    { id: 'surface', categoryId: 'laptop', name: 'Surface' },
    { id: 'lenovo', categoryId: 'laptop', name: 'Lenovo' },
    { id: 'ps4', categoryId: 'console', name: 'PS4' },
    { id: 'ps5', categoryId: 'console', name: 'PS5' },
    { id: 'hp-printer', categoryId: 'printer', name: 'HP' },
    { id: 'canon', categoryId: 'printer', name: 'Canon' },
    { id: 'brother', categoryId: 'printer', name: 'Brother' },
  ]);
  const [models, setModels] = useLocalStorage<ProductModel[]>('store-models', []);
  const [colors, setColors] = useLocalStorage<ProductColor[]>('store-colors', [
    { id: 'black', name: 'مشکی', code: '#000000' },
    { id: 'white', name: 'سفید', code: '#ffffff' },
    { id: 'blue', name: 'آبی', code: '#3b82f6' },
    { id: 'red', name: 'قرمز', code: '#ef4444' },
  ]);
  
  const [reminders, setReminders] = useLocalStorage<Reminder[]>('store-reminders', []);
  const [notes, setNotes] = useLocalStorage<DailyNote[]>('store-notes', []);
  const [invoices, setInvoices] = useLocalStorage<Invoice[]>('store-invoices', []);
  const [checks, setChecks] = useLocalStorage<Check[]>('store-checks', []);
  const [installmentPlans, setInstallmentPlans] = useLocalStorage<InstallmentPlan[]>('store-installment-plans', []);
  
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [sidebarSection, setSidebarSection] = useState<string>('dashboard');

  // Handlers
  const handleAddProduct = (product: Product) => setProducts(prev => [product, ...prev]);
  const handleDeleteProduct = (id: string) => {
    if (confirm('آیا از حذف این محصول مطمئن هستید؟')) {
      setProducts(prev => prev.filter(p => p.id !== id));
    }
  };
  const handleUpdateProduct = (updatedProduct: Product) => {
    setProducts(prev => prev.map(p => p.id === updatedProduct.id ? updatedProduct : p));
  };
  const handleAddCustomer = (customer: Customer) => setCustomers(prev => [customer, ...prev]);
  const handleDeleteCustomer = (id: string) => {
    if (confirm('آیا از حذف این شخص مطمئن هستید؟')) {
      setCustomers(prev => prev.filter(c => c.id !== id));
    }
  };
  const handleUpdateCustomer = (updatedCustomer: Customer) => {
    setCustomers(prev => prev.map(c => c.id === updatedCustomer.id ? updatedCustomer : c));
  };
  const handleAddGroup = (group: CustomerGroup) => setGroups(prev => [...prev, group]);
  const handleDeleteGroup = (id: string) => {
    if (confirm('آیا از حذف این گروه مطمئن هستید؟')) {
      setGroups(prev => prev.filter(g => g.id !== id));
      setCustomers(prev => prev.map(c => c.groupId === id ? { ...c, groupId: undefined } : c));
    }
  };
  const handleEditGroup = (updatedGroup: CustomerGroup) => {
    setGroups(prev => prev.map(g => g.id === updatedGroup.id ? updatedGroup : g));
  };
  const handleAddSale = (sale: Sale) => setSales(prev => [sale, ...prev]);
  const handleUpdateSale = (updatedSale: Sale) => {
    setSales(prev => prev.map(s => s.id === updatedSale.id ? updatedSale : s));
  };
  const handleDeleteSale = (id: string) => {
    if (confirm('آیا از حذف این فروش مطمئن هستید؟')) {
      setSales(prev => prev.filter(s => s.id !== id));
    }
  };
  const handleImportProducts = (data: any[]) => {
    const newProducts = data as Product[];
    setProducts(prev => [...newProducts, ...prev]);
    alert(`${newProducts.length} محصول با موفقیت وارد شد!`);
  };
  const handleImportCustomers = (data: any[]) => {
    const newCustomers = data as Customer[];
    setCustomers(prev => [...newCustomers, ...prev]);
    alert(`${newCustomers.length} شخص با موفقیت وارد شد!`);
  };

  // Export/Import
  const handleExport = () => {
    const data = {
      products, customers, sales, groups, categories, brands, models, colors,
      reminders, notes, invoices, checks, installmentPlans,
      exportDate: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backup-${new Date().toLocaleDateString('fa-IR')}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        if (data.products) setProducts(data.products);
        if (data.customers) setCustomers(data.customers);
        if (data.sales) setSales(data.sales);
        if (data.groups) setGroups(data.groups);
        alert('داده‌ها با موفقیت بازیابی شدند!');
      } catch (error) {
        alert('خطا در خواندن فایل!');
      }
    };
    reader.readAsText(file);
  };

  // رندر محتوای اصلی بر اساس بخش انتخاب شده
  const renderContent = () => {
    // بخش‌های معرفی
    if (sidebarSection.startsWith('intro-')) {
      return (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-gradient-to-br from-blue-600 to-violet-600 rounded-2xl p-6 text-white">
            <h2 className="text-2xl font-bold mb-2">📖 معرفی</h2>
            <p className="text-blue-100">مدیریت و تنظیمات پایه</p>
          </div>
          
          {sidebarSection === 'intro-products' && (
            <div className="space-y-6">
              <ProductForm onAdd={handleAddProduct} products={products} />
              <ProductList products={products} onDelete={handleDeleteProduct} />
            </div>
          )}
          
          {sidebarSection === 'intro-persons' && (
            <div className="space-y-6">
              <CustomerForm onAdd={handleAddCustomer} groups={groups} />
              <CustomerList
                customers={customers}
                sales={sales}
                groups={groups}
                onDelete={handleDeleteCustomer}
                onUpdate={handleUpdateCustomer}
              />
            </div>
          )}
          
          {sidebarSection === 'intro-product-groups' && (
            <InventoryManager
              products={products}
              categories={categories}
              brands={brands}
              models={models}
              colors={colors}
              onAddProduct={handleAddProduct}
              onUpdateCategories={setCategories}
              onUpdateBrands={setBrands}
              onUpdateModels={setModels}
              onUpdateColors={setColors}
            />
          )}
          
          {sidebarSection === 'intro-person-groups' && (
            <GroupManager
              groups={groups}
              onAdd={handleAddGroup}
              onDelete={handleDeleteGroup}
              onEdit={handleEditGroup}
            />
          )}
          
          {sidebarSection === 'intro-banks' && (
            <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-10 text-center">
              <span className="text-5xl block mb-4">🏦</span>
              <h3 className="text-xl font-bold text-white mb-2">گروه بانک‌ها</h3>
              <p className="text-slate-400">این بخش به زودی اضافه خواهد شد</p>
            </div>
          )}
        </div>
      );
    }

    // بخش‌های لیست
    if (sidebarSection.startsWith('list-')) {
      return (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-gradient-to-br from-blue-600 to-violet-600 rounded-2xl p-6 text-white">
            <h2 className="text-2xl font-bold mb-2">📋 لیست‌ها</h2>
            <p className="text-blue-100">مشاهده و مدیریت لیست‌ها</p>
          </div>
          
          {sidebarSection === 'list-products' && (
            <ProductList products={products} onDelete={handleDeleteProduct} />
          )}
          
          {sidebarSection === 'list-checks' && (
            <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-10 text-center">
              <span className="text-5xl block mb-4">💳</span>
              <h3 className="text-xl font-bold text-white mb-2">لیست چک‌ها</h3>
              <p className="text-slate-400">{checks.length} چک ثبت شده</p>
            </div>
          )}
          
          {sidebarSection === 'list-persons' && (
            <CustomerList
              customers={customers}
              sales={sales}
              groups={groups}
              onDelete={handleDeleteCustomer}
              onUpdate={handleUpdateCustomer}
            />
          )}
          
          {sidebarSection === 'list-invoices' && (
            <SalesList
              sales={sales}
              products={products}
              customers={customers}
              onUpdateSale={handleUpdateSale}
              onDelete={handleDeleteSale}
            />
          )}
        </div>
      );
    }

    // بخش‌های فاکتور
    if (sidebarSection.startsWith('invoice-')) {
      return (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-gradient-to-br from-blue-600 to-violet-600 rounded-2xl p-6 text-white">
            <h2 className="text-2xl font-bold mb-2">📄 فاکتور</h2>
            <p className="text-blue-100">ثبت و مدیریت فاکتورها</p>
          </div>
          
          {sidebarSection === 'invoice-purchase' && (
            <PurchaseInvoiceForm
              products={products}
              customers={customers}
              invoices={invoices}
              onSaveInvoice={(invoice) => setInvoices(prev => [invoice, ...prev])}
              onUpdateProduct={handleUpdateProduct}
            />
          )}
          
          {(sidebarSection === 'invoice-sale' || sidebarSection === 'invoice-return-purchase' || sidebarSection === 'invoice-return-sale' || sidebarSection === 'invoice-pre') && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <SaleForm
                products={products}
                customers={customers}
                onAddSale={handleAddSale}
                onUpdateProduct={handleUpdateProduct}
              />
              <div className="space-y-3">
                <ImportExcel type="sales" onImport={(data: any[]) => {
                  alert(`${data.length} فاکتور با موفقیت وارد شد!`);
                }} />
                <button
                  onClick={downloadSampleSales}
                  className="w-full bg-slate-700/50 hover:bg-slate-600/50 text-slate-300 rounded-2xl p-3 flex items-center justify-center gap-2 transition-all text-sm"
                >
                  <span>📥</span>
                  <span>دانلود نمونه فایل اکسل فاکتورها</span>
                </button>
              </div>
            </div>
          )}
          
          <SalesList
            sales={sales}
            products={products}
            customers={customers}
            onUpdateSale={handleUpdateSale}
            onDelete={handleDeleteSale}
          />
        </div>
      );
    }

    // بخش‌های تنظیمات
    if (sidebarSection.startsWith('settings-')) {
      return (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-gradient-to-br from-blue-600 to-violet-600 rounded-2xl p-6 text-white">
            <h2 className="text-2xl font-bold mb-2">⚙️ تنظیمات</h2>
            <p className="text-blue-100">تنظیمات برنامه</p>
          </div>
          
          {sidebarSection === 'settings-theme' && (
            <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-6">
              <h3 className="text-xl font-bold text-white mb-4">🎨 تغییر تم برنامه</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {['تاریک', 'آبی', 'سبز', 'بنفش'].map((theme, i) => (
                  <button
                    key={i}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      i === 0 ? 'border-blue-500 bg-blue-500/20' : 'border-slate-600 bg-slate-700/30 hover:border-blue-500/50'
                    }`}
                  >
                    <div className={`w-full h-16 rounded-lg mb-2 ${
                      i === 0 ? 'bg-slate-900' : i === 1 ? 'bg-blue-900' : i === 2 ? 'bg-emerald-900' : 'bg-violet-900'
                    }`} />
                    <p className="text-white text-sm text-center">{theme}</p>
                  </button>
                ))}
              </div>
            </div>
          )}
          
          {sidebarSection === 'settings-backup' && (
            <div className="space-y-4">
              <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-6">
                <h3 className="text-xl font-bold text-white mb-4">💾 بک‌آپ خودکار</h3>
                <div className="space-y-4">
                  <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4">
                    <h4 className="text-emerald-400 font-bold mb-2">📤 پشتیبان‌گیری دستی</h4>
                    <button
                      onClick={handleExport}
                      className="w-full bg-emerald-600 text-white py-3 rounded-xl font-bold hover:bg-emerald-700 transition-all mt-2"
                    >
                      💾 دانلود فایل پشتیبان
                    </button>
                  </div>
                  <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
                    <h4 className="text-blue-400 font-bold mb-2">📥 بازیابی</h4>
                    <label className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-all cursor-pointer block text-center mt-2">
                      📂 انتخاب فایل پشتیبان
                      <input type="file" accept=".json" onChange={handleImport} className="hidden" />
                    </label>
                  </div>
                  <div className="bg-slate-700/30 rounded-xl p-4">
                    <h4 className="text-white font-bold mb-2">⏰ بک‌آپ خودکار</h4>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-300">وضعیت:</span>
                      <span className="text-emerald-400 font-bold">فعال ✓</span>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-slate-300">آخرین بک‌آپ:</span>
                      <span className="text-white">همیشه (ذخیره خودکار)</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      );
    }

    // داشبورد پیش‌فرض
    return (
      <div className="space-y-6 animate-fadeIn">
        <StoreDashboard products={products} sales={sales} customers={customers} />
        <RemindersAndNotes
          reminders={reminders}
          notes={notes}
          onAddReminder={(r) => setReminders(prev => [r, ...prev])}
          onUpdateReminder={(r) => setReminders(prev => prev.map(x => x.id === r.id ? r : x))}
          onDeleteReminder={(id) => setReminders(prev => prev.filter(r => r.id !== id))}
          onAddNote={(n) => setNotes(prev => [n, ...prev])}
          onUpdateNote={(n) => setNotes(prev => prev.map(x => x.id === n.id ? n : x))}
          onDeleteNote={(id) => setNotes(prev => prev.filter(n => n.id !== id))}
        />
      </div>
    );
  };

  return (
    <div className="min-h-screen text-white">
      {/* سایدبار */}
      <Sidebar onNavigate={setSidebarSection} activeSection={sidebarSection} />

      {/* محتوای اصلی */}
      <div className="lg:mr-72">
        {/* هدر */}
        <header className="bg-slate-900/80 backdrop-blur-lg border-b border-slate-700/50 sticky top-0 z-30">
          <div className="max-w-7xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-violet-600 rounded-xl flex items-center justify-center text-xl shadow-lg">
                  🏪
                </div>
                <div>
                  <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-violet-400 bg-clip-text text-transparent">
                    حسابداری فروشگاه
                  </h1>
                  <p className="text-xs text-slate-500">مدیریت فروش نقد و اقساط - آفلاین</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleExport}
                  className="px-3 py-2 bg-emerald-600/20 text-emerald-400 rounded-lg text-xs hover:bg-emerald-600/30 transition-all flex items-center gap-1.5"
                >
                  <span>💾</span>
                  <span className="hidden sm:inline">پشتیبان‌گیری</span>
                </button>
                <label className="px-3 py-2 bg-blue-600/20 text-blue-400 rounded-lg text-xs hover:bg-blue-600/30 transition-all flex items-center gap-1.5 cursor-pointer">
                  <span>📥</span>
                  <span className="hidden sm:inline">بازیابی</span>
                  <input type="file" accept=".json" onChange={handleImport} className="hidden" />
                </label>
              </div>
            </div>
          </div>
        </header>

        {/* محتوای صفحه */}
        <main className="max-w-7xl mx-auto px-4 py-6">
          {renderContent()}
        </main>

        {/* فوتر */}
        <footer className="mt-12 py-6 border-t border-slate-800/50">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <p className="text-slate-600 text-sm">
              🏪 حسابداری فروشگاه — نسخه آفلاین | بدون نیاز به سرور و اینترنت
            </p>
          </div>
        </footer>
      </div>

      {/* دکمه شناور دستیار هوش مصنوعی */}
      <button
        onClick={() => setShowAIAssistant(!showAIAssistant)}
        className="fixed bottom-6 left-6 w-16 h-16 bg-gradient-to-br from-blue-600 to-violet-600 rounded-full shadow-2xl shadow-blue-500/50 flex items-center justify-center text-3xl hover:scale-110 transition-all z-50"
        title="دستیار هوش مصنوعی"
      >
        🤖
      </button>

      {/* مودال دستیار هوش مصنوعی */}
      {showAIAssistant && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-2xl">
            <AIAssistant
              products={products}
              customers={customers}
              invoices={invoices}
              checks={checks}
              installmentPlans={installmentPlans}
            />
            <button
              onClick={() => setShowAIAssistant(false)}
              className="mt-4 w-full bg-slate-700 text-white py-3 rounded-xl font-bold hover:bg-slate-600 transition-all"
            >
              بستن دستیار
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
