import { Product, Sale, Customer } from './types';
import { formatNumber, isOverdue, daysUntilDue } from './utils';

interface StoreDashboardProps {
  products: Product[];
  sales: Sale[];
  customers: Customer[];
}

export default function StoreDashboard({ products, sales, customers }: StoreDashboardProps) {
  // محاسبه آمار
  const totalSales = sales.filter(s => s.status === 'completed').reduce((sum, s) => sum + s.totalAmount, 0);
  const cashSales = sales.filter(s => s.paymentType === 'cash' && s.status === 'completed').reduce((sum, s) => sum + s.totalAmount, 0);
  const installmentSales = sales.filter(s => s.paymentType === 'installment' && s.status === 'completed').reduce((sum, s) => sum + s.totalAmount, 0);

  // محاسبه اقساط معوق
  const overdueInstallments = sales
    .filter(s => s.paymentType === 'installment' && s.installments)
    .flatMap(s => s.installments!.filter(i => i.status === 'pending' && isOverdue(i.dueDate)));

  const overdueAmount = overdueInstallments.reduce((sum, i) => sum + i.amount, 0);

  // محاسبه اقساط پیش رو
  const upcomingInstallments = sales
    .filter(s => s.paymentType === 'installment' && s.installments)
    .flatMap(s => s.installments!.filter(i => i.status === 'pending' && !isOverdue(i.dueDate) && daysUntilDue(i.dueDate) <= 7));

  const upcomingAmount = upcomingInstallments.reduce((sum, i) => sum + i.amount, 0);

  // محاسبه سود (بدون مالیات)
  const totalProfit = sales
    .filter(s => s.status === 'completed')
    .reduce((sum, s) => {
      const product = products.find(p => p.id === s.productId);
      if (product) {
        return sum + (s.unitPrice - product.buyPrice) * s.quantity;
      }
      return sum;
    }, 0);

  // موجودی کل
  const totalStockValue = products.reduce((sum, p) => sum + (p.buyPrice * p.stock), 0);

  // فروش این ماه
  const thisMonth = new Date().getMonth();
  const thisYear = new Date().getFullYear();
  const monthSales = sales.filter(s => {
    const d = new Date(s.date);
    return d.getMonth() === thisMonth && d.getFullYear() === thisYear && s.status === 'completed';
  });
  const monthTotal = monthSales.reduce((sum, s) => sum + s.totalAmount, 0);

  return (
    <div className="space-y-6">
      {/* کارت‌های اصلی */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* فروش کل */}
        <div className="bg-gradient-to-br from-emerald-600 to-emerald-800 rounded-2xl p-5 text-white shadow-lg shadow-emerald-500/20 animate-fadeIn">
          <div className="flex items-center justify-between mb-3">
            <span className="text-emerald-200 text-sm">کل فروش</span>
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">💰</div>
          </div>
          <p className="text-2xl font-bold">{formatNumber(totalSales)}</p>
          <p className="text-emerald-200 text-xs mt-1">تومان</p>
        </div>

        {/* فروش نقدی */}
        <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl p-5 text-white shadow-lg shadow-blue-500/20 animate-fadeIn" style={{ animationDelay: '0.1s' }}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-blue-200 text-sm">فروش نقدی</span>
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">💵</div>
          </div>
          <p className="text-2xl font-bold">{formatNumber(cashSales)}</p>
          <p className="text-blue-200 text-xs mt-1">تومان</p>
        </div>

        {/* فروش اقساطی */}
        <div className="bg-gradient-to-br from-violet-600 to-violet-800 rounded-2xl p-5 text-white shadow-lg shadow-violet-500/20 animate-fadeIn" style={{ animationDelay: '0.2s' }}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-violet-200 text-sm">فروش اقساطی</span>
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">💳</div>
          </div>
          <p className="text-2xl font-bold">{formatNumber(installmentSales)}</p>
          <p className="text-violet-200 text-xs mt-1">تومان</p>
        </div>

        {/* سود کل */}
        <div className="bg-gradient-to-br from-amber-600 to-amber-800 rounded-2xl p-5 text-white shadow-lg shadow-amber-500/20 animate-fadeIn" style={{ animationDelay: '0.3s' }}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-amber-200 text-sm">سود کل</span>
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">📈</div>
          </div>
          <p className="text-2xl font-bold">{formatNumber(totalProfit)}</p>
          <p className="text-amber-200 text-xs mt-1">تومان</p>
        </div>
      </div>

      {/* کارت‌های وضعیت */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* اقساط معوق */}
        <div className="bg-gradient-to-br from-rose-600 to-rose-800 rounded-2xl p-5 text-white shadow-lg shadow-rose-500/20">
          <div className="flex items-center justify-between mb-3">
            <span className="text-rose-200 text-sm">اقساط معوق</span>
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">⚠️</div>
          </div>
          <p className="text-2xl font-bold">{formatNumber(overdueAmount)}</p>
          <p className="text-rose-200 text-xs mt-1">{overdueInstallments.length} قسط</p>
        </div>

        {/* اقساط پیش رو */}
        <div className="bg-gradient-to-br from-cyan-600 to-cyan-800 rounded-2xl p-5 text-white shadow-lg shadow-cyan-500/20">
          <div className="flex items-center justify-between mb-3">
            <span className="text-cyan-200 text-sm">اقساط ۷ روز آینده</span>
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">📅</div>
          </div>
          <p className="text-2xl font-bold">{formatNumber(upcomingAmount)}</p>
          <p className="text-cyan-200 text-xs mt-1">{upcomingInstallments.length} قسط</p>
        </div>

        {/* ارزش موجودی */}
        <div className="bg-gradient-to-br from-slate-600 to-slate-800 rounded-2xl p-5 text-white shadow-lg shadow-slate-500/20">
          <div className="flex items-center justify-between mb-3">
            <span className="text-slate-200 text-sm">ارزش موجودی</span>
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">📦</div>
          </div>
          <p className="text-2xl font-bold">{formatNumber(totalStockValue)}</p>
          <p className="text-slate-200 text-xs mt-1">تومان</p>
        </div>

        {/* فروش این ماه */}
        <div className="bg-gradient-to-br from-teal-600 to-teal-800 rounded-2xl p-5 text-white shadow-lg shadow-teal-500/20">
          <div className="flex items-center justify-between mb-3">
            <span className="text-teal-200 text-sm">فروش این ماه</span>
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">📊</div>
          </div>
          <p className="text-2xl font-bold">{formatNumber(monthTotal)}</p>
          <p className="text-teal-200 text-xs mt-1">{monthSales.length} فروش</p>
        </div>
      </div>

      {/* آمار سریع */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-5 border border-slate-700/50">
          <h4 className="text-slate-400 text-sm mb-2">تعداد محصولات</h4>
          <p className="text-3xl font-bold text-white">{products.length}</p>
          <p className="text-slate-500 text-xs mt-1">محصول فعال</p>
        </div>
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-5 border border-slate-700/50">
          <h4 className="text-slate-400 text-sm mb-2">تعداد مشتریان</h4>
          <p className="text-3xl font-bold text-white">{customers.length}</p>
          <p className="text-slate-500 text-xs mt-1">مشتری ثبت شده</p>
        </div>
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl p-5 border border-slate-700/50">
          <h4 className="text-slate-400 text-sm mb-2">تعداد فروش‌ها</h4>
          <p className="text-3xl font-bold text-white">{sales.length}</p>
          <p className="text-slate-500 text-xs mt-1">فاکتور صادر شده</p>
        </div>
      </div>
    </div>
  );
}
