import { useState } from 'react';
import { Sale, Product, Customer, Installment } from './types';
import { formatNumber, formatDate, isOverdue, daysUntilDue } from './utils';

interface SalesListProps {
  sales: Sale[];
  products: Product[];
  customers: Customer[];
  onUpdateSale: (sale: Sale) => void;
  onDelete: (id: string) => void;
}

export default function SalesList({ sales, products, customers, onUpdateSale, onDelete }: SalesListProps) {
  const [filter, setFilter] = useState<'all' | 'cash' | 'installment' | 'overdue'>('all');
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);

  let filteredSales = [...sales].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  if (filter === 'cash') {
    filteredSales = filteredSales.filter(s => s.paymentType === 'cash');
  } else if (filter === 'installment') {
    filteredSales = filteredSales.filter(s => s.paymentType === 'installment');
  } else if (filter === 'overdue') {
    filteredSales = filteredSales.filter(s => 
      s.paymentType === 'installment' && 
      s.installments?.some(i => i.status === 'pending' && isOverdue(i.dueDate))
    );
  }

  const handlePayInstallment = (saleId: string, installmentId: string) => {
    const sale = sales.find(s => s.id === saleId);
    if (!sale || !sale.installments) return;

    const updatedInstallments = sale.installments.map(i =>
      i.id === installmentId
        ? { ...i, status: 'paid' as const, paidDate: new Date().toISOString().split('T')[0] }
        : i
    );

    const updatedSale = { ...sale, installments: updatedInstallments };
    onUpdateSale(updatedSale);
  };

  if (sales.length === 0) {
    return (
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-10 text-center">
        <span className="text-4xl block mb-3">🧾</span>
        <p className="text-slate-400">هنوز فروشی ثبت نشده</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* فیلتر */}
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-4">
        <div className="flex flex-wrap gap-2">
          {([
            ['all', 'همه', '📋'],
            ['cash', 'نقدی', '💵'],
            ['installment', 'اقساطی', '💳'],
            ['overdue', 'معوق', '⚠️'],
          ] as const).map(([value, label, icon]) => (
            <button
              key={value}
              onClick={() => setFilter(value)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all flex items-center gap-2 ${
                filter === value
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-slate-700/50 text-slate-300 hover:bg-slate-600'
              }`}
            >
              <span>{icon}</span>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* لیست فروش‌ها */}
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 overflow-hidden">
        <div className="p-5 border-b border-slate-700/50">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            🧾 لیست فروش‌ها
            <span className="text-sm text-slate-400 font-normal">({filteredSales.length} فاکتور)</span>
          </h3>
        </div>

        <div className="divide-y divide-slate-700/50 max-h-[600px] overflow-y-auto">
          {filteredSales.map((sale, index) => {
            const product = products.find(p => p.id === sale.productId);
            const customer = customers.find(c => c.id === sale.customerId);
            const hasOverdue = sale.installments?.some(i => i.status === 'pending' && isOverdue(i.dueDate));

            return (
              <div
                key={sale.id}
                className="p-4 hover:bg-slate-700/20 transition-all animate-slideIn group"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="text-white font-medium">{product?.name || 'محصول نامشخص'}</h4>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        sale.paymentType === 'cash'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'bg-blue-500/20 text-blue-400'
                      }`}>
                        {sale.paymentType === 'cash' ? '💵 نقدی' : '💳 اقساطی'}
                      </span>
                      {hasOverdue && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400">
                          ⚠️ معوق
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-xs text-slate-400">
                      <span>👤 {customer?.name || 'مشتری نامشخص'}</span>
                      <span>📞 {customer?.phone}</span>
                      <span>📅 {formatDate(sale.date)}</span>
                    </div>
                    <div className="flex items-center gap-4 mt-2 text-sm">
                      <span className="text-slate-300">تعداد: {sale.quantity}</span>
                      <span className="text-white font-bold">{formatNumber(sale.totalAmount)} تومان</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {sale.paymentType === 'installment' && (
                      <button
                        onClick={() => setSelectedSale(sale)}
                        className="px-3 py-1.5 bg-blue-600/20 text-blue-400 rounded-lg text-xs hover:bg-blue-600/30 transition-all"
                      >
                        مشاهده اقساط
                      </button>
                    )}
                    <button
                      onClick={() => onDelete(sale.id)}
                      className="opacity-0 group-hover:opacity-100 text-rose-400 hover:text-rose-300 transition-all"
                      title="حذف"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* مودال اقساط */}
      {selectedSale && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setSelectedSale(null)}>
          <div className="bg-slate-800 rounded-2xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto border border-slate-700" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">جزئیات اقساط</h3>
              <button
                onClick={() => setSelectedSale(null)}
                className="text-slate-400 hover:text-white w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-700"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              {selectedSale.installments?.map((installment, i) => {
                const overdue = installment.status === 'pending' && isOverdue(installment.dueDate);
                const days = daysUntilDue(installment.dueDate);

                return (
                  <div
                    key={installment.id}
                    className={`p-4 rounded-xl border ${
                      installment.status === 'paid'
                        ? 'bg-emerald-500/10 border-emerald-500/30'
                        : overdue
                        ? 'bg-rose-500/10 border-rose-500/30'
                        : 'bg-slate-700/30 border-slate-600'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white font-medium">قسط {i + 1}</p>
                        <p className="text-slate-400 text-sm mt-1">
                          سررسید: {formatDate(installment.dueDate)}
                          {installment.status === 'pending' && !overdue && (
                            <span className="text-blue-400 mr-2">({days} روز مانده)</span>
                          )}
                          {overdue && <span className="text-rose-400 mr-2">(معوق)</span>}
                          {installment.status === 'paid' && installment.paidDate && (
                            <span className="text-emerald-400 mr-2">(پرداخت شده: {formatDate(installment.paidDate)})</span>
                          )}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-white font-bold">{formatNumber(installment.amount)} تومان</span>
                        {installment.status === 'pending' && (
                          <button
                            onClick={() => handlePayInstallment(selectedSale.id, installment.id)}
                            className="px-3 py-1.5 bg-emerald-600 text-white rounded-lg text-xs hover:bg-emerald-700 transition-all"
                          >
                            پرداخت
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
