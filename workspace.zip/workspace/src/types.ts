export interface ProductCategory {
  id: string;
  name: string;
  icon: string;
}

export interface ProductBrand {
  id: string;
  categoryId: string;
  name: string;
}

export interface ProductModel {
  id: string;
  brandId: string;
  name: string;
}

export interface ProductColor {
  id: string;
  name: string;
  code: string;
}

export interface Product {
  id: string;
  code: string;
  name: string;
  category: 'phone' | 'laptop' | 'console' | 'printer' | 'misc';
  categoryId?: string;
  brand: string;
  brandId?: string;
  model: string;
  modelId?: string;
  color?: string;
  ram?: string;
  storage?: string;
  buyPrice: number;
  sellPrice: number;
  stock: number;
  minStock: number;
  reorderPoint: number;
  allowNegativeStock: boolean;
  serialNumbers: string[];
  description?: string;
  createdAt: string;
}

export interface StockTransaction {
  id: string;
  productId: string;
  type: 'in' | 'out';
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  date: string;
  description?: string;
  relatedSaleId?: string;
}

export interface StockTransaction {
  id: string;
  productId: string;
  type: 'in' | 'out';
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  date: string;
  description?: string;
  relatedSaleId?: string;
}

export interface CustomerGroup {
  id: string;
  name: string;
  color: string;
  icon: string;
}

export interface Document {
  id: string;
  name: string;
  type: string;
  data: string; // base64
  date: string;
}

export interface Guarantor {
  id: string;
  name: string;
  phone: string;
  address?: string;
  job?: string;
  nationalId?: string;
  image?: string; // تصویر پروفایل ضامن
  documents: Document[];
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address?: string;
  nationalId?: string;
  job?: string;
  employeeId?: string;
  bankCardNumber?: string;
  city?: string;
  creditor?: number;
  debtor?: number;
  image?: string; // base64
  documents: Document[];
  groupId?: string;
  guarantor?: Guarantor;
  notes?: string;
  createdAt: string;
}

export interface Sale {
  id: string;
  productId: string;
  customerId: string;
  quantity: number;
  unitPrice: number;
  totalAmount: number;
  paymentType: 'cash' | 'installment';
  downPayment: number;
  installments?: Installment[];
  date: string;
  status: 'completed' | 'pending' | 'cancelled';
}

export interface Installment {
  id: string;
  amount: number;
  dueDate: string;
  paidDate?: string;
  status: 'pending' | 'paid' | 'overdue';
}

export interface Transaction {
  id: string;
  title: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  date: string;
  description?: string;
  relatedSaleId?: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
  type: 'income' | 'expense' | 'both';
}

export type FilterType = 'all' | 'income' | 'expense';
export type SortType = 'date-desc' | 'date-asc' | 'amount-desc' | 'amount-asc';

export interface Reminder {
  id: string;
  title: string;
  description?: string;
  date: string;
  time?: string;
  priority: 'low' | 'medium' | 'high';
  isDone: boolean;
  createdAt: string;
}

export interface DailyNote {
  id: string;
  title: string;
  content: string;
  date: string;
  createdAt: string;
}

// سیستم فاکتور
export type PaymentMethod = 'cash' | 'card' | 'check' | 'installment' | 'receipt' | 'credit' | 'mixed' | 'transfer';
export type InvoiceType = 'purchase' | 'sale' | 'return_purchase' | 'return_sale' | 'pre_invoice';

export interface InvoiceItem {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  buyPrice: number;
  sellPrice: number;
  discount: number;
  total: number;
}

export interface Payment {
  id: string;
  method: PaymentMethod;
  amount: number;
  date: string;
  checkId?: string;
  description?: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  type: InvoiceType;
  date: string;
  personId: string;
  personName: string;
  items: InvoiceItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  paid: number;
  remaining: number;
  payments: Payment[];
  status: 'pending' | 'partial' | 'completed' | 'cancelled';
  description?: string;
  createdAt: string;
}

// سیستم چک
export type CheckType = 'received' | 'paid';
export type CheckStatus = 'pending' | 'cleared' | 'bounced' | 'cancelled';

export interface Check {
  id: string;
  checkNumber: string;
  type: CheckType;
  amount: number;
  dueDate: string;
  issueDate: string;
  bankId: string;
  bankName: string;
  accountId?: string;
  personId: string;
  personName: string;
  invoiceId?: string;
  status: CheckStatus;
  description?: string;
  createdAt: string;
}

// سیستم بانک
export interface Bank {
  id: string;
  name: string;
  code: string;
}

export interface BankAccount {
  id: string;
  bankId: string;
  accountNumber: string;
  cardNumber: string;
  sheba: string;
  ownerName: string;
  balance: number;
  isActive: boolean;
}

// سیستم اقساط
export interface InstallmentPlan {
  id: string;
  invoiceId: string;
  personId: string;
  totalAmount: number;
  downPayment: number;
  remainingAmount: number;
  numberOfInstallments: number;
  installmentAmount: number;
  startDate: string;
  status: 'active' | 'completed' | 'defaulted';
  installments: InstallmentPayment[];
  createdAt: string;
}

export interface InstallmentPayment {
  id: string;
  planId: string;
  installmentNumber: number;
  amount: number;
  dueDate: string;
  paidDate?: string;
  status: 'pending' | 'paid' | 'overdue';
  paymentMethod?: PaymentMethod;
}
