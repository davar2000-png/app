import { useState } from 'react';
import { Customer, CustomerGroup, Document, Guarantor } from './types';
import { generateId, getTodayString } from './utils';
import SimpleImageUpload from './SimpleImageUpload';

interface CustomerEditFormProps {
  customer: Customer;
  groups: CustomerGroup[];
  onSave: (customer: Customer) => void;
  onCancel: () => void;
}

export default function CustomerEditForm({ customer, groups, onSave, onCancel }: CustomerEditFormProps) {
  const [name, setName] = useState(customer.name);
  const [phone, setPhone] = useState(customer.phone || '');
  const [address, setAddress] = useState(customer.address || '');
  const [nationalId, setNationalId] = useState(customer.nationalId || '');
  const [job, setJob] = useState(customer.job || '');
  const [employeeId, setEmployeeId] = useState(customer.employeeId || '');
  const [bankCardNumber, setBankCardNumber] = useState(customer.bankCardNumber || '');
  const [city, setCity] = useState(customer.city || '');
  const [creditor, setCreditor] = useState(customer.creditor || 0);
  const [debtor, setDebtor] = useState(customer.debtor || 0);
  const [groupId, setGroupId] = useState(customer.groupId || '');
  const [notes, setNotes] = useState(customer.notes || '');
  const [image, setImage] = useState(customer.image || '');
  
  // ضامن
  const [hasGuarantor, setHasGuarantor] = useState(!!customer.guarantor);
  const [guarantorName, setGuarantorName] = useState(customer.guarantor?.name || '');
  const [guarantorPhone, setGuarantorPhone] = useState(customer.guarantor?.phone || '');
  const [guarantorAddress, setGuarantorAddress] = useState(customer.guarantor?.address || '');
  const [guarantorJob, setGuarantorJob] = useState(customer.guarantor?.job || '');
  const [guarantorNationalId, setGuarantorNationalId] = useState(customer.guarantor?.nationalId || '');
  const [guarantorImage, setGuarantorImage] = useState(customer.guarantor?.image || '');
  const [guarantorDocuments, setGuarantorDocuments] = useState<Document[]>(customer.guarantor?.documents || []);

  // مدارک
  const [documents, setDocuments] = useState<Document[]>(customer.documents || []);

  const handleImageChange = (newImage: string) => {
    setImage(newImage);
  };

  const handleDocumentUpload = (e: React.ChangeEvent<HTMLInputElement>, isGuarantor: boolean = false) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const fileContent = ev.target?.result as string;
        const doc = Object.assign({} as Document, {
          id: generateId(),
          name: file.name,
          type: file.type,
          date: getTodayString(),
        });
        doc.data = fileContent;
        if (isGuarantor) {
          setGuarantorDocuments(prev => [...prev, doc]);
        } else {
          setDocuments(prev => [...prev, doc]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removeDocument = (id: string, isGuarantor: boolean = false) => {
    if (isGuarantor) {
      setGuarantorDocuments(prev => prev.filter(d => d.id !== id));
    } else {
      setDocuments(prev => prev.filter(d => d.id !== id));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;

    console.log('🔍 ذخیره شخص:', {
      name,
      hasImage: !!image,
      imageLength: image?.length || 0,
      hasGuarantor,
      guarantorDocuments: guarantorDocuments.length,
      documents: documents.length,
    });

    let guarantor: Guarantor | undefined;
    if (hasGuarantor && guarantorName) {
      guarantor = {
        id: customer.guarantor?.id || generateId(),
        name: guarantorName,
        phone: guarantorPhone,
        address: guarantorAddress,
        job: guarantorJob,
        nationalId: guarantorNationalId,
        image: guarantorImage,
        documents: guarantorDocuments,
      };
    }

    const updatedCustomer: Customer = {
      ...customer,
      name,
      phone,
      address,
      nationalId,
      job,
      employeeId,
      bankCardNumber,
      city,
      creditor,
      debtor,
      image,
      documents,
      groupId: groupId || undefined,
      guarantor,
      notes,
    };

    console.log('✅ شخص ذخیره شد:', {
      id: updatedCustomer.id,
      name: updatedCustomer.name,
      hasImage: !!updatedCustomer.image,
      imageLength: updatedCustomer.image?.length || 0,
    });

    onSave(updatedCustomer);
  };

  return (
    <div className="bg-slate-800/80 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50 shadow-xl animate-fadeIn">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">✏️ ویرایش شخص</h3>
        <button
          onClick={onCancel}
          className="text-slate-400 hover:text-white transition-colors w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-700"
        >
          ✕
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* تصویر و اطلاعات اصلی */}
        <div className="flex flex-col sm:flex-row gap-4">
          <SimpleImageUpload 
            currentImage={image} 
            onImageChange={(newImage) => {
              console.log('📸 تصویر تغییر کرد:', { hasImage: !!newImage, length: newImage?.length || 0 });
              handleImageChange(newImage);
            }}
          />

          {/* اطلاعات اصلی */}
          <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 text-sm mb-2">نام و نام خانوادگی *</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
                required
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-2">شماره تماس</label>
              <input
                type="tel"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-2">کد ملی</label>
              <input
                type="text"
                value={nationalId}
                onChange={e => setNationalId(e.target.value)}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-2">شغل</label>
              <input
                type="text"
                value={job}
                onChange={e => setJob(e.target.value)}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-2">شهر</label>
              <input
                type="text"
                value={city}
                onChange={e => setCity(e.target.value)}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-2">شماره کارمندی</label>
              <input
                type="text"
                value={employeeId}
                onChange={e => setEmployeeId(e.target.value)}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
              />
            </div>
          </div>
        </div>

        {/* آدرس */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">آدرس</label>
          <textarea
            value={address}
            onChange={e => setAddress(e.target.value)}
            rows={2}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all resize-none"
          />
        </div>

        {/* شماره کارت و مالی */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-slate-300 text-sm mb-2">شماره کارت بانکی</label>
            <input
              type="text"
              value={bankCardNumber}
              onChange={e => setBankCardNumber(e.target.value)}
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
            />
          </div>
          <div>
            <label className="block text-emerald-400 text-sm mb-2">بستانکار (تومان)</label>
            <input
              type="number"
              value={creditor}
              onChange={e => setCreditor(Number(e.target.value) || 0)}
              min="0"
              className="w-full bg-slate-700/50 border border-emerald-600/50 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500 transition-all"
            />
          </div>
          <div>
            <label className="block text-rose-400 text-sm mb-2">بدهکار (تومان)</label>
            <input
              type="number"
              value={debtor}
              onChange={e => setDebtor(Number(e.target.value) || 0)}
              min="0"
              className="w-full bg-slate-700/50 border border-rose-600/50 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-rose-500 transition-all"
            />
          </div>
        </div>

        {/* گروه‌بندی */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">گروه</label>
          <select
            value={groupId}
            onChange={e => setGroupId(e.target.value)}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
          >
            <option value="">بدون گروه</option>
            {groups.map(g => (
              <option key={g.id} value={g.id}>{g.icon} {g.name}</option>
            ))}
          </select>
        </div>

        {/* مدارک */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">مدارک</label>
          <div className="bg-slate-700/30 rounded-xl p-4">
            <label className="flex items-center justify-center gap-2 bg-slate-600/50 border border-dashed border-slate-500 rounded-xl p-3 cursor-pointer hover:bg-slate-600 transition-all">
              <span>📎</span>
              <span className="text-sm text-slate-300">افزودن مدرک جدید</span>
              <input
                type="file"
                multiple
                accept="image/*,.pdf,.doc,.docx"
                onChange={e => handleDocumentUpload(e, false)}
                className="hidden"
              />
            </label>
            {documents.length > 0 && (
              <div className="mt-3 space-y-2">
                {documents.map(doc => (
                  <div key={doc.id} className="flex items-center justify-between bg-slate-700/50 rounded-lg p-2">
                    <div className="flex items-center gap-2">
                      <span>{doc.type.includes('image') ? '🖼️' : '📄'}</span>
                      <span className="text-sm text-slate-300 truncate max-w-[200px]">{doc.name}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeDocument(doc.id, false)}
                      className="text-rose-400 hover:text-rose-300 text-sm"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ضامن */}
        <div className="border border-slate-600 rounded-xl overflow-hidden">
          <button
            type="button"
            onClick={() => setHasGuarantor(!hasGuarantor)}
            className={`w-full py-3 px-4 flex items-center justify-between transition-all ${
              hasGuarantor ? 'bg-amber-600/20 text-amber-400' : 'bg-slate-700/30 text-slate-300'
            }`}
          >
            <span className="flex items-center gap-2">
              <span>🛡️</span>
              <span className="font-medium">ضامن</span>
            </span>
            <span>{hasGuarantor ? '▼' : '◀'}</span>
          </button>

          {hasGuarantor && (
            <div className="p-4 space-y-3 bg-slate-700/20">
              {/* تصویر و اطلاعات ضامن */}
              <div className="flex flex-col sm:flex-row gap-4">
                <SimpleImageUpload 
                  currentImage={guarantorImage} 
                  onImageChange={setGuarantorImage} 
                />
                <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 text-sm mb-2">نام ضامن</label>
                    <input
                      type="text"
                      value={guarantorName}
                      onChange={e => setGuarantorName(e.target.value)}
                      className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 text-sm mb-2">تلفن ضامن</label>
                    <input
                      type="tel"
                      value={guarantorPhone}
                      onChange={e => setGuarantorPhone(e.target.value)}
                      className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 text-sm mb-2">شغل ضامن</label>
                    <input
                      type="text"
                      value={guarantorJob}
                      onChange={e => setGuarantorJob(e.target.value)}
                      className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 text-sm mb-2">کد ملی ضامن</label>
                    <input
                      type="text"
                      value={guarantorNationalId}
                      onChange={e => setGuarantorNationalId(e.target.value)}
                      className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-all"
                    />
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-slate-300 text-sm mb-2">آدرس ضامن</label>
                <textarea
                  value={guarantorAddress}
                  onChange={e => setGuarantorAddress(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition-all resize-none"
                />
              </div>
              {/* مدارک ضامن */}
              <div>
                <label className="block text-slate-300 text-sm mb-2">مدارک ضامن</label>
                <label className="flex items-center justify-center gap-2 bg-slate-600/50 border border-dashed border-amber-500/50 rounded-xl p-3 cursor-pointer hover:bg-slate-600 transition-all">
                  <span>📎</span>
                  <span className="text-sm text-slate-300">افزودن مدرک ضامن</span>
                  <input
                    type="file"
                    multiple
                    accept="image/*,.pdf,.doc,.docx"
                    onChange={e => handleDocumentUpload(e, true)}
                    className="hidden"
                  />
                </label>
                {guarantorDocuments.length > 0 && (
                  <div className="mt-3 space-y-2">
                    {guarantorDocuments.map(doc => (
                      <div key={doc.id} className="flex items-center justify-between bg-slate-700/50 rounded-lg p-2">
                        <div className="flex items-center gap-2">
                          <span>{doc.type.includes('image') ? '🖼️' : '📄'}</span>
                          <span className="text-sm text-slate-300 truncate max-w-[200px]">{doc.name}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeDocument(doc.id, true)}
                          className="text-rose-400 hover:text-rose-300 text-sm"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* یادداشت */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">یادداشت</label>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            rows={2}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all resize-none"
          />
        </div>

        {/* دکمه‌ها */}
        <div className="flex gap-3">
          <button
            type="submit"
            className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-700 py-3 rounded-xl font-bold text-white shadow-lg shadow-blue-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all"
          >
            ✓ ذخیره تغییرات
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="px-6 bg-slate-700 text-white py-3 rounded-xl font-bold hover:bg-slate-600 transition-all"
          >
            انصراف
          </button>
        </div>
      </form>
    </div>
  );
}
