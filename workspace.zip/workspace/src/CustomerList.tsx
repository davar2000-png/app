import { useState } from 'react';
import { Customer, CustomerGroup, Sale, Document } from './types';
import { formatDate, isOverdue } from './utils';
import CustomerEditForm from './CustomerEditForm';

interface CustomerListProps {
  customers: Customer[];
  sales: Sale[];
  groups: CustomerGroup[];
  onDelete: (id: string) => void;
  onUpdate: (customer: Customer) => void;
}

export default function CustomerList({ customers, sales, groups, onDelete, onUpdate }: CustomerListProps) {
  const [search, setSearch] = useState('');
  const [filterGroup, setFilterGroup] = useState('');
  const [filterHasGuarantor, setFilterHasGuarantor] = useState<'all' | 'yes' | 'no'>('all');
  const [filterHasDebt, setFilterHasDebt] = useState<'all' | 'yes' | 'no'>('all');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [viewingDoc, setViewingDoc] = useState<Document | null>(null);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [viewingImage, setViewingImage] = useState<string | null>(null);

  // فیلتر پیشرفته
  let filtered = [...customers];

  if (search) {
    const s = search.toLowerCase();
    filtered = filtered.filter(c =>
      c.name.toLowerCase().includes(s) ||
      c.phone.includes(s) ||
      c.nationalId?.includes(s) ||
      c.job?.toLowerCase().includes(s) ||
      c.employeeId?.includes(s) ||
      c.address?.toLowerCase().includes(s) ||
      c.notes?.toLowerCase().includes(s) ||
      c.guarantor?.name.toLowerCase().includes(s) ||
      c.guarantor?.phone.includes(s)
    );
  }

  if (filterGroup) {
    filtered = filtered.filter(c => c.groupId === filterGroup);
  }

  if (filterHasGuarantor === 'yes') {
    filtered = filtered.filter(c => c.guarantor);
  } else if (filterHasGuarantor === 'no') {
    filtered = filtered.filter(c => !c.guarantor);
  }

  if (filterHasDebt === 'yes') {
    filtered = filtered.filter(c => {
      const customerSales = sales.filter(s => s.customerId === c.id);
      return customerSales.some(s =>
        s.paymentType === 'installment' &&
        s.installments?.some(i => i.status === 'pending')
      );
    });
  } else if (filterHasDebt === 'no') {
    filtered = filtered.filter(c => {
      const customerSales = sales.filter(s => s.customerId === c.id);
      return !customerSales.some(s =>
        s.paymentType === 'installment' &&
        s.installments?.some(i => i.status === 'pending')
      );
    });
  }

  const getCustomerDebt = (customerId: string) => {
    return sales
      .filter(s => s.customerId === customerId && s.paymentType === 'installment' && s.installments)
      .flatMap(s => s.installments!.filter(i => i.status === 'pending'))
      .reduce((sum, i) => sum + i.amount, 0);
  };

  const getCustomerPurchaseCount = (customerId: string) => {
    return sales.filter(s => s.customerId === customerId && s.status === 'completed').length;
  };

  const getGroupById = (id?: string) => groups.find(g => g.id === id);

  if (customers.length === 0) {
    return (
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-10 text-center">
        <span className="text-4xl block mb-3">👥</span>
        <p className="text-slate-400">هنوز شخصی ثبت نشده</p>
      </div>
    );
  }

  return (
    <>
      {/* جستجوی پیشرفته */}
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-5 mb-4">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          🔍 جستجوی پیشرفته
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* جستجوی متنی */}
          <div>
            <label className="block text-slate-400 text-xs mb-1">جستجو</label>
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="نام، تلفن، کد ملی، شغل..."
              className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
            />
          </div>

          {/* فیلتر گروه */}
          <div>
            <label className="block text-slate-400 text-xs mb-1">گروه</label>
            <select
              value={filterGroup}
              onChange={e => setFilterGroup(e.target.value)}
              className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500 transition-all"
            >
              <option value="">همه گروه‌ها</option>
              {groups.map(g => (
                <option key={g.id} value={g.id}>{g.icon} {g.name}</option>
              ))}
            </select>
          </div>

          {/* فیلتر ضامن */}
          <div>
            <label className="block text-slate-400 text-xs mb-1">ضامن</label>
            <select
              value={filterHasGuarantor}
              onChange={e => setFilterHasGuarantor(e.target.value as any)}
              className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500 transition-all"
            >
              <option value="all">همه</option>
              <option value="yes">دارای ضامن</option>
              <option value="no">بدون ضامن</option>
            </select>
          </div>

          {/* فیلتر بدهی */}
          <div>
            <label className="block text-slate-400 text-xs mb-1">وضعیت بدهی</label>
            <select
              value={filterHasDebt}
              onChange={e => setFilterHasDebt(e.target.value as any)}
              className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500 transition-all"
            >
              <option value="all">همه</option>
              <option value="yes">دارای بدهی</option>
              <option value="no">بدون بدهی</option>
            </select>
          </div>
        </div>

        <div className="mt-3 flex items-center justify-between">
          <p className="text-sm text-slate-400">{filtered.length} نفر از {customers.length} نفر</p>
          {(search || filterGroup || filterHasGuarantor !== 'all' || filterHasDebt !== 'all') && (
            <button
              onClick={() => { setSearch(''); setFilterGroup(''); setFilterHasGuarantor('all'); setFilterHasDebt('all'); }}
              className="text-xs text-blue-400 hover:text-blue-300"
            >
              پاک کردن فیلترها ✕
            </button>
          )}
        </div>
      </div>

      {/* لیست اشخاص */}
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 overflow-hidden">
        <div className="p-5 border-b border-slate-700/50">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            👥 لیست اشخاص
            <span className="text-sm text-slate-400 font-normal">({filtered.length} نفر)</span>
          </h3>
        </div>

        <div className="divide-y divide-slate-700/50 max-h-[600px] overflow-y-auto">
          {filtered.length === 0 ? (
            <div className="p-10 text-center text-slate-500">
              <span className="text-3xl block mb-2">🔍</span>
              <p>نتیجه‌ای یافت نشد</p>
            </div>
          ) : (
            filtered.map((customer, index) => {
              const debt = getCustomerDebt(customer.id);
              const purchaseCount = getCustomerPurchaseCount(customer.id);
              const group = getGroupById(customer.groupId);

              return (
                <div
                  key={customer.id}
                  className="p-4 hover:bg-slate-700/20 transition-all animate-slideIn group cursor-pointer"
                  style={{ animationDelay: `${index * 0.03}s` }}
                  onClick={() => setSelectedCustomer(customer)}
                >
                  <div className="flex items-center gap-3">
                    {/* تصویر */}
                    <div className="shrink-0">
                      {customer.image ? (
                        <img 
                          src={customer.image} 
                          alt={customer.name} 
                          className="w-20 h-14 rounded-xl object-cover border-2 border-blue-500/30 cursor-pointer hover:scale-110 transition-transform"
                          onClick={(e) => {
                            e.stopPropagation();
                            setViewingImage(customer.image || null);
                          }}
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                            e.currentTarget.nextElementSibling?.classList.remove('hidden');
                          }}
                        />
                      ) : null}
                      <div className={`${customer.image ? 'hidden' : ''} w-20 h-14 bg-blue-500/20 rounded-xl flex items-center justify-center text-xl`}>
                        👤
                      </div>
                    </div>

                    {/* اطلاعات */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-white font-medium">{customer.name}</h4>
                        {group && (
                          <span
                            className="text-[10px] px-2 py-0.5 rounded-full"
                            style={{ backgroundColor: `${group.color}20`, color: group.color }}
                          >
                            {group.icon} {group.name}
                          </span>
                        )}
                        {customer.guarantor && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400">
                            🛡️ ضامن دارد
                          </span>
                        )}
                        {customer.documents.length > 0 && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400">
                            📎 {customer.documents.length} مدرک
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 flex-wrap">
                        {customer.phone && <span>📞 {customer.phone}</span>}
                        {customer.job && <span>💼 {customer.job}</span>}
                        {customer.city && <span>🏙️ {customer.city}</span>}
                        {customer.nationalId && <span>🆔 {customer.nationalId}</span>}
                      </div>
                    </div>

                    {/* آمار */}
                    <div className="flex items-center gap-4 shrink-0">
                      <div className="text-left hidden sm:block">
                        <p className="text-xs text-slate-400">خریدها</p>
                        <p className="text-sm text-white font-bold">{purchaseCount}</p>
                      </div>
                      {debt > 0 && (
                        <div className="text-left">
                          <p className="text-xs text-rose-400">بدهی</p>
                          <p className="text-sm text-rose-400 font-bold">{debt.toLocaleString('fa-IR')}</p>
                        </div>
                      )}
                      <button
                        onClick={(e) => { e.stopPropagation(); onDelete(customer.id); }}
                        className="opacity-0 group-hover:opacity-100 text-rose-400 hover:text-rose-300 transition-all"
                        title="حذف"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* مودال جزئیات شخص */}
      {selectedCustomer && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setSelectedCustomer(null)}>
          <div className="bg-slate-800 rounded-2xl p-6 max-w-3xl w-full max-h-[90vh] overflow-y-auto border border-slate-700" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">مشخصات شخص</h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => { setEditingCustomer(selectedCustomer); setSelectedCustomer(null); }}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700 transition-all flex items-center gap-2"
                >
                  <span>✏️</span>
                  <span>ویرایش</span>
                </button>
                <button
                  onClick={() => setSelectedCustomer(null)}
                  className="text-slate-400 hover:text-white w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-700"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="space-y-6">
              {/* اطلاعات اصلی */}
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
                {selectedCustomer.image ? (
                  <div className="shrink-0">
                    <img 
                      src={selectedCustomer.image} 
                      alt={selectedCustomer.name} 
                      className="w-48 h-32 rounded-2xl object-cover border-4 border-blue-500/30 shadow-lg cursor-pointer hover:scale-105 transition-transform"
                      onClick={() => setViewingImage(selectedCustomer.image || null)}
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.nextElementSibling?.classList.remove('hidden');
                      }}
                    />
                    <div className="hidden w-48 h-32 rounded-2xl bg-blue-500/20 flex items-center justify-center text-5xl border-4 border-blue-500/30">
                      👤
                    </div>
                  </div>
                ) : (
                  <div className="w-48 h-32 bg-blue-500/20 rounded-2xl flex items-center justify-center text-5xl border-4 border-blue-500/30">
                    👤
                  </div>
                )}
                <div className="flex-1 text-center sm:text-right">
                  <h4 className="text-2xl text-white font-bold">{selectedCustomer.name}</h4>
                  <div className="grid grid-cols-2 gap-2 mt-3 text-sm">
                    {selectedCustomer.phone && <div><span className="text-slate-400">تلفن:</span> <span className="text-white">{selectedCustomer.phone}</span></div>}
                    {selectedCustomer.nationalId && <div><span className="text-slate-400">کد ملی:</span> <span className="text-white">{selectedCustomer.nationalId}</span></div>}
                    {selectedCustomer.job && <div><span className="text-slate-400">شغل:</span> <span className="text-white">{selectedCustomer.job}</span></div>}
                    {selectedCustomer.city && <div><span className="text-slate-400">شهر:</span> <span className="text-white">{selectedCustomer.city}</span></div>}
                    {selectedCustomer.employeeId && <div><span className="text-slate-400">شماره کارمندی:</span> <span className="text-white">{selectedCustomer.employeeId}</span></div>}
                    {selectedCustomer.bankCardNumber && <div><span className="text-slate-400">کارت بانکی:</span> <span className="text-white">{selectedCustomer.bankCardNumber}</span></div>}
                    {selectedCustomer.address && <div className="col-span-2"><span className="text-slate-400">آدرس:</span> <span className="text-white">{selectedCustomer.address}</span></div>}
                    {(selectedCustomer.creditor || selectedCustomer.debtor) && (
                      <div className="col-span-2 flex gap-4 mt-2">
                        {selectedCustomer.creditor ? (
                          <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg px-3 py-2">
                            <span className="text-emerald-400 text-xs">بستانکار: </span>
                            <span className="text-emerald-300 font-bold">{Number(selectedCustomer.creditor).toLocaleString('fa-IR')}</span>
                          </div>
                        ) : null}
                        {selectedCustomer.debtor ? (
                          <div className="bg-rose-500/10 border border-rose-500/30 rounded-lg px-3 py-2">
                            <span className="text-rose-400 text-xs">بدهکار: </span>
                            <span className="text-rose-300 font-bold">{Number(selectedCustomer.debtor).toLocaleString('fa-IR')}</span>
                          </div>
                        ) : null}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* گروه */}
              {selectedCustomer.groupId && (() => {
                const group = getGroupById(selectedCustomer.groupId);
                if (!group) return null;
                return (
                  <div className="bg-slate-700/30 rounded-xl p-3">
                    <span className="text-slate-400 text-sm">گروه: </span>
                    <span className="text-white">{group.icon} {group.name}</span>
                  </div>
                );
              })()}

              {/* آمار */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-700/30 rounded-xl p-3 text-center">
                  <p className="text-slate-400 text-xs">تاریخ ثبت</p>
                  <p className="text-white text-sm font-bold mt-1">{formatDate(selectedCustomer.createdAt)}</p>
                </div>
                <div className="bg-slate-700/30 rounded-xl p-3 text-center">
                  <p className="text-slate-400 text-xs">تعداد خرید</p>
                  <p className="text-white text-sm font-bold mt-1">{getCustomerPurchaseCount(selectedCustomer.id)}</p>
                </div>
                <div className="bg-slate-700/30 rounded-xl p-3 text-center">
                  <p className="text-slate-400 text-xs">بدهی</p>
                  <p className={`text-sm font-bold mt-1 ${getCustomerDebt(selectedCustomer.id) > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {getCustomerDebt(selectedCustomer.id) > 0 ? getCustomerDebt(selectedCustomer.id).toLocaleString('fa-IR') : 'ندارد'}
                  </p>
                </div>
              </div>

              {/* مدارک */}
              {selectedCustomer.documents.length > 0 && (
                <div>
                  <h4 className="text-white font-bold mb-3 flex items-center gap-2">📎 مدارک</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {selectedCustomer.documents.map(doc => (
                      <div
                        key={doc.id}
                        onClick={() => setViewingDoc(doc)}
                        className="bg-slate-700/30 rounded-xl p-3 cursor-pointer hover:bg-slate-700/50 transition-all"
                      >
                        {doc.type.includes('image') ? (
                          <img src={doc.data} alt={doc.name} className="w-full h-20 object-cover rounded-lg mb-2" />
                        ) : (
                          <div className="w-full h-20 bg-slate-600/50 rounded-lg mb-2 flex items-center justify-center text-2xl">
                            📄
                          </div>
                        )}
                        <p className="text-xs text-slate-300 truncate">{doc.name}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ضامن */}
              {selectedCustomer.guarantor && (
                <div className="border border-amber-500/30 rounded-xl p-4 bg-amber-500/5">
                  <h4 className="text-amber-400 font-bold mb-3 flex items-center gap-2">🛡️ مشخصات ضامن</h4>
                  
                  {/* تصویر ضامن */}
                  <div className="flex items-start gap-4 mb-4">
                    {selectedCustomer.guarantor.image ? (
                      <img 
                        src={selectedCustomer.guarantor.image} 
                        alt={selectedCustomer.guarantor.name} 
                        className="w-24 h-16 rounded-lg object-cover border-2 border-amber-500/30 cursor-pointer hover:scale-105 transition-transform"
                        onClick={() => setViewingImage(selectedCustomer.guarantor!.image || null)}
                      />
                    ) : (
                      <div className="w-24 h-16 bg-amber-500/20 rounded-lg flex items-center justify-center text-2xl border-2 border-amber-500/30">
                        🛡️
                      </div>
                    )}
                    <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                      <div><span className="text-slate-400">نام:</span> <span className="text-white">{selectedCustomer.guarantor.name}</span></div>
                      <div><span className="text-slate-400">تلفن:</span> <span className="text-white">{selectedCustomer.guarantor.phone}</span></div>
                      {selectedCustomer.guarantor.job && <div><span className="text-slate-400">شغل:</span> <span className="text-white">{selectedCustomer.guarantor.job}</span></div>}
                      {selectedCustomer.guarantor.nationalId && <div><span className="text-slate-400">کد ملی:</span> <span className="text-white">{selectedCustomer.guarantor.nationalId}</span></div>}
                      {selectedCustomer.guarantor.address && <div className="col-span-2"><span className="text-slate-400">آدرس:</span> <span className="text-white">{selectedCustomer.guarantor.address}</span></div>}
                    </div>
                  </div>
                  
                  {/* مدارک ضامن */}
                  {selectedCustomer.guarantor.documents.length > 0 && (
                    <div className="mt-3">
                      <p className="text-slate-400 text-xs mb-2">مدارک ضامن:</p>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {selectedCustomer.guarantor.documents.map(doc => (
                          <div
                            key={doc.id}
                            onClick={() => setViewingDoc(doc)}
                            className="bg-slate-700/30 rounded-lg p-2 cursor-pointer hover:bg-slate-700/50 transition-all"
                          >
                            {doc.type.includes('image') ? (
                              <img src={doc.data} alt={doc.name} className="w-full h-16 object-cover rounded mb-1" />
                            ) : (
                              <div className="w-full h-16 bg-slate-600/50 rounded flex items-center justify-center text-xl mb-1">📄</div>
                            )}
                            <p className="text-[10px] text-slate-300 truncate">{doc.name}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* یادداشت */}
              {selectedCustomer.notes && (
                <div className="bg-slate-700/30 rounded-xl p-3">
                  <p className="text-slate-400 text-xs mb-1">یادداشت:</p>
                  <p className="text-white text-sm">{selectedCustomer.notes}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* مودال مشاهده مدرک */}
      {viewingDoc && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-[60] p-4" onClick={() => setViewingDoc(null)}>
          <div className="max-w-4xl max-h-[90vh] w-full" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-white font-bold">{viewingDoc.name}</h4>
              <button
                onClick={() => setViewingDoc(null)}
                className="text-white bg-slate-700 w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-600"
              >
                ✕
              </button>
            </div>
            {viewingDoc.type.includes('image') ? (
              <img src={viewingDoc.data} alt={viewingDoc.name} className="w-full max-h-[80vh] object-contain rounded-xl" />
            ) : (
              <iframe src={viewingDoc.data} className="w-full h-[80vh] rounded-xl bg-white" />
            )}
          </div>
        </div>
      )}

      {/* مودال ویرایش شخص */}
      {editingCustomer && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-[60] p-4 overflow-y-auto">
          <div className="max-w-4xl w-full my-8" onClick={e => e.stopPropagation()}>
            <CustomerEditForm
              customer={editingCustomer}
              groups={groups}
              onSave={(updatedCustomer) => {
                onUpdate(updatedCustomer);
                setEditingCustomer(null);
              }}
              onCancel={() => setEditingCustomer(null)}
            />
          </div>
        </div>
      )}

      {/* مودال بزرگ‌نمایی تصویر */}
      {viewingImage && (
        <div 
          className="fixed inset-0 bg-black/95 flex items-center justify-center z-[70] p-4"
          onClick={() => setViewingImage(null)}
        >
          <div className="relative" onClick={e => e.stopPropagation()}>
            <button
              onClick={() => setViewingImage(null)}
              className="absolute -top-12 right-0 bg-white/20 hover:bg-white/30 text-white w-10 h-10 rounded-full flex items-center justify-center transition-all text-lg z-10"
            >
              ✕
            </button>
            <img 
              src={viewingImage} 
              alt="تصویر بزرگ" 
              className="block max-w-[90vw] max-h-[85vh] object-contain"
              style={{ width: 'auto', height: 'auto' }}
            />
          </div>
        </div>
      )}
    </>
  );
}
