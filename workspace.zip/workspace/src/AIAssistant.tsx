import { useState, useEffect } from 'react';
import { Product, Customer, Invoice, Check, InstallmentPlan } from './types';
import { formatNumber, formatJalaliDate, isOverdue, daysUntilDue } from './utils';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AIAssistantProps {
  products: Product[];
  customers: Customer[];
  invoices: Invoice[];
  checks: Check[];
  installmentPlans: InstallmentPlan[];
}

export default function AIAssistant({
  products,
  customers,
  invoices,
  checks,
  installmentPlans,
}: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'سلام! من دستیار هوش مصنوعی فروشگاه شما هستم. می‌توانم در موارد زیر به شما کمک کنم:\n\n📊 گزارش‌گیری و تحلیل\n💰 تحلیل فروش و خرید\n📦 وضعیت کالاها و موجودی\n👥 تحلیل مشتریان\n📄 بررسی فاکتورها\n💳 تحلیل چک‌ها و اقساط\n\nچه کمکی از دست من برمی‌آید؟',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // توابع تحلیلی
  const analyzeSales = () => {
    const today = new Date().toISOString().split('T')[0];
    const todayInvoices = invoices.filter(inv => inv.date === today && inv.type === 'sale');
    const todaySales = todayInvoices.reduce((sum, inv) => sum + inv.total, 0);
    const todayProfit = todayInvoices.reduce((sum, inv) => {
      return sum + inv.items.reduce((itemSum, item) => {
        return itemSum + ((item.sellPrice - item.buyPrice) * item.quantity);
      }, 0);
    }, 0);

    const thisMonth = new Date().getMonth();
    const thisYear = new Date().getFullYear();
    const monthInvoices = invoices.filter(inv => {
      const d = new Date(inv.date);
      return d.getMonth() === thisMonth && d.getFullYear() === thisYear && inv.type === 'sale';
    });
    const monthSales = monthInvoices.reduce((sum, inv) => sum + inv.total, 0);

    return `📊 **گزارش فروش:**\n\n💰 فروش امروز: ${formatNumber(todaySales)} تومان\n📈 سود امروز: ${formatNumber(todayProfit)} تومان\n📅 تعداد فاکتور امروز: ${todayInvoices.length}\n\n💼 فروش این ماه: ${formatNumber(monthSales)} تومان\n📄 تعداد فاکتور این ماه: ${monthInvoices.length}\n📊 میانگین فاکتور: ${formatNumber(monthInvoices.length > 0 ? Math.round(monthSales / monthInvoices.length) : 0)} تومان`;
  };

  const analyzeProducts = () => {
    const totalProducts = products.length;
    const totalStock = products.reduce((sum, p) => sum + p.stock, 0);
    const totalValue = products.reduce((sum, p) => sum + (p.sellPrice * p.stock), 0);
    const lowStock = products.filter(p => p.stock <= p.minStock);
    const outOfStock = products.filter(p => p.stock === 0);

    return `📦 **گزارش کالاها:**\n\n📊 تعداد کل کالاها: ${totalProducts}\n📦 مجموع موجودی: ${totalStock} عدد\n💰 ارزش کل انبار: ${formatNumber(totalValue)} تومان\n\n⚠️ کالاهای کم‌موجود: ${lowStock.length}\n❌ کالاهای ناموجود: ${outOfStock.length}\n\n${lowStock.length > 0 ? `🔴 لیست کالاهای کم‌موجود:\n${lowStock.slice(0, 5).map(p => `• ${p.name}: ${p.stock} عدد`).join('\n')}` : ''}`;
  };

  const analyzeCustomers = () => {
    const totalCustomers = customers.length;
    const totalDebt = invoices.reduce((sum, inv) => sum + inv.remaining, 0);
    const customersWithDebt = new Set(invoices.filter(inv => inv.remaining > 0).map(inv => inv.personId)).size;

    const topCustomers = customers
      .map(c => ({
        customer: c,
        totalPurchase: invoices.filter(inv => inv.personId === c.id && inv.type === 'sale').reduce((sum, inv) => sum + inv.total, 0),
      }))
      .sort((a, b) => b.totalPurchase - a.totalPurchase)
      .slice(0, 5);

    return `👥 **گزارش مشتریان:**\n\n👤 تعداد کل مشتریان: ${totalCustomers}\n💳 مشتریان دارای بدهی: ${customersWithDebt}\n💰 مجموع بدهی‌ها: ${formatNumber(totalDebt)} تومان\n\n🏆 5 مشتری برتر:\n${topCustomers.map((c, i) => `${i + 1}. ${c.customer.name}: ${formatNumber(c.totalPurchase)} تومان`).join('\n')}`;
  };

  const analyzeChecks = () => {
    const totalChecks = checks.length;
    const pendingChecks = checks.filter(c => c.status === 'pending');
    const overdueChecks = pendingChecks.filter(c => isOverdue(c.dueDate));
    const upcomingChecks = pendingChecks.filter(c => !isOverdue(c.dueDate) && daysUntilDue(c.dueDate) <= 7);

    const receivedChecks = checks.filter(c => c.type === 'received');
    const paidChecks = checks.filter(c => c.type === 'paid');

    return `💳 **گزارش چک‌ها:**\n\n📊 تعداد کل چک‌ها: ${totalChecks}\n⏳ چک‌های در انتظار: ${pendingChecks.length}\n\n📥 چک‌های دریافتی: ${receivedChecks.length}\n📤 چک‌های پرداختی: ${paidChecks.length}\n\n🔴 چک‌های سررسید شده: ${overdueChecks.length}\n🟡 چک‌های نزدیک سررسید (7 روز): ${upcomingChecks.length}\n\n${overdueChecks.length > 0 ? `⚠️ چک‌های سررسید شده:\n${overdueChecks.slice(0, 3).map(c => `• چک ${c.checkNumber}: ${formatNumber(c.amount)} تومان - سررسید: ${formatJalaliDate(c.dueDate)}`).join('\n')}` : ''}`;
  };

  const analyzeInstallments = () => {
    const totalPlans = installmentPlans.length;
    const activePlans = installmentPlans.filter(p => p.status === 'active');
    const totalRemaining = activePlans.reduce((sum, p) => sum + p.remainingAmount, 0);

    const overdueInstallments = installmentPlans
      .flatMap(p => p.installments)
      .filter(i => i.status === 'pending' && isOverdue(i.dueDate));
    const overdueAmount = overdueInstallments.reduce((sum, i) => sum + i.amount, 0);

    return `📅 **گزارش اقساط:**\n\n📊 تعداد کل اقساط: ${totalPlans}\n✅ اقساط فعال: ${activePlans.length}\n💰 مجموع باقیمانده: ${formatNumber(totalRemaining)} تومان\n\n🔴 اقساط سررسید شده: ${overdueInstallments.length}\n💸 مبلغ معوق: ${formatNumber(overdueAmount)} تومان\n\n${overdueInstallments.length > 0 ? `⚠️ اقساط سررسید شده:\n${overdueInstallments.slice(0, 3).map(i => `• قسط شماره ${i.installmentNumber}: ${formatNumber(i.amount)} تومان - سررسید: ${formatJalaliDate(i.dueDate)}`).join('\n')}` : ''}`;
  };

  const generateResponse = (userMessage: string): string => {
    const msg = userMessage.toLowerCase();

    if (msg.includes('فروش') || msg.includes('sale')) {
      return analyzeSales();
    }
    if (msg.includes('کالا') || msg.includes('محصول') || msg.includes('موجودی')) {
      return analyzeProducts();
    }
    if (msg.includes('مشتری') || msg.includes('customer')) {
      return analyzeCustomers();
    }
    if (msg.includes('چک') || msg.includes('check')) {
      return analyzeChecks();
    }
    if (msg.includes('قسط') || msg.includes('installment')) {
      return analyzeInstallments();
    }
    if (msg.includes('گزارش') || msg.includes('report') || msg.includes('تحلیل')) {
      return `📊 **گزارش کامل فروشگاه:**\n\n${analyzeSales()}\n\n---\n\n${analyzeProducts()}\n\n---\n\n${analyzeCustomers()}`;
    }
    if (msg.includes('بدهی') || msg.includes('debt')) {
      const totalDebt = invoices.reduce((sum, inv) => sum + inv.remaining, 0);
      const debtors = new Set(invoices.filter(inv => inv.remaining > 0).map(inv => inv.personId)).size;
      return `💳 **گزارش بدهی‌ها:**\n\n💰 مجموع بدهی‌ها: ${formatNumber(totalDebt)} تومان\n👤 تعداد بدهکاران: ${debtors}\n\n⚠️ برای مشاهده جزئیات، به بخش فاکتورها مراجعه کنید.`;
    }
    if (msg.includes('سود') || msg.includes('profit')) {
      const totalProfit = invoices
        .filter(inv => inv.type === 'sale')
        .reduce((sum, inv) => {
          return sum + inv.items.reduce((itemSum, item) => {
            return itemSum + ((item.sellPrice - item.buyPrice) * item.quantity);
          }, 0);
        }, 0);
      return `📈 **گزارش سود:**\n\n💰 مجموع سود کل: ${formatNumber(totalProfit)} تومان\n\n📊 برای مشاهده سود روزانه/ماهانه، از بخش گزارش‌ها استفاده کنید.`;
    }
    if (msg.includes('کمک') || msg.includes('help') || msg.includes('چه کار')) {
      return `🤖 **من می‌توانم در موارد زیر به شما کمک کنم:**\n\n📊 **گزارش‌گیری:**\n• "گزارش فروش" - تحلیل فروش امروز و ماه\n• "گزارش کالا" - وضعیت موجودی کالاها\n• "گزارش مشتری" - تحلیل مشتریان\n• "گزارش چک" - وضعیت چک‌ها\n• "گزارش قسط" - وضعیت اقساط\n• "گزارش کامل" - گزارش جامع\n\n💰 **تحلیل مالی:**\n• "سود" - محاسبه سود\n• "بدهی" - وضعیت بدهی‌ها\n\n🔍 **جستجو:**\n• می‌توانید درباره هر موضوعی سوال بپرسید\n\nچه کمکی نیاز دارید؟`;
    }

    return `متوجه شدم. من می‌توانم در موارد زیر به شما کمک کنم:\n\n📊 گزارش فروش\n📦 گزارش کالاها\n👥 گزارش مشتریان\n💳 گزارش چک‌ها\n📅 گزارش اقساط\n💰 تحلیل سود و بدهی\n\nلطفاً یکی از این موارد را انتخاب کنید یا سوال خود را واضح‌تر بپرسید.`;
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    // شبیه‌سازی تاخیر پردازش
    setTimeout(() => {
      const response = generateResponse(input);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMessage]);
      setIsLoading(false);
    }, 500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const quickActions = [
    { label: '📊 گزارش فروش', query: 'گزارش فروش' },
    { label: '📦 گزارش کالا', query: 'گزارش کالا' },
    { label: '👥 گزارش مشتری', query: 'گزارش مشتری' },
    { label: '💳 گزارش چک', query: 'گزارش چک' },
    { label: '📅 گزارش قسط', query: 'گزارش قسط' },
    { label: '💰 سود', query: 'سود' },
  ];

  return (
    <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 flex flex-col h-[600px]">
      {/* هدر */}
      <div className="p-4 border-b border-slate-700/50 flex items-center gap-3">
        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-violet-600 rounded-xl flex items-center justify-center text-xl">
          🤖
        </div>
        <div>
          <h3 className="text-white font-bold">دستیار هوش مصنوعی</h3>
          <p className="text-slate-400 text-xs">تحلیل و گزارش‌گیری هوشمند</p>
        </div>
      </div>

      {/* پیام‌ها */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map(message => (
          <div
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                message.role === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-700/50 text-slate-100'
              }`}
            >
              <div className="whitespace-pre-wrap text-sm">{message.content}</div>
              <div className={`text-xs mt-1 ${message.role === 'user' ? 'text-blue-200' : 'text-slate-400'}`}>
                {message.timestamp.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-slate-700/50 rounded-2xl px-4 py-3">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* دکمه‌های سریع */}
      <div className="px-4 py-2 border-t border-slate-700/50">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {quickActions.map((action, i) => (
            <button
              key={i}
              onClick={() => {
                setInput(action.query);
                setTimeout(handleSend, 100);
              }}
              className="px-3 py-1.5 bg-slate-700/50 hover:bg-slate-600/50 text-slate-300 rounded-lg text-xs whitespace-nowrap transition-all"
            >
              {action.label}
            </button>
          ))}
        </div>
      </div>

      {/* ورودی */}
      <div className="p-4 border-t border-slate-700/50">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="سوال خود را بنویسید..."
            className="flex-1 bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            disabled={isLoading}
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="px-6 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            ارسال
          </button>
        </div>
      </div>
    </div>
  );
}
