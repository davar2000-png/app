import { useState, useRef, useEffect } from 'react';

interface SimpleImageUploadProps {
  currentImage: string;
  onImageChange: (image: string) => void;
}

export default function SimpleImageUpload({ currentImage, onImageChange }: SimpleImageUploadProps) {
  const [preview, setPreview] = useState<string>(currentImage);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // به‌روزرسانی preview وقتی currentImage از parent تغییر می‌کند
  useEffect(() => {
    setPreview(currentImage);
  }, [currentImage]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // بررسی حجم (حداکثر 2MB)
    if (file.size > 2 * 1024 * 1024) {
      alert('⚠️ حجم فایل خیلی زیاد است!\nلطفاً فایل کوچکتر (کمتر از 2 مگابایت) انتخاب کنید.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Resize تصویر به اندازه مستطیلی (مثل کارت ملی 3:2)
        const canvas = document.createElement('canvas');
        const targetWidth = 320;
        const targetHeight = 200;
        canvas.width = targetWidth;
        canvas.height = targetHeight;
        const ctx = canvas.getContext('2d');
        
        if (!ctx) return;

        // محاسبه ابعاد برای crop مستطیلی از مرکز
        const targetRatio = targetWidth / targetHeight;
        const imgRatio = img.width / img.height;
        
        let cropWidth, cropHeight, startX, startY;
        
        if (imgRatio > targetRatio) {
          // تصویر عریض‌تر است، از عرض crop می‌کنیم
          cropHeight = img.height;
          cropWidth = img.height * targetRatio;
          startX = (img.width - cropWidth) / 2;
          startY = 0;
        } else {
          // تصویر بلندتر است، از ارتفاع crop می‌کنیم
          cropWidth = img.width;
          cropHeight = img.width / targetRatio;
          startX = 0;
          startY = (img.height - cropHeight) / 2;
        }

        ctx.drawImage(
          img,
          startX, startY, cropWidth, cropHeight,
          0, 0, targetWidth, targetHeight
        );

        const resizedImage = canvas.toDataURL('image/jpeg', 0.8);
        setPreview(resizedImage);
        onImageChange(resizedImage);
        
        console.log('✅ تصویر با موفقیت پردازش شد:', {
          size: resizedImage.length,
          dimensions: `${targetWidth}x${targetHeight}`,
          preview: resizedImage.substring(0, 50)
        });
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleRemove = () => {
    setPreview('');
    onImageChange('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="shrink-0">
      <label className="block text-slate-300 text-sm mb-2">تصویر شخص</label>
      <p className="text-slate-500 text-xs mb-2">از روی کارت ملی یا به صورت مستقیم</p>
      
      <div className="relative group">
        {preview ? (
          <div className="w-48 h-32 rounded-xl overflow-hidden border-2 border-blue-500/50 relative">
            <img src={preview} alt="تصویر" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center">
              <span className="text-white text-xs text-center px-2">
                📷<br/>تغییر تصویر
              </span>
            </div>
          </div>
        ) : (
          <div className="w-48 h-32 rounded-xl bg-slate-700/50 border-2 border-dashed border-slate-600 flex flex-col items-center justify-center gap-2 cursor-pointer hover:border-blue-500/50 transition-all">
            <span className="text-4xl">📷</span>
            <span className="text-xs text-slate-400 text-center px-2">کلیک کنید<br/>برای آپلود<br/>(اندازه کارت ملی)</span>
          </div>
        )}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="absolute inset-0 opacity-0 cursor-pointer"
        />
      </div>
      
      {preview && (
        <button
          type="button"
          onClick={handleRemove}
          className="mt-2 text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1"
        >
          <span>✕</span>
          <span>حذف تصویر</span>
        </button>
      )}
    </div>
  );
}
