import { useState } from 'react';

export default function Settings() {
  const [activeSection, setActiveSection] = useState<'general' | 'backup' | 'about'>('general');

  const handleExport = () => {
    const data = {
      products: localStorage.getItem('store-products'),
      customers: localStorage.getItem('store-customers'),
      invoices: localStorage.getItem('store-invoices'),
      checks: localStorage.getItem('store-checks'),
      installmentPlans: localStorage.getItem('store-installment-plans'),
      categories: localStorage.getItem('store-categories'),
      brands: localStorage.getItem('store-brands'),
      models: localStorage.getItem('store-models'),
      colors: localStorage.getItem('store-colors'),
      reminders: localStorage.getItem('store-reminders'),
      notes: localStorage.getItem('store-notes'),
      exportDate: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backup-${new Date().toLocaleDateString('fa-IR')}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        if (data.products) localStorage.setItem('store-products', data.products);
        if (data.customers) localStorage.setItem('store-customers', data.customers);
        if (data.invoices) localStorage.setItem('store-invoices', data.invoices);
        if (data.checks) localStorage.setItem('store-checks', data.checks);
        if (data.installmentPlans) localStorage.setItem('store-installment-plans', data.installmentPlans);
        if (data.categories) localStorage.setItem('store-categories', data.categories);
        if (data.brands) localStorage.setItem('store-brands', data.brands);
        if (data.models) localStorage.setItem('store-models', data.models);
        if (data.colors) localStorage.setItem('store-colors', data.colors);
        if (data.reminders) localStorage.setItem('store-reminders', data.reminders);
        if (data.notes) localStorage.setItem('store-notes', data.notes);
        alert('✅ داده‌ها با موفقیت بازیابی شدند! صفحه را رفرش کنید.');
        window.location.reload();
      } catch (error) {
        alert('❌ خطا در خواندن فایل! لطفاً فایل معتبر انتخاب کنید.');
      }
    };
    reader.readAsText(file);
  };

  const handleClearAll = () => {
    if (confirm('⚠️ آیا مطمئن هستید؟ تمام داده‌ها حذف خواهند شد!')) {
      if (confirm('⚠️ این عمل قابل بازگشت نیست! آیا واقعاً می‌خواهید ادامه دهید؟')) {
        localStorage.clear();
        alert('✅ تمام داده‌ها حذف شدند. صفحه را رفرش کنید.');
        window.location.reload();
      }
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* هدر */}
      <div className="bg-gradient-to-br from-blue-600 to-violet-600 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">⚙️ تنظیمات برنامه</h2>
        <p className="text-blue-100">مدیریت تنظیمات، پشتیبان‌گیری و بازیابی داده‌ها</p>
      </div>

      {/* تب‌ها */}
      <div className="flex gap-2 bg-slate-800/60 backdrop-blur-lg rounded-xl p-2 border border-slate-700/50">
        <button
          onClick={() => setActiveSection('general')}
          className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
            activeSection === 'general'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-300 hover:bg-slate-700/50'
          }`}
        >
          🔧 عمومی
        </button>
        <button
          onClick={() => setActiveSection('backup')}
          className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
            activeSection === 'backup'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-300 hover:bg-slate-700/50'
          }`}
        >
          💾 پشتیبان‌گیری
        </button>
        <button
          onClick={() => setActiveSection('about')}
          className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
            activeSection === 'about'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-300 hover:bg-slate-700/50'
          }`}
        >
          ℹ️ درباره
        </button>
      </div>

      {/* تنظیمات عمومی */}
      {activeSection === 'general' && (
        <div className="space-y-4">
          <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-6">
            <h3 className="text-xl font-bold text-white mb-4">🔧 تنظیمات عمومی</h3>
            
            <div className="space-y-4">
              <div className="bg-slate-700/30 rounded-xl p-4">
                <h4 className="text-white font-bold mb-2">زبان و منطقه</h4>
                <p className="text-slate-400 text-sm mb-3">زبان برنامه و فرمت تاریخ</p>
                <div className="flex items-center justify-between">
                  <span className="text-slate-300">زبان:</span>
                  <span className="text-white font-medium">فارسی 🇮🇷</span>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-slate-300">تقویم:</span>
                  <span className="text-white font-medium">شمسی</span>
                </div>
              </div>

              <div className="bg-slate-700/30 rounded-xl p-4">
                <h4 className="text-white font-bold mb-2">واحد پول</h4>
                <p className="text-slate-400 text-sm mb-3">واحد نمایش مبالغ</p>
                <div className="flex items-center justify-between">
                  <span className="text-slate-300">واحد:</span>
                  <span className="text-white font-medium">تومان (ت)</span>
                </div>
              </div>

              <div className="bg-slate-700/30 rounded-xl p-4">
                <h4 className="text-white font-bold mb-2">ذخیره‌سازی</h4>
                <p className="text-slate-400 text-sm mb-3">محل ذخیره داده‌ها</p>
                <div className="flex items-center justify-between">
                  <span className="text-slate-300">محل ذخیره:</span>
                  <span className="text-white font-medium">مرورگر (localStorage)</span>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-slate-300">حجم استفاده شده:</span>
                  <span className="text-white font-medium">
                    {(JSON.stringify(localStorage).length / 1024).toFixed(2)} KB
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* پشتیبان‌گیری */}
      {activeSection === 'backup' && (
        <div className="space-y-4">
          <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-6">
            <h3 className="text-xl font-bold text-white mb-4">💾 پشتیبان‌گیری و بازیابی</h3>
            
            <div className="space-y-4">
              <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4">
                <h4 className="text-emerald-400 font-bold mb-2">📤 پشتیبان‌گیری</h4>
                <p className="text-slate-300 text-sm mb-3">
                  تمام داده‌های برنامه را در یک فایل JSON ذخیره کنید
                </p>
                <button
                  onClick={handleExport}
                  className="w-full bg-emerald-600 text-white py-3 rounded-xl font-bold hover:bg-emerald-700 transition-all"
                >
                  💾 دانلود فایل پشتیبان
                </button>
              </div>

              <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
                <h4 className="text-blue-400 font-bold mb-2">📥 بازیابی</h4>
                <p className="text-slate-300 text-sm mb-3">
                  داده‌ها را از فایل پشتیبان بازیابی کنید
                </p>
                <label className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-all cursor-pointer block text-center">
                  📂 انتخاب فایل پشتیبان
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImport}
                    className="hidden"
                  />
                </label>
              </div>

              <div className="bg-rose-500/10 border border-rose-500/30 rounded-xl p-4">
                <h4 className="text-rose-400 font-bold mb-2">🗑️ حذف تمام داده‌ها</h4>
                <p className="text-slate-300 text-sm mb-3">
                  تمام داده‌های برنامه را حذف کنید (قابل بازگشت نیست!)
                </p>
                <button
                  onClick={handleClearAll}
                  className="w-full bg-rose-600 text-white py-3 rounded-xl font-bold hover:bg-rose-700 transition-all"
                >
                  🗑️ حذف تمام داده‌ها
                </button>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-amber-900/30 to-orange-900/30 rounded-2xl p-6 border border-amber-500/30">
            <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
              <span>⚠️</span>
              نکات مهم
            </h3>
            <ul className="space-y-2 text-slate-300 text-sm">
              <li>✓ هر هفته از داده‌ها پشتیبان‌گیری کنید</li>
              <li>✓ فایل پشتیبان را در چند محل ذخیره کنید</li>
              <li>✓ قبل از پاک کردن کش مرورگر، پشتیبان بگیرید</li>
              <li>✓ برای انتقال به کامپیوتر دیگر، فایل پشتیبان را منتقل کنید</li>
            </ul>
          </div>
        </div>
      )}

      {/* درباره */}
      {activeSection === 'about' && (
        <div className="space-y-4">
          <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-6">
            <h3 className="text-xl font-bold text-white mb-4">ℹ️ درباره برنامه</h3>
            
            <div className="text-center py-6">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-violet-600 rounded-2xl flex items-center justify-center text-5xl mx-auto mb-4 shadow-2xl">
                🏪
              </div>
              <h4 className="text-2xl font-bold text-white mb-2">حسابداری فروشگاه</h4>
              <p className="text-slate-400 mb-4">سیستم مدیریت جامع فروشگاه</p>
              <div className="inline-block bg-blue-500/20 text-blue-400 px-4 py-2 rounded-xl">
                نسخه 2.0.0
              </div>
            </div>

            <div className="space-y-3 mt-6">
              <div className="bg-slate-700/30 rounded-xl p-4">
                <h5 className="text-white font-bold mb-2">🎯 ویژگی‌ها</h5>
                <ul className="space-y-1 text-slate-300 text-sm">
                  <li>✓ مدیریت کالا و انبار</li>
                  <li>✓ مدیریت اشخاص و مشتریان</li>
                  <li>✓ سیستم فاکتور پیشرفته</li>
                  <li>✓ مدیریت چک و اقساط</li>
                  <li>✓ دستیار هوش مصنوعی</li>
                  <li>✓ گزارش‌گیری حرفه‌ای</li>
                </ul>
              </div>

              <div className="bg-slate-700/30 rounded-xl p-4">
                <h5 className="text-white font-bold mb-2">🔧 تکنولوژی‌ها</h5>
                <ul className="space-y-1 text-slate-300 text-sm">
                  <li>• React 18</li>
                  <li>• TypeScript</li>
                  <li>• Tailwind CSS</li>
                  <li>• Vite</li>
                  <li>• localStorage</li>
                </ul>
              </div>

              <div className="bg-slate-700/30 rounded-xl p-4">
                <h5 className="text-white font-bold mb-2">📞 پشتیبانی</h5>
                <p className="text-slate-300 text-sm">
                  برای گزارش مشکلات یا پیشنهاد ویژگی‌ها، به صفحه GitHub پروژه مراجعه کنید
                </p>
              </div>
            </div>
          </div>

          <div className="text-center text-slate-500 text-sm py-4">
            <p>ساخته شده با ❤️ برای فروشگاه‌های ایرانی</p>
            <p className="mt-1">© 1403 - تمامی حقوق محفوظ است</p>
          </div>
        </div>
      )}
    </div>
  );
}
