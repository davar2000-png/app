import { useState } from 'react';
import { Product, Customer, Invoice } from './types';
import { formatNumber, formatJalaliDate } from './utils';

interface ListManagerProps {
  products: Product[];
  customers: Customer[];
  invoices: Invoice[];
}

export default function ListManager({ products, customers, invoices }: ListManagerProps) {
  const [activeTab, setActiveTab] = useState<'products' | 'customers' | 'invoices'>('products');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredCustomers = customers.filter(c =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.phone.includes(searchTerm) ||
    c.nationalId?.includes(searchTerm) ||
    c.job?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredInvoices = invoices.filter(inv =>
    inv.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inv.personName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* هدر */}
      <div className="bg-gradient-to-br from-blue-600 to-violet-600 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">📋 لیست‌های اصلی</h2>
        <p className="text-blue-100">مدیریت و مشاهده لیست کالاها، اشخاص و فاکتورها</p>
      </div>

      {/* تب‌ها */}
      <div className="flex gap-2 bg-slate-800/60 backdrop-blur-lg rounded-xl p-2 border border-slate-700/50">
        <button
          onClick={() => { setActiveTab('products'); setSearchTerm(''); }}
          className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
            activeTab === 'products'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-300 hover:bg-slate-700/50'
          }`}
        >
          📦 کالاها ({products.length})
        </button>
        <button
          onClick={() => { setActiveTab('customers'); setSearchTerm(''); }}
          className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
            activeTab === 'customers'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-300 hover:bg-slate-700/50'
          }`}
        >
          👥 اشخاص ({customers.length})
        </button>
        <button
          onClick={() => { setActiveTab('invoices'); setSearchTerm(''); }}
          className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
            activeTab === 'invoices'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'text-slate-300 hover:bg-slate-700/50'
          }`}
        >
          📄 فاکتورها ({invoices.length})
        </button>
      </div>

      {/* جستجو */}
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-xl p-4 border border-slate-700/50">
        <input
          type="text"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          placeholder={`جستجو در ${activeTab === 'products' ? 'کالاها' : activeTab === 'customers' ? 'اشخاص' : 'فاکتورها'}...`}
          className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
        />
      </div>

      {/* محتوای تب‌ها */}
      {activeTab === 'products' && (
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-700/50">
                <tr>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">کد</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">نام کالا</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">برند</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">موجودی</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">قیمت خرید</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">قیمت فروش</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {filteredProducts.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                      کالایی یافت نشد
                    </td>
                  </tr>
                ) : (
                  filteredProducts.map(product => (
                    <tr key={product.id} className="hover:bg-slate-700/20 transition-colors">
                      <td className="px-4 py-3 text-sm text-slate-300">{product.code}</td>
                      <td className="px-4 py-3 text-sm text-white font-medium">{product.name}</td>
                      <td className="px-4 py-3 text-sm text-slate-300">{product.brand}</td>
                      <td className="px-4 py-3 text-sm">
                        <span className={`font-bold ${
                          product.stock === 0 ? 'text-rose-400' : 
                          product.stock <= product.minStock ? 'text-amber-400' : 'text-emerald-400'
                        }`}>
                          {product.stock}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-300">{formatNumber(product.buyPrice)}</td>
                      <td className="px-4 py-3 text-sm text-emerald-400 font-bold">{formatNumber(product.sellPrice)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'customers' && (
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-700/50">
                <tr>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">تصویر</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">نام</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">تلفن</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">کد ملی</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">شغل</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">شهر</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {filteredCustomers.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                      شخصی یافت نشد
                    </td>
                  </tr>
                ) : (
                  filteredCustomers.map(customer => (
                    <tr key={customer.id} className="hover:bg-slate-700/20 transition-colors">
                      <td className="px-4 py-3">
                        {customer.image ? (
                          <img src={customer.image} alt={customer.name} className="w-10 h-10 rounded-lg object-cover" />
                        ) : (
                          <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center text-xl">
                            👤
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3 text-sm text-white font-medium">{customer.name}</td>
                      <td className="px-4 py-3 text-sm text-slate-300">{customer.phone}</td>
                      <td className="px-4 py-3 text-sm text-slate-300">{customer.nationalId || '-'}</td>
                      <td className="px-4 py-3 text-sm text-slate-300">{customer.job || '-'}</td>
                      <td className="px-4 py-3 text-sm text-slate-300">{customer.city || '-'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'invoices' && (
        <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-700/50">
                <tr>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">شماره فاکتور</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">نوع</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">تاریخ</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">مشتری/فروشنده</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">مبلغ کل</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">وضعیت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {filteredInvoices.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                      فاکتوری یافت نشد
                    </td>
                  </tr>
                ) : (
                  filteredInvoices.map(invoice => (
                    <tr key={invoice.id} className="hover:bg-slate-700/20 transition-colors">
                      <td className="px-4 py-3 text-sm text-white font-medium">{invoice.invoiceNumber}</td>
                      <td className="px-4 py-3 text-sm">
                        <span className={`px-2 py-1 rounded-lg text-xs ${
                          invoice.type === 'sale' ? 'bg-emerald-500/20 text-emerald-400' :
                          invoice.type === 'purchase' ? 'bg-blue-500/20 text-blue-400' :
                          invoice.type === 'return_sale' ? 'bg-rose-500/20 text-rose-400' :
                          'bg-orange-500/20 text-orange-400'
                        }`}>
                          {invoice.type === 'sale' ? 'فروش' :
                           invoice.type === 'purchase' ? 'خرید' :
                           invoice.type === 'return_sale' ? 'برگشت فروش' : 'برگشت خرید'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-300">{formatJalaliDate(invoice.date)}</td>
                      <td className="px-4 py-3 text-sm text-slate-300">{invoice.personName}</td>
                      <td className="px-4 py-3 text-sm text-emerald-400 font-bold">{formatNumber(invoice.total)}</td>
                      <td className="px-4 py-3 text-sm">
                        <span className={`px-2 py-1 rounded-lg text-xs ${
                          invoice.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400' :
                          invoice.status === 'partial' ? 'bg-amber-500/20 text-amber-400' :
                          'bg-rose-500/20 text-rose-400'
                        }`}>
                          {invoice.status === 'completed' ? 'تسویه شده' :
                           invoice.status === 'partial' ? 'جزئی' : 'پرداخت نشده'}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
