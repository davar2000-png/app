import { useState } from 'react';

interface SidebarProps {
  onNavigate: (section: string) => void;
  activeSection: string;
}

export default function Sidebar({ onNavigate, activeSection }: SidebarProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [expandedMenu, setExpandedMenu] = useState<string | null>('intro');

  const menuStructure = [
    {
      id: 'intro',
      label: 'معرفی',
      icon: '📖',
      subItems: [
        { id: 'intro-products', label: 'کالا', icon: '📦' },
        { id: 'intro-persons', label: 'طرف حساب', icon: '👤' },
        { id: 'intro-product-groups', label: 'گروه کالا', icon: '🏷️' },
        { id: 'intro-person-groups', label: 'گروه اشخاص', icon: '👥' },
        { id: 'intro-banks', label: 'گروه بانک‌ها', icon: '🏦' },
      ],
    },
    {
      id: 'list',
      label: 'لیست',
      icon: '📋',
      subItems: [
        { id: 'list-products', label: 'کالا', icon: '📦' },
        { id: 'list-checks', label: 'چک‌ها', icon: '💳' },
        { id: 'list-persons', label: 'اشخاص', icon: '👥' },
        { id: 'list-invoices', label: 'فاکتورها', icon: '📄' },
      ],
    },
    {
      id: 'invoice',
      label: 'فاکتور',
      icon: '📄',
      subItems: [
        { id: 'invoice-purchase', label: 'خرید', icon: '🛒' },
        { id: 'invoice-sale', label: 'فروش', icon: '💰' },
        { id: 'invoice-return-purchase', label: 'برگشت از خرید', icon: '↩️' },
        { id: 'invoice-return-sale', label: 'برگشت از فروش', icon: '↩️' },
        { id: 'invoice-pre', label: 'پیش‌فاکتور', icon: '📋' },
      ],
    },
    {
      id: 'settings',
      label: 'تنظیمات',
      icon: '⚙️',
      subItems: [
        { id: 'settings-theme', label: 'تغییر تم', icon: '🎨' },
        { id: 'settings-backup', label: 'بک‌آپ خودکار', icon: '💾' },
      ],
    },
  ];

  const handleMenuClick = (menuId: string) => {
    if (expandedMenu === menuId) {
      setExpandedMenu(null);
    } else {
      setExpandedMenu(menuId);
    }
  };

  const handleSubItemClick = (subItemId: string) => {
    onNavigate(subItemId);
    if (window.innerWidth < 1024) {
      setIsExpanded(false);
    }
  };

  return (
    <>
      {/* دکمه toggle برای موبایل */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="lg:hidden fixed top-4 right-4 z-50 w-12 h-12 bg-blue-600 text-white rounded-full shadow-lg flex items-center justify-center text-xl hover:bg-blue-700 transition-all"
      >
        {isExpanded ? '✕' : '☰'}
      </button>

      {/* سایدبار */}
      <div
        className={`fixed top-0 right-0 h-full bg-slate-900/95 backdrop-blur-lg border-l border-slate-700/50 shadow-2xl transition-all duration-300 z-40 ${
          isExpanded ? 'w-72' : 'w-0 lg:w-20'
        }`}
      >
        <div className="flex flex-col h-full overflow-hidden">
          {/* هدر */}
          <div className="p-4 border-b border-slate-700/50 shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-violet-600 rounded-xl flex items-center justify-center text-xl shadow-lg shrink-0">
                🏪
              </div>
              {isExpanded && (
                <div className="animate-fadeIn overflow-hidden">
                  <h2 className="text-white font-bold text-sm whitespace-nowrap">حسابداری فروشگاه</h2>
                  <p className="text-slate-400 text-xs whitespace-nowrap">نسخه 2.0</p>
                </div>
              )}
            </div>
          </div>

          {/* منو */}
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
            {menuStructure.map(menu => (
              <div key={menu.id}>
                {/* آیتم اصلی منو */}
                <button
                  onClick={() => handleMenuClick(menu.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all group ${
                    expandedMenu === menu.id
                      ? 'bg-gradient-to-r from-blue-600 to-violet-600 text-white shadow-lg shadow-blue-500/30'
                      : 'text-slate-300 hover:bg-slate-800/50 hover:text-white'
                  }`}
                  title={!isExpanded ? menu.label : ''}
                >
                  <span className="text-2xl group-hover:scale-110 transition-transform shrink-0">{menu.icon}</span>
                  {isExpanded && (
                    <div className="flex-1 text-right flex items-center justify-between animate-fadeIn">
                      <span className="font-medium text-sm">{menu.label}</span>
                      <span className={`text-xs transition-transform ${expandedMenu === menu.id ? 'rotate-90' : ''}`}>
                        ◀
                      </span>
                    </div>
                  )}
                </button>

                {/* زیرمنوها */}
                {isExpanded && expandedMenu === menu.id && (
                  <div className="mt-1 mr-4 space-y-1 animate-fadeIn border-r-2 border-blue-500/30 pr-3">
                    {menu.subItems.map(subItem => (
                      <button
                        key={subItem.id}
                        onClick={() => handleSubItemClick(subItem.id)}
                        className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all ${
                          activeSection === subItem.id
                            ? 'bg-blue-600/30 text-blue-300 font-medium'
                            : 'text-slate-400 hover:bg-slate-700/50 hover:text-white'
                        }`}
                      >
                        <span className="text-lg">{subItem.icon}</span>
                        <span>{subItem.label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* فوتر */}
          {isExpanded && (
            <div className="p-3 border-t border-slate-700/50 shrink-0">
              <div className="bg-slate-800/50 rounded-xl p-3">
                <p className="text-slate-400 text-xs text-center">
                  🤖 دستیار هوش مصنوعی فعال
                </p>
                <p className="text-slate-500 text-[10px] text-center mt-1">
                  نسخه آفلاین - بدون نیاز به اینترنت
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Overlay برای موبایل */}
      {isExpanded && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-30"
          onClick={() => setIsExpanded(false)}
        />
      )}
    </>
  );
}
