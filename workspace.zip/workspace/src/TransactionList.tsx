import { Transaction, FilterType, SortType } from './types';
import { formatNumber, formatDate, getCategoryById } from './utils';
import { useState } from 'react';

interface TransactionListProps {
  transactions: Transaction[];
  onDelete: (id: string) => void;
}

export default function TransactionList({ transactions, onDelete }: TransactionListProps) {
  const [filter, setFilter] = useState<FilterType>('all');
  const [sort, setSort] = useState<SortType>('date-desc');
  const [search, setSearch] = useState('');

  let filtered = [...transactions];

  // فیلتر
  if (filter !== 'all') {
    filtered = filtered.filter(t => t.type === filter);
  }

  // جستجو
  if (search) {
    filtered = filtered.filter(t =>
      t.title.includes(search) || t.description?.includes(search)
    );
  }

  // مرتب‌سازی
  switch (sort) {
    case 'date-desc':
      filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      break;
    case 'date-asc':
      filtered.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      break;
    case 'amount-desc':
      filtered.sort((a, b) => b.amount - a.amount);
      break;
    case 'amount-asc':
      filtered.sort((a, b) => a.amount - b.amount);
      break;
  }

  return (
    <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 shadow-xl overflow-hidden">
      {/* هدر */}
      <div className="p-5 border-b border-slate-700/50">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            📋 تراکنش‌ها
            <span className="text-sm text-slate-400 font-normal">({filtered.length} مورد)</span>
          </h3>
        </div>

        {/* جستجو */}
        <div className="mb-4">
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="🔍 جستجو در تراکنش‌ها..."
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all text-sm"
          />
        </div>

        {/* فیلتر و مرتب‌سازی */}
        <div className="flex flex-wrap gap-2">
          <div className="flex gap-1 bg-slate-700/50 rounded-lg p-1">
            {([['all', 'همه'], ['income', 'درآمد'], ['expense', 'هزینه']] as const).map(([value, label]) => (
              <button
                key={value}
                onClick={() => setFilter(value)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                  filter === value
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <select
            value={sort}
            onChange={e => setSort(e.target.value as SortType)}
            className="bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-blue-500"
          >
            <option value="date-desc">جدیدترین</option>
            <option value="date-asc">قدیمی‌ترین</option>
            <option value="amount-desc">بیشترین مبلغ</option>
            <option value="amount-asc">کمترین مبلغ</option>
          </select>
        </div>
      </div>

      {/* لیست */}
      <div className="max-h-[500px] overflow-y-auto">
        {filtered.length === 0 ? (
          <div className="p-10 text-center text-slate-500">
            <span className="text-4xl block mb-3">📭</span>
            <p>تراکنشی یافت نشد</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-700/50">
            {filtered.map((transaction, index) => {
              const cat = getCategoryById(transaction.category);
              return (
                <div
                  key={transaction.id}
                  className="p-4 hover:bg-slate-700/30 transition-all animate-slideIn group"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <div className="flex items-center gap-3">
                    {/* آیکون دسته‌بندی */}
                    <div
                      className="w-11 h-11 rounded-xl flex items-center justify-center text-xl shrink-0"
                      style={{ backgroundColor: `${cat?.color}20` }}
                    >
                      {cat?.icon || '📌'}
                    </div>

                    {/* اطلاعات */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-white font-medium text-sm truncate">{transaction.title}</h4>
                        {cat && (
                          <span
                            className="text-[10px] px-2 py-0.5 rounded-full shrink-0"
                            style={{ backgroundColor: `${cat.color}20`, color: cat.color }}
                          >
                            {cat.name}
                          </span>
                        )}
                      </div>
                      <p className="text-slate-500 text-xs mt-1">{formatDate(transaction.date)}</p>
                      {transaction.description && (
                        <p className="text-slate-400 text-xs mt-1 truncate">{transaction.description}</p>
                      )}
                    </div>

                    {/* مبلغ */}
                    <div className="text-left shrink-0">
                      <p className={`font-bold text-sm ${
                        transaction.type === 'income' ? 'text-emerald-400' : 'text-rose-400'
                      }`}>
                        {transaction.type === 'income' ? '+' : '-'}{formatNumber(transaction.amount)}
                      </p>
                      <p className="text-slate-500 text-[10px]">تومان</p>
                    </div>

                    {/* دکمه حذف */}
                    <button
                      onClick={() => onDelete(transaction.id)}
                      className="opacity-0 group-hover:opacity-100 w-8 h-8 flex items-center justify-center rounded-lg bg-rose-500/20 text-rose-400 hover:bg-rose-500/30 transition-all shrink-0"
                      title="حذف"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
