import { Category } from './types';

export const categories: Category[] = [
  { id: 'product-sale', name: 'فروش محصول', icon: '📱', color: '#10b981', type: 'income' },
  { id: 'installment-payment', name: 'پرداخت قسط', icon: '💳', color: '#06b6d4', type: 'income' },
  { id: 'product-buy', name: 'خرید محصول', icon: '🛒', color: '#ef4444', type: 'expense' },
  { id: 'rent', name: 'اجاره مغازه', icon: '🏠', color: '#78716c', type: 'expense' },
  { id: 'salary', name: 'حقوق کارمند', icon: '💰', color: '#8b5cf6', type: 'expense' },
  { id: 'utilities', name: 'قبوض', icon: '📄', color: '#6366f1', type: 'expense' },
  { id: 'repair', name: 'تعمیرات', icon: '🔧', color: '#f97316', type: 'expense' },
  { id: 'shipping', name: 'حمل و نقل', icon: '🚚', color: '#3b82f6', type: 'expense' },
  { id: 'advertising', name: 'تبلیغات', icon: '📢', color: '#ec4899', type: 'expense' },
  { id: 'other-in', name: 'سایر درآمدها', icon: '💵', color: '#22c55e', type: 'income' },
  { id: 'other-out', name: 'سایر هزینه‌ها', icon: '📦', color: '#64748b', type: 'expense' },
];

export const productCategories = [
  { id: 'phone', name: 'گوشی موبایل', icon: '📱' },
  { id: 'laptop', name: 'لپ‌تاپ', icon: '💻' },
  { id: 'console', name: 'کنسول بازی', icon: '🎮' },
];

export function formatNumber(num: number): string {
  return num.toLocaleString('fa-IR');
}

export function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('fa-IR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export function formatShortDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('fa-IR', {
    month: 'short',
    day: 'numeric',
  });
}

export function getCategoryById(id: string): Category | undefined {
  return categories.find(c => c.id === id);
}

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

export function getTodayString(): string {
  return new Date().toISOString().split('T')[0];
}

export function calculateInstallments(totalAmount: number, downPayment: number, months: number): { amount: number; dates: string[] } {
  const remaining = totalAmount - downPayment;
  const installmentAmount = Math.round(remaining / months);
  const dates: string[] = [];
  const today = new Date();
  
  for (let i = 1; i <= months; i++) {
    const dueDate = new Date(today);
    dueDate.setMonth(dueDate.getMonth() + i);
    dates.push(dueDate.toISOString().split('T')[0]);
  }
  
  return { amount: installmentAmount, dates };
}

export function isOverdue(dueDate: string): boolean {
  return new Date(dueDate) < new Date(getTodayString());
}

export function daysUntilDue(dueDate: string): number {
  const today = new Date(getTodayString());
  const due = new Date(dueDate);
  const diff = due.getTime() - today.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

// تبدیل تاریخ میلادی به شمسی
export function toJalali(gy: number, gm: number, gd: number): [number, number, number] {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy = gy <= 1600 ? 0 : 979;
  gy -= gy <= 1600 ? 621 : 1600;
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days = 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) - 80 + gd + g_d_m[gm - 1];
  jy += 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}

// تبدیل تاریخ شمسی به میلادی
export function toGregorian(jy: number, jm: number, jd: number): [number, number, number] {
  let gy = jy <= 979 ? 621 : 1600;
  jy -= jy <= 979 ? 0 : 979;
  let days = 365 * jy + Math.floor(jy / 33) * 8 + Math.floor((jy % 33 + 3) / 4) + 78 + jd + (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let gd = days + 1;
  const sal_a = [0, 31, (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm = 0;
  for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
  return [gy, gm, gd];
}

// فرمت تاریخ شمسی
export function formatJalaliDate(dateStr: string): string {
  const date = new Date(dateStr);
  const [jy, jm, jd] = toJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
  const monthNames = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  return `${jd} ${monthNames[jm - 1]} ${jy}`;
}

// فرمت تاریخ شمسی کوتاه
export function formatJalaliShort(dateStr: string): string {
  const date = new Date(dateStr);
  const [jy, jm, jd] = toJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
  return `${jy}/${jm.toString().padStart(2, '0')}/${jd.toString().padStart(2, '0')}`;
}

// تاریخ امروز شمسی
export function getTodayJalali(): string {
  const today = new Date();
  const [jy, jm, jd] = toJalali(today.getFullYear(), today.getMonth() + 1, today.getDate());
  return `${jy}/${jm.toString().padStart(2, '0')}/${jd.toString().padStart(2, '0')}`;
}

// تولید شماره فاکتور
export function generateInvoiceNumber(type: string): string {
  const today = new Date();
  const [jy, jm, jd] = toJalali(today.getFullYear(), today.getMonth() + 1, today.getDate());
  const prefix = type === 'purchase' ? 'K' : type === 'sale' ? 'F' : type === 'return_purchase' ? 'BK' : type === 'return_sale' ? 'BF' : 'P';
  return `${prefix}-${jy}${jm.toString().padStart(2, '0')}${jd.toString().padStart(2, '0')}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;
}
