import { useState } from 'react';
import { Product, Customer, Sale, Installment } from './types';
import { generateId, getTodayString, formatNumber, calculateInstallments } from './utils';

interface SaleFormProps {
  products: Product[];
  customers: Customer[];
  onAddSale: (sale: Sale) => void;
  onUpdateProduct: (product: Product) => void;
}

export default function SaleForm({ products, customers, onAddSale, onUpdateProduct }: SaleFormProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [productId, setProductId] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [quantity, setQuantity] = useState('1');
  const [paymentType, setPaymentType] = useState<'cash' | 'installment'>('cash');
  const [downPayment, setDownPayment] = useState('');
  const [installmentMonths, setInstallmentMonths] = useState('3');
  const [unitPrice, setUnitPrice] = useState('');

  const selectedProduct = products.find(p => p.id === productId);

  const handleProductChange = (id: string) => {
    setProductId(id);
    const product = products.find(p => p.id === id);
    if (product) {
      setUnitPrice(product.sellPrice.toString());
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productId || !customerId || !unitPrice) return;

    const product = products.find(p => p.id === productId);
    if (!product) return;

    const totalAmount = Number(unitPrice) * Number(quantity);
    let installments: Installment[] | undefined;

    if (paymentType === 'installment') {
      const dp = Number(downPayment) || 0;
      const months = Number(installmentMonths) || 3;
      const { amount, dates } = calculateInstallments(totalAmount, dp, months);
      
      installments = dates.map((date, i) => ({
        id: generateId(),
        amount: i === dates.length - 1 ? amount + (totalAmount - dp - amount * months) : amount,
        dueDate: date,
        status: 'pending' as const,
      }));
    }

    const sale: Sale = {
      id: generateId(),
      productId,
      customerId,
      quantity: Number(quantity),
      unitPrice: Number(unitPrice),
      totalAmount,
      paymentType,
      downPayment: paymentType === 'installment' ? Number(downPayment) || 0 : totalAmount,
      installments,
      date: getTodayString(),
      status: 'completed',
    };

    onAddSale(sale);

    // به‌روزرسانی موجودی
    const updatedProduct = { ...product, stock: product.stock - Number(quantity) };
    onUpdateProduct(updatedProduct);

    // ریست فرم
    setProductId('');
    setCustomerId('');
    setQuantity('1');
    setPaymentType('cash');
    setDownPayment('');
    setInstallmentMonths('3');
    setUnitPrice('');
    setIsOpen(false);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 text-white rounded-2xl p-4 flex items-center justify-center gap-3 shadow-lg shadow-violet-500/20 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
      >
        <span className="text-2xl">🧾</span>
        <span className="text-lg font-bold">ثبت فروش جدید</span>
      </button>
    );
  }

  const availableProducts = products.filter(p => p.stock > 0);

  return (
    <div className="bg-slate-800/80 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50 shadow-xl animate-fadeIn">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">ثبت فروش جدید</h3>
        <button
          onClick={() => setIsOpen(false)}
          className="text-slate-400 hover:text-white transition-colors w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-700"
        >
          ✕
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* انتخاب محصول */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">محصول</label>
          <select
            value={productId}
            onChange={e => handleProductChange(e.target.value)}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
            required
          >
            <option value="">انتخاب محصول...</option>
            {availableProducts.map(p => (
              <option key={p.id} value={p.id}>
                {p.name} - {p.brand} {p.model} (موجودی: {p.stock})
              </option>
            ))}
          </select>
        </div>

        {/* انتخاب مشتری */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">مشتری</label>
          <select
            value={customerId}
            onChange={e => setCustomerId(e.target.value)}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
            required
          >
            <option value="">انتخاب مشتری...</option>
            {customers.map(c => (
              <option key={c.id} value={c.id}>
                {c.name} - {c.phone}
              </option>
            ))}
          </select>
        </div>

        {/* تعداد و قیمت */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-slate-300 text-sm mb-2">تعداد</label>
            <input
              type="number"
              value={quantity}
              onChange={e => setQuantity(e.target.value)}
              min="1"
              max={selectedProduct?.stock || 1}
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
              required
            />
          </div>
          <div>
            <label className="block text-slate-300 text-sm mb-2">قیمت واحد (تومان)</label>
            <input
              type="number"
              value={unitPrice}
              onChange={e => setUnitPrice(e.target.value)}
              min="0"
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
              required
            />
          </div>
        </div>

        {/* مبلغ کل */}
        {unitPrice && quantity && (
          <div className="bg-slate-700/30 rounded-xl p-4 text-center">
            <span className="text-slate-400 text-sm">مبلغ کل: </span>
            <span className="text-white font-bold text-lg">{formatNumber(Number(unitPrice) * Number(quantity))} تومان</span>
          </div>
        )}

        {/* نوع پرداخت */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">نوع پرداخت</label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setPaymentType('cash')}
              className={`py-3 rounded-xl font-bold transition-all ${
                paymentType === 'cash'
                  ? 'bg-emerald-600 text-white shadow-lg'
                  : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
              }`}
            >
              💵 نقدی
            </button>
            <button
              type="button"
              onClick={() => setPaymentType('installment')}
              className={`py-3 rounded-xl font-bold transition-all ${
                paymentType === 'installment'
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
              }`}
            >
              💳 اقساطی
            </button>
          </div>
        </div>

        {/* تنظیمات اقساط */}
        {paymentType === 'installment' && (
          <div className="space-y-3 bg-slate-700/30 rounded-xl p-4">
            <div>
              <label className="block text-slate-300 text-sm mb-2">پیش‌پرداخت (تومان)</label>
              <input
                type="number"
                value={downPayment}
                onChange={e => setDownPayment(e.target.value)}
                placeholder="۰"
                min="0"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
              />
            </div>
            <div>
              <label className="block text-slate-300 text-sm mb-2">تعداد اقساط (ماه)</label>
              <select
                value={installmentMonths}
                onChange={e => setInstallmentMonths(e.target.value)}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
              >
                <option value="3">۳ ماه</option>
                <option value="6">۶ ماه</option>
                <option value="9">۹ ماه</option>
                <option value="12">۱۲ ماه</option>
                <option value="18">۱۸ ماه</option>
                <option value="24">۲۴ ماه</option>
              </select>
            </div>
            {downPayment && unitPrice && quantity && (
              <div className="text-sm text-slate-400">
                مبلغ هر قسط: {formatNumber(Math.round((Number(unitPrice) * Number(quantity) - Number(downPayment)) / Number(installmentMonths)))} تومان
              </div>
            )}
          </div>
        )}

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-violet-600 to-purple-700 py-3 rounded-xl font-bold text-white shadow-lg shadow-violet-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all"
        >
          ✓ ثبت فروش
        </button>
      </form>
    </div>
  );
}
