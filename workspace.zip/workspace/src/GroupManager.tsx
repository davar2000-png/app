import { useState } from 'react';
import { CustomerGroup } from './types';
import { generateId } from './utils';

interface GroupManagerProps {
  groups: CustomerGroup[];
  onAdd: (group: CustomerGroup) => void;
  onDelete: (id: string) => void;
  onEdit: (group: CustomerGroup) => void;
}

const groupIcons = ['👥', '💎', '⭐', '🏢', '🎓', '👨‍💼', '👩‍💼', '🛡️', '🔥', '💰', '🎯', '🏆'];
const groupColors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#f97316', '#14b8a6', '#6366f1'];

export default function GroupManager({ groups, onAdd, onDelete, onEdit }: GroupManagerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState<CustomerGroup | null>(null);
  const [name, setName] = useState('');
  const [icon, setIcon] = useState('👥');
  const [color, setColor] = useState('#3b82f6');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;

    if (editingGroup) {
      onEdit({ ...editingGroup, name, icon, color });
      setEditingGroup(null);
    } else {
      const group: CustomerGroup = {
        id: generateId(),
        name,
        icon,
        color,
      };
      onAdd(group);
    }

    setName('');
    setIcon('👥');
    setColor('#3b82f6');
    setIsOpen(false);
  };

  const handleEdit = (group: CustomerGroup) => {
    setEditingGroup(group);
    setName(group.name);
    setIcon(group.icon);
    setColor(group.color);
    setIsOpen(true);
  };

  const handleClose = () => {
    setIsOpen(false);
    setEditingGroup(null);
    setName('');
    setIcon('👥');
    setColor('#3b82f6');
  };

  return (
    <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          📁 گروه‌بندی اشخاص
          <span className="text-sm text-slate-400 font-normal">({groups.length} گروه)</span>
        </h3>
        <button
          onClick={() => { setIsOpen(!isOpen); if (isOpen) handleClose(); }}
          className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700 transition-all"
        >
          {isOpen ? 'بستن' : '+ گروه جدید'}
        </button>
      </div>

      {/* فرم اضافه/ویرایش گروه */}
      {isOpen && (
        <form onSubmit={handleSubmit} className="mb-4 bg-slate-700/30 rounded-xl p-4 space-y-3 animate-fadeIn">
          <div>
            <label className="block text-slate-300 text-sm mb-2">نام گروه</label>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="مثلاً: مشتریان VIP"
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
              required
            />
          </div>

          <div>
            <label className="block text-slate-300 text-sm mb-2">آیکون</label>
            <div className="flex flex-wrap gap-2">
              {groupIcons.map(i => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setIcon(i)}
                  className={`w-9 h-9 rounded-lg flex items-center justify-center text-lg transition-all ${
                    icon === i ? 'bg-blue-600 scale-110' : 'bg-slate-700/50 hover:bg-slate-600'
                  }`}
                >
                  {i}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-slate-300 text-sm mb-2">رنگ</label>
            <div className="flex flex-wrap gap-2">
              {groupColors.map(c => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className={`w-8 h-8 rounded-lg transition-all ${color === c ? 'scale-125 ring-2 ring-white' : ''}`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>

          <div className="flex gap-2">
            <button
              type="submit"
              className="flex-1 bg-blue-600 text-white py-2 rounded-xl font-bold hover:bg-blue-700 transition-all"
            >
              {editingGroup ? '✓ ذخیره تغییرات' : '+ افزودن گروه'}
            </button>
            {editingGroup && (
              <button
                type="button"
                onClick={handleClose}
                className="px-4 bg-slate-600 text-white py-2 rounded-xl hover:bg-slate-500 transition-all"
              >
                انصراف
              </button>
            )}
          </div>
        </form>
      )}

      {/* لیست گروه‌ها */}
      {groups.length === 0 ? (
        <p className="text-slate-500 text-center py-4 text-sm">هنوز گروهی تعریف نشده</p>
      ) : (
        <div className="flex flex-wrap gap-2">
          {groups.map(group => (
            <div
              key={group.id}
              className="flex items-center gap-2 px-3 py-2 rounded-xl border group"
              style={{ borderColor: `${group.color}50`, backgroundColor: `${group.color}10` }}
            >
              <span>{group.icon}</span>
              <span className="text-sm" style={{ color: group.color }}>{group.name}</span>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all">
                <button
                  onClick={() => handleEdit(group)}
                  className="text-xs text-slate-400 hover:text-blue-400"
                  title="ویرایش"
                >
                  ✏️
                </button>
                <button
                  onClick={() => onDelete(group.id)}
                  className="text-xs text-slate-400 hover:text-rose-400"
                  title="حذف"
                >
                  ✕
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
