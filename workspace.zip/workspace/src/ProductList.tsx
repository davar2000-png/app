import { Product } from './types';
import { formatNumber, productCategories } from './utils';

interface ProductListProps {
  products: Product[];
  onDelete: (id: string) => void;
}

export default function ProductList({ products, onDelete }: ProductListProps) {
  if (products.length === 0) {
    return (
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-10 text-center">
        <span className="text-4xl block mb-3">📦</span>
        <p className="text-slate-400">هنوز محصولی ثبت نشده</p>
      </div>
    );
  }

  return (
    <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 overflow-hidden">
      <div className="p-5 border-b border-slate-700/50">
        <h3 className="text-xl font-bold text-white flex items-center gap-2">
          📦 لیست محصولات
          <span className="text-sm text-slate-400 font-normal">({products.length} محصول)</span>
        </h3>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-slate-700/30">
            <tr>
              <th className="text-right text-xs text-slate-400 font-medium px-4 py-3">محصول</th>
              <th className="text-right text-xs text-slate-400 font-medium px-4 py-3">دسته</th>
              <th className="text-right text-xs text-slate-400 font-medium px-4 py-3">قیمت خرید</th>
              <th className="text-right text-xs text-slate-400 font-medium px-4 py-3">قیمت فروش</th>
              <th className="text-right text-xs text-slate-400 font-medium px-4 py-3">سود</th>
              <th className="text-right text-xs text-slate-400 font-medium px-4 py-3">موجودی</th>
              <th className="text-center text-xs text-slate-400 font-medium px-4 py-3">عملیات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700/50">
            {products.map((product, index) => {
              const profit = ((product.sellPrice - product.buyPrice) / product.buyPrice) * 100;
              const cat = productCategories.find(c => c.id === product.category);
              return (
                <tr key={product.id} className="hover:bg-slate-700/20 transition-all animate-slideIn group" style={{ animationDelay: `${index * 0.05}s` }}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{cat?.icon}</span>
                      <div>
                        <p className="text-white text-sm font-medium">{product.name}</p>
                        <p className="text-slate-500 text-xs">{product.brand} - {product.model}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-xs text-slate-300 bg-slate-700/50 px-2 py-1 rounded-lg">{cat?.name}</span>
                  </td>
                  <td className="px-4 py-3 text-sm text-slate-300">{formatNumber(product.buyPrice)}</td>
                  <td className="px-4 py-3 text-sm text-white font-medium">{formatNumber(product.sellPrice)}</td>
                  <td className="px-4 py-3">
                    <span className={`text-sm font-bold ${profit > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {profit.toFixed(0)}%
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-sm font-bold ${product.stock > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {product.stock}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <button
                      onClick={() => onDelete(product.id)}
                      className="opacity-0 group-hover:opacity-100 text-rose-400 hover:text-rose-300 transition-all"
                      title="حذف"
                    >
                      🗑️
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
