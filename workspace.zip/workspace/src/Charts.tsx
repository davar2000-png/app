import { Transaction } from './types';
import { categories, formatNumber, getCategoryById } from './utils';

interface ChartsProps {
  transactions: Transaction[];
}

export default function Charts({ transactions }: ChartsProps) {
  // محاسبه هزینه‌ها بر اساس دسته‌بندی
  const expenseByCategory = categories
    .filter(c => c.type === 'expense')
    .map(cat => {
      const total = transactions
        .filter(t => t.category === cat.id && t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0);
      return { ...cat, total };
    })
    .filter(c => c.total > 0)
    .sort((a, b) => b.total - a.total);

  const totalExpense = expenseByCategory.reduce((sum, c) => sum + c.total, 0);

  // محاسبه درآمدها بر اساس دسته‌بندی
  const incomeByCategory = categories
    .filter(c => c.type === 'income')
    .map(cat => {
      const total = transactions
        .filter(t => t.category === cat.id && t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0);
      return { ...cat, total };
    })
    .filter(c => c.total > 0)
    .sort((a, b) => b.total - a.total);

  const totalIncome = incomeByCategory.reduce((sum, c) => sum + c.total, 0);

  // نمودار ۷ روز اخیر
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    return date;
  });

  const dailyData = last7Days.map(date => {
    const dateStr = date.toISOString().split('T')[0];
    const dayIncome = transactions
      .filter(t => t.date === dateStr && t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    const dayExpense = transactions
      .filter(t => t.date === dateStr && t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
    return {
      date,
      label: date.toLocaleDateString('fa-IR', { weekday: 'short' }),
      income: dayIncome,
      expense: dayExpense,
    };
  });

  const maxDaily = Math.max(...dailyData.map(d => Math.max(d.income, d.expense)), 1);

  if (transactions.length === 0) {
    return (
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-8 text-center">
        <span className="text-4xl block mb-3">📊</span>
        <p className="text-slate-400">برای مشاهده نمودارها، تراکنش ثبت کنید</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* نمودار هزینه‌ها */}
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-5">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          📊 هزینه‌ها بر اساس دسته‌بندی
        </h3>
        {expenseByCategory.length === 0 ? (
          <p className="text-slate-500 text-center py-6">هزینه‌ای ثبت نشده</p>
        ) : (
          <div className="space-y-3">
            {expenseByCategory.slice(0, 6).map(cat => {
              const percentage = totalExpense > 0 ? (cat.total / totalExpense) * 100 : 0;
              return (
                <div key={cat.id}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-slate-300 flex items-center gap-1.5">
                      <span>{cat.icon}</span>
                      {cat.name}
                    </span>
                    <span className="text-xs text-slate-400">
                      {formatNumber(cat.total)} ({percentage.toFixed(0)}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-700/50 rounded-full h-2.5 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{
                        width: `${percentage}%`,
                        backgroundColor: cat.color,
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* نمودار درآمد */}
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-5">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          💰 درآمدها بر اساس دسته‌بندی
        </h3>
        {incomeByCategory.length === 0 ? (
          <p className="text-slate-500 text-center py-6">درآمدی ثبت نشده</p>
        ) : (
          <div className="space-y-3">
            {incomeByCategory.slice(0, 6).map(cat => {
              const percentage = totalIncome > 0 ? (cat.total / totalIncome) * 100 : 0;
              return (
                <div key={cat.id}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-slate-300 flex items-center gap-1.5">
                      <span>{cat.icon}</span>
                      {cat.name}
                    </span>
                    <span className="text-xs text-slate-400">
                      {formatNumber(cat.total)} ({percentage.toFixed(0)}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-700/50 rounded-full h-2.5 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{
                        width: `${percentage}%`,
                        backgroundColor: cat.color,
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* نمودار ۷ روز اخیر */}
      <div className="bg-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-700/50 p-5 lg:col-span-2">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          📈 نمودار ۷ روز اخیر
        </h3>
        <div className="flex items-end justify-between gap-2 h-40">
          {dailyData.map((day, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div className="w-full flex items-end justify-center gap-1 h-28">
                {/* میله درآمد */}
                <div
                  className="w-3 bg-emerald-500 rounded-t-sm transition-all duration-500 min-h-[2px]"
                  style={{ height: `${(day.income / maxDaily) * 100}%` }}
                  title={`درآمد: ${formatNumber(day.income)}`}
                />
                {/* میله هزینه */}
                <div
                  className="w-3 bg-rose-500 rounded-t-sm transition-all duration-500 min-h-[2px]"
                  style={{ height: `${(day.expense / maxDaily) * 100}%` }}
                  title={`هزینه: ${formatNumber(day.expense)}`}
                />
              </div>
              <span className="text-[10px] text-slate-500">{day.label}</span>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-center gap-6 mt-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-emerald-500 rounded-sm" />
            <span className="text-xs text-slate-400">درآمد</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-rose-500 rounded-sm" />
            <span className="text-xs text-slate-400">هزینه</span>
          </div>
        </div>
      </div>
    </div>
  );
}
