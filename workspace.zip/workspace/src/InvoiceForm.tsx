import { useState } from 'react';
import { Invoice, InvoiceItem, Payment, Product, Customer, PaymentMethod, InvoiceType } from './types';
import { generateId, getTodayString, formatNumber, formatJalaliDate, generateInvoiceNumber } from './utils';

interface InvoiceFormProps {
  products: Product[];
  customers: Customer[];
  type: InvoiceType;
  onSave: (invoice: Invoice) => void;
  onCancel: () => void;
}

export default function InvoiceForm({ products, customers, type, onSave, onCancel }: InvoiceFormProps) {
  const [invoiceNumber] = useState(generateInvoiceNumber(type));
  const [date, setDate] = useState(getTodayString());
  const [personId, setPersonId] = useState('');
  const [items, setItems] = useState<InvoiceItem[]>([]);
  const [discount, setDiscount] = useState(0);
  const [tax, setTax] = useState(0);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [description, setDescription] = useState('');
  const [warnings, setWarnings] = useState<string[]>([]);

  // فرم افزودن آیتم
  const [selectedProductId, setSelectedProductId] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [itemDiscount, setItemDiscount] = useState(0);
  const [customSellPrice, setCustomSellPrice] = useState('');

  const getTypeLabel = () => {
    switch (type) {
      case 'purchase': return 'فاکتور خرید';
      case 'sale': return 'فاکتور فروش';
      case 'return_purchase': return 'برگشت از خرید';
      case 'return_sale': return 'برگشت از فروش';
      case 'pre_invoice': return 'پیش‌فاکتور';
    }
  };

  const getTypeColor = () => {
    switch (type) {
      case 'purchase': return 'from-blue-600 to-blue-800';
      case 'sale': return 'from-emerald-600 to-emerald-800';
      case 'return_purchase': return 'from-rose-600 to-rose-800';
      case 'return_sale': return 'from-orange-600 to-orange-800';
      case 'pre_invoice': return 'from-violet-600 to-violet-800';
    }
  };

  const selectedProduct = products.find(p => p.id === selectedProductId);

  const handleAddItem = () => {
    if (!selectedProduct || quantity <= 0) return;

    const warnings: string[] = [];

    // کنترل موجودی
    if (quantity > selectedProduct.stock && type === 'sale') {
      warnings.push(`⚠️ تعداد وارد شده (${quantity}) بیشتر از موجودی (${selectedProduct.stock}) است`);
    }

    // تعیین قیمت فروش
    let sellPrice = selectedProduct.sellPrice;
    if (customSellPrice) {
      sellPrice = Number(customSellPrice);
    }

    // کنترل قیمت فروش کمتر از خرید
    if (sellPrice < selectedProduct.buyPrice && type === 'sale') {
      warnings.push(`⚠️ قیمت فروش (${formatNumber(sellPrice)}) کمتر از قیمت خرید (${formatNumber(selectedProduct.buyPrice)}) است`);
    }

    const total = (sellPrice * quantity) - itemDiscount;

    const item: InvoiceItem = {
      id: generateId(),
      productId: selectedProduct.id,
      productName: selectedProduct.name,
      quantity,
      buyPrice: selectedProduct.buyPrice,
      sellPrice,
      discount: itemDiscount,
      total,
    };

    setItems([...items, item]);
    setWarnings(warnings);

    // ریست فرم
    setSelectedProductId('');
    setQuantity(1);
    setItemDiscount(0);
    setCustomSellPrice('');
  };

  const handleRemoveItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const subtotal = items.reduce((sum, item) => sum + item.total, 0);
  const total = subtotal - discount + tax;
  const paidAmount = payments.reduce((sum, p) => sum + p.amount, 0);
  const remaining = total - paidAmount;

  const handleAddPayment = (method: PaymentMethod, amount: number) => {
    const payment: Payment = {
      id: generateId(),
      method,
      amount,
      date: getTodayString(),
    };
    setPayments([...payments, payment]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!personId || items.length === 0) return;

    const person = customers.find(c => c.id === personId);
    if (!person) return;

    const invoice: Invoice = {
      id: generateId(),
      invoiceNumber,
      type,
      date,
      personId,
      personName: person.name,
      items,
      subtotal,
      discount,
      tax,
      total,
      paid: paidAmount,
      remaining,
      payments,
      status: remaining === 0 ? 'completed' : paidAmount > 0 ? 'partial' : 'pending',
      description,
      createdAt: new Date().toISOString(),
    };

    onSave(invoice);
  };

  const getPaymentMethodLabel = (method: PaymentMethod) => {
    switch (method) {
      case 'cash': return 'نقد';
      case 'card': return 'کارت';
      case 'check': return 'چک';
      case 'installment': return 'اقساط';
      case 'receipt': return 'فیش';
      case 'credit': return 'نسیه';
      case 'mixed': return 'ترکیبی';
    }
  };

  return (
    <div className="bg-slate-800/80 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50 shadow-xl">
      <div className="flex items-center justify-between mb-6">
        <h3 className={`text-xl font-bold text-white bg-gradient-to-r ${getTypeColor()} bg-clip-text text-transparent`}>
          {getTypeLabel()} - {invoiceNumber}
        </h3>
        <button
          onClick={onCancel}
          className="text-slate-400 hover:text-white w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-700"
        >
          ✕
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* اطلاعات اصلی */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-slate-300 text-sm mb-2">تاریخ</label>
            <input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500"
            />
            <p className="text-xs text-slate-400 mt-1">{formatJalaliDate(date)}</p>
          </div>
          <div>
            <label className="block text-slate-300 text-sm mb-2">{type === 'purchase' ? 'فروشنده' : 'مشتری'} *</label>
            <select
              value={personId}
              onChange={e => setPersonId(e.target.value)}
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500"
              required
            >
              <option value="">انتخاب...</option>
              {customers.map(c => (
                <option key={c.id} value={c.id}>{c.name} - {c.phone}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-slate-300 text-sm mb-2">شماره فاکتور</label>
            <input
              type="text"
              value={invoiceNumber}
              disabled
              className="w-full bg-slate-700/30 border border-slate-600 rounded-xl px-4 py-3 text-slate-400"
            />
          </div>
        </div>

        {/* افزودن آیتم */}
        <div className="bg-slate-700/30 rounded-xl p-4">
          <h4 className="text-white font-bold mb-3">➕ افزودن کالا</h4>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            <div className="md:col-span-2">
              <label className="block text-slate-300 text-xs mb-1">کالا</label>
              <select
                value={selectedProductId}
                onChange={e => {
                  setSelectedProductId(e.target.value);
                  const p = products.find(pr => pr.id === e.target.value);
                  if (p) setCustomSellPrice(p.sellPrice.toString());
                }}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
              >
                <option value="">انتخاب کالا...</option>
                {products.map(p => (
                  <option key={p.id} value={p.id}>{p.name} (موجودی: {p.stock})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-300 text-xs mb-1">تعداد</label>
              <input
                type="number"
                value={quantity}
                onChange={e => setQuantity(Number(e.target.value))}
                min="1"
                className={`w-full bg-slate-700/50 border rounded-lg px-3 py-2 text-white text-sm focus:outline-none ${
                  selectedProduct && quantity > selectedProduct.stock && type === 'sale'
                    ? 'border-yellow-500 bg-yellow-500/10'
                    : 'border-slate-600 focus:border-blue-500'
                }`}
              />
            </div>
            <div>
              <label className="block text-slate-300 text-xs mb-1">قیمت فروش</label>
              <input
                type="number"
                value={customSellPrice}
                onChange={e => setCustomSellPrice(e.target.value)}
                className={`w-full bg-slate-700/50 border rounded-lg px-3 py-2 text-white text-sm focus:outline-none ${
                  selectedProduct && Number(customSellPrice) < selectedProduct.buyPrice && type === 'sale'
                    ? 'border-pink-500 bg-pink-500/10'
                    : 'border-slate-600 focus:border-blue-500'
                }`}
              />
            </div>
            <div>
              <label className="block text-slate-300 text-xs mb-1">تخفیف</label>
              <input
                type="number"
                value={itemDiscount}
                onChange={e => setItemDiscount(Number(e.target.value))}
                min="0"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
          <button
            type="button"
            onClick={handleAddItem}
            className="mt-3 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-all"
          >
            ➕ افزودن به فاکتور
          </button>
        </div>

        {/* هشدارها */}
        {warnings.length > 0 && (
          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4">
            {warnings.map((w, i) => (
              <p key={i} className="text-yellow-400 text-sm">{w}</p>
            ))}
          </div>
        )}

        {/* لیست آیتم‌ها */}
        {items.length > 0 && (
          <div className="bg-slate-700/30 rounded-xl p-4">
            <h4 className="text-white font-bold mb-3">📋 اقلام فاکتور</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-700/50">
                  <tr>
                    <th className="px-3 py-2 text-right text-slate-300">کالا</th>
                    <th className="px-3 py-2 text-right text-slate-300">تعداد</th>
                    <th className="px-3 py-2 text-right text-slate-300">قیمت</th>
                    <th className="px-3 py-2 text-right text-slate-300">تخفیف</th>
                    <th className="px-3 py-2 text-right text-slate-300">جمع</th>
                    <th className="px-3 py-2 text-center text-slate-300">حذف</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700/50">
                  {items.map(item => (
                    <tr key={item.id}>
                      <td className="px-3 py-2 text-white">{item.productName}</td>
                      <td className="px-3 py-2 text-white">{item.quantity}</td>
                      <td className="px-3 py-2 text-white">{formatNumber(item.sellPrice)}</td>
                      <td className="px-3 py-2 text-white">{formatNumber(item.discount)}</td>
                      <td className="px-3 py-2 text-emerald-400 font-bold">{formatNumber(item.total)}</td>
                      <td className="px-3 py-2 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(item.id)}
                          className="text-rose-400 hover:text-rose-300"
                        >
                          🗑️
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* محاسبات */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-slate-700/30 rounded-xl p-4 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">جمع کل:</span>
              <span className="text-white font-bold">{formatNumber(subtotal)} تومان</span>
            </div>
            <div>
              <label className="block text-slate-300 text-xs mb-1">تخفیف کل</label>
              <input
                type="number"
                value={discount}
                onChange={e => setDiscount(Number(e.target.value))}
                min="0"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 text-xs mb-1">مالیات</label>
              <input
                type="number"
                value={tax}
                onChange={e => setTax(Number(e.target.value))}
                min="0"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>
            <div className="flex justify-between text-lg border-t border-slate-600 pt-3">
              <span className="text-white font-bold">مبلغ نهایی:</span>
              <span className="text-emerald-400 font-bold">{formatNumber(total)} تومان</span>
            </div>
          </div>

          <div className="bg-slate-700/30 rounded-xl p-4 space-y-3">
            <h4 className="text-white font-bold">💳 تسویه حساب</h4>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">پرداخت شده:</span>
              <span className="text-emerald-400 font-bold">{formatNumber(paidAmount)} تومان</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">باقیمانده:</span>
              <span className={`font-bold ${remaining > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {formatNumber(remaining)} تومان
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-3">
              <button
                type="button"
                onClick={() => handleAddPayment('cash', remaining)}
                className="bg-emerald-600 text-white py-2 rounded-lg text-sm hover:bg-emerald-700"
              >
                💵 نقد
              </button>
              <button
                type="button"
                onClick={() => handleAddPayment('card', remaining)}
                className="bg-blue-600 text-white py-2 rounded-lg text-sm hover:bg-blue-700"
              >
                💳 کارت
              </button>
              <button
                type="button"
                onClick={() => handleAddPayment('check', remaining)}
                className="bg-violet-600 text-white py-2 rounded-lg text-sm hover:bg-violet-700"
              >
                📝 چک
              </button>
              <button
                type="button"
                onClick={() => handleAddPayment('installment', remaining)}
                className="bg-amber-600 text-white py-2 rounded-lg text-sm hover:bg-amber-700"
              >
                📅 اقساط
              </button>
            </div>
          </div>
        </div>

        {/* توضیحات */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">توضیحات</label>
          <textarea
            value={description}
            onChange={e => setDescription(e.target.value)}
            rows={2}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none"
          />
        </div>

        {/* دکمه‌ها */}
        <div className="flex gap-3">
          <button
            type="submit"
            className={`flex-1 bg-gradient-to-r ${getTypeColor()} py-3 rounded-xl font-bold text-white shadow-lg hover:scale-[1.02] active:scale-[0.98] transition-all`}
          >
            ✓ ثبت فاکتور
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="px-6 bg-slate-700 text-white py-3 rounded-xl font-bold hover:bg-slate-600 transition-all"
          >
            انصراف
          </button>
        </div>
      </form>
    </div>
  );
}
