import { Transaction } from './types';
import { formatNumber } from './utils';

interface DashboardProps {
  transactions: Transaction[];
}

export default function Dashboard({ transactions }: DashboardProps) {
  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpense = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const balance = totalIncome - totalExpense;

  const thisMonth = new Date().getMonth();
  const thisYear = new Date().getFullYear();
  const monthTransactions = transactions.filter(t => {
    const d = new Date(t.date);
    return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
  });

  const monthIncome = monthTransactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const monthExpense = monthTransactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {/* موجودی کل */}
      <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl p-5 text-white shadow-lg shadow-blue-500/20 animate-fadeIn">
        <div className="flex items-center justify-between mb-3">
          <span className="text-blue-200 text-sm">موجودی کل</span>
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">
            💎
          </div>
        </div>
        <p className={`text-2xl font-bold ${balance < 0 ? 'text-red-300' : 'text-white'}`}>
          {formatNumber(balance)}
        </p>
        <p className="text-blue-200 text-xs mt-1">تومان</p>
      </div>

      {/* درآمد کل */}
      <div className="bg-gradient-to-br from-emerald-600 to-emerald-800 rounded-2xl p-5 text-white shadow-lg shadow-emerald-500/20 animate-fadeIn" style={{ animationDelay: '0.1s' }}>
        <div className="flex items-center justify-between mb-3">
          <span className="text-emerald-200 text-sm">کل درآمد</span>
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">
            📥
          </div>
        </div>
        <p className="text-2xl font-bold">{formatNumber(totalIncome)}</p>
        <p className="text-emerald-200 text-xs mt-1">تومان</p>
      </div>

      {/* هزینه کل */}
      <div className="bg-gradient-to-br from-rose-600 to-rose-800 rounded-2xl p-5 text-white shadow-lg shadow-rose-500/20 animate-fadeIn" style={{ animationDelay: '0.2s' }}>
        <div className="flex items-center justify-between mb-3">
          <span className="text-rose-200 text-sm">کل هزینه</span>
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">
            📤
          </div>
        </div>
        <p className="text-2xl font-bold">{formatNumber(totalExpense)}</p>
        <p className="text-rose-200 text-xs mt-1">تومان</p>
      </div>

      {/* این ماه */}
      <div className="bg-gradient-to-br from-violet-600 to-violet-800 rounded-2xl p-5 text-white shadow-lg shadow-violet-500/20 animate-fadeIn" style={{ animationDelay: '0.3s' }}>
        <div className="flex items-center justify-between mb-3">
          <span className="text-violet-200 text-sm">این ماه</span>
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">
            📅
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-emerald-300 text-sm">+{formatNumber(monthIncome)}</span>
          <span className="text-violet-300">/</span>
          <span className="text-rose-300 text-sm">-{formatNumber(monthExpense)}</span>
        </div>
        <p className="text-violet-200 text-xs mt-1">تومان</p>
      </div>
    </div>
  );
}
