import { useState, useRef } from 'react';
import ReactCrop, { centerCrop, makeAspectCrop, Crop, PixelCrop, PercentCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';

interface ImageCropperProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (croppedImage: string) => void;
  imageSrc: string;
}

function centerAspectCrop(mediaWidth: number, mediaHeight: number) {
  return centerCrop(
    makeAspectCrop(
      { unit: '%', width: 40 },
      1.6, // aspect ratio 1.6:1 (مثل کارت ملی مستطیلی)
      mediaWidth,
      mediaHeight,
    ),
    mediaWidth,
    mediaHeight,
  );
}

export default function ImageCropper({ isOpen, onClose, onSave, imageSrc }: ImageCropperProps) {
  const [crop, setCrop] = useState<Crop>();
  const [completedCrop, setCompletedCrop] = useState<PercentCrop>();
  const imgRef = useRef<HTMLImageElement>(null);

  if (!isOpen) return null;

  const handleSave = () => {
    if (!completedCrop || !imgRef.current) return;

    const image = imgRef.current;
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const pixelRatio = window.devicePixelRatio;
    const pixelCrop = {
      x: (completedCrop.x || 0) * scaleX,
      y: (completedCrop.y || 0) * scaleY,
      width: (completedCrop.width || 0) * scaleX,
      height: (completedCrop.height || 0) * scaleY,
    };

    // محدود کردن اندازه تصویر برای ذخیره در localStorage
    const maxSize = 400; // حداکثر 400x400 پیکسل
    let targetWidth = pixelCrop.width;
    let targetHeight = pixelCrop.height;
    
    if (targetWidth > maxSize || targetHeight > maxSize) {
      const ratio = Math.min(maxSize / targetWidth, maxSize / targetHeight);
      targetWidth = targetWidth * ratio;
      targetHeight = targetHeight * ratio;
    }

    canvas.width = targetWidth;
    canvas.height = targetHeight;

    ctx.imageSmoothingQuality = 'high';

    ctx.drawImage(
      image,
      pixelCrop.x,
      pixelCrop.y,
      pixelCrop.width,
      pixelCrop.height,
      0,
      0,
      targetWidth,
      targetHeight,
    );

    // فشرده‌سازی بیشتر برای ذخیره در localStorage
    const croppedImage = canvas.toDataURL('image/jpeg', 0.7);
    onSave(croppedImage);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-[70] p-4">
      <div className="bg-slate-800 rounded-2xl p-6 max-w-3xl w-full max-h-[90vh] overflow-y-auto border border-slate-700">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-white">✂️ برش تصویر شخص</h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-700"
          >
            ✕
          </button>
        </div>

        <div className="bg-slate-900/50 rounded-xl p-4 mb-4">
          <p className="text-slate-300 text-sm mb-3 text-center">
            💡 کادر را روی صورت شخص در کارت ملی قرار دهید
          </p>
          <ReactCrop
            crop={crop}
            onChange={(_, percentCrop) => setCrop(percentCrop)}
            onComplete={(_, percentCrop) => setCompletedCrop(percentCrop)}
            aspect={1.6}
          >
            <img
              ref={imgRef}
              src={imageSrc}
              alt="تصویر برای برش"
              onLoad={(e) => {
                const { naturalWidth, naturalHeight } = e.currentTarget;
                setCrop(centerAspectCrop(naturalWidth, naturalHeight));
              }}
              style={{ maxHeight: '60vh', maxWidth: '100%', margin: '0 auto', display: 'block' }}
            />
          </ReactCrop>
        </div>

        <div className="flex gap-3">
          <button
            onClick={handleSave}
            className="flex-1 bg-gradient-to-r from-emerald-600 to-emerald-700 text-white py-3 rounded-xl font-bold hover:scale-[1.02] active:scale-[0.98] transition-all shadow-lg shadow-emerald-500/30"
          >
            ✓ ذخیره تصویر بریده شده
          </button>
          <button
            onClick={onClose}
            className="px-6 bg-slate-700 text-white py-3 rounded-xl font-bold hover:bg-slate-600 transition-all"
          >
            انصراف
          </button>
        </div>
      </div>
    </div>
  );
}
