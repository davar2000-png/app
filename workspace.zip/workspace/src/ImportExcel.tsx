import { useState } from 'react';
import * as XLSX from 'xlsx';
import { Customer, Product, Sale } from './types';
import { generateId, getTodayString } from './utils';

interface ImportExcelProps {
  type: 'customers' | 'products' | 'sales';
  onImport: (data: any[]) => void;
}

export default function ImportExcel({ type, onImport }: ImportExcelProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [preview, setPreview] = useState<any[]>([]);
  const [allValidData, setAllValidData] = useState<any[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [fileName, setFileName] = useState('');

  const getTypeLabel = () => {
    switch (type) {
      case 'customers': return 'اشخاص';
      case 'products': return 'کالاها';
      case 'sales': return 'فاکتورها';
    }
  };

  const getRequiredColumns = () => {
    switch (type) {
      case 'customers':
        return ['نام'];
      case 'products':
        return ['نام', 'برند', 'مدل', 'قیمت خرید', 'قیمت فروش'];
      case 'sales':
        return ['محصول', 'مشتری', 'مبلغ کل', 'تاریخ'];
    }
  };

  const getOptionalColumns = () => {
    switch (type) {
      case 'customers':
        return ['موبایل/تلفن', 'آدرس', 'کد ملی', 'شغل', 'شهر', 'بستانکار', 'بدهکار', 'توضیحات'];
      case 'products':
        return ['دسته', 'موجودی', 'توضیحات'];
      case 'sales':
        return ['تعداد', 'قیمت واحد', 'نوع پرداخت', 'پیش پرداخت'];
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setErrors([]);
    setPreview([]);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
        
        // خواندن با header: 1 برای دیدن ساختار واقعی
        const rawData = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });
        
        if (rawData.length < 2) {
          setErrors(['فایل خالی است یا فقط یک ردیف دارد']);
          return;
        }

        // تبدیل به JSON با استفاده از ردیف اول به عنوان header
        const headers = (rawData[0] as any[]).map(h => String(h).trim());
        const jsonData = rawData.slice(1).map(row => {
          const obj: any = {};
          (row as any[]).forEach((cell, i) => {
            if (headers[i]) {
              obj[headers[i]] = cell;
            }
          });
          return obj;
        });

        console.log('📊 ساختار فایل:', { headers, firstRow: jsonData[0] });

        if (jsonData.length === 0) {
          setErrors(['فایل خالی است']);
          return;
        }

        // Validate and transform data
        const { validData, errors } = validateData(jsonData);
        
        if (errors.length > 0) {
          setErrors(errors);
        }

        setAllValidData(validData); // Store all valid records
        setPreview(validData.slice(0, 10)); // Show first 10 rows in preview
      } catch (error) {
        setErrors(['خطا در خواندن فایل: ' + (error as Error).message]);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const validateData = (data: any[]) => {
    const validData: any[] = [];
    const errors: string[] = [];

    data.forEach((row, index) => {
      try {
        switch (type) {
          case 'customers': {
            // پیدا کردن ستون‌ها با نام‌های مختلف
            const name = row['نام'] || row['نام و نام خانوادگی'] || row['Name'] || row['نام شخص'];
            const phone = row['تلفن'] || row['شماره تماس'] || row['Phone'] || row['موبایل'] || row['تلفن تماس'] || row['شماره موبایل'] || '';
            
            if (!name) {
              errors.push(`ردیف ${index + 2}: نام الزامی است - مقادیر موجود: ${JSON.stringify(row)}`);
              return;
            }
            validData.push({
              id: generateId(),
              name: String(name).trim(),
              phone: phone ? String(phone).trim() : '',
              address: row['آدرس'] ? String(row['آدرس']).trim() : '',
              nationalId: row['کد ملی'] ? String(row['کد ملی']).trim() : '',
              job: row['شغل'] ? String(row['شغل']).trim() : '',
              employeeId: row['شماره کارمندی'] ? String(row['شماره کارمندی']).trim() : '',
              bankCardNumber: row['شماره کارت'] ? String(row['شماره کارت']).trim() : '',
              city: row['شهر'] ? String(row['شهر']).trim() : '',
              creditor: row['بستانکار'] ? Number(String(row['بستانکار']).replace(/,/g, '')) || 0 : 0,
              debtor: row['بدهکار'] ? Number(String(row['بدهکار']).replace(/,/g, '')) || 0 : 0,
              image: '',
              documents: [],
              notes: row['توضیحات'] ? String(row['توضیحات']).trim() : '',
              createdAt: getTodayString(),
            });
            break;
          }
          case 'products': {
            const name = row['نام'] || row['نام محصول'] || row['Name'];
            const brand = row['برند'] || row['Brand'];
            const model = row['مدل'] || row['Model'];
            const buyPrice = row['قیمت خرید'] || row['Buy Price'];
            const sellPrice = row['قیمت فروش'] || row['Sell Price'];
            
            if (!name || !brand || !model || !buyPrice || !sellPrice) {
              errors.push(`ردیف ${index + 2}: نام، برند، مدل، قیمت خرید و قیمت فروش الزامی است - مقادیر موجود: ${JSON.stringify(row)}`);
              return;
            }
            const category = row['دسته'] === 'لپ‌تاپ' ? 'laptop' : row['دسته'] === 'کنسول' ? 'console' : 'phone';
            validData.push({
              id: generateId(),
              name: String(name),
              category: category as 'phone' | 'laptop' | 'console',
              brand: String(brand),
              model: String(model),
              buyPrice: Number(buyPrice) || 0,
              sellPrice: Number(sellPrice) || 0,
              stock: Number(row['موجودی']) || 0,
              description: row['توضیحات'] ? String(row['توضیحات']) : '',
            });
            break;
          }
          case 'sales': {
            const product = row['محصول'] || row['نام محصول'] || row['Product'];
            const customer = row['مشتری'] || row['نام مشتری'] || row['Customer'];
            const totalAmount = row['مبلغ کل'] || row['مبلغ'] || row['Total'];
            const date = row['تاریخ'] || row['Date'];
            
            if (!product || !customer || !totalAmount || !date) {
              errors.push(`ردیف ${index + 2}: محصول، مشتری، مبلغ کل و تاریخ الزامی است - مقادیر موجود: ${JSON.stringify(row)}`);
              return;
            }
            validData.push({
              id: generateId(),
              productName: String(product),
              customerName: String(customer),
              quantity: Number(row['تعداد']) || 1,
              unitPrice: Number(row['قیمت واحد']) || 0,
              totalAmount: Number(totalAmount) || 0,
              paymentType: row['نوع پرداخت'] === 'اقساطی' ? 'installment' : 'cash',
              downPayment: Number(row['پیش پرداخت']) || 0,
              date: String(date),
              status: 'completed',
            });
            break;
          }
        }
      } catch (error) {
        errors.push(`ردیف ${index + 2}: خطا در پردازش - ${(error as Error).message}`);
      }
    });

    return { validData, errors };
  };

  const handleImport = () => {
    if (allValidData.length === 0) {
      alert('داده‌ای برای وارد کردن وجود ندارد');
      return;
    }

    onImport(allValidData); // Import all valid records, not just preview
    setIsOpen(false);
    setPreview([]);
    setAllValidData([]);
    setErrors([]);
    setFileName('');
  };

  const handleClose = () => {
    setIsOpen(false);
    setPreview([]);
    setAllValidData([]);
    setErrors([]);
    setFileName('');
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-2xl p-4 flex items-center justify-center gap-3 shadow-lg shadow-green-500/20 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
      >
        <span className="text-2xl">📊</span>
        <span className="text-lg font-bold">وارد کردن از اکسل</span>
      </button>
    );
  }

  return (
    <div className="bg-slate-800/80 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50 shadow-xl animate-fadeIn">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">📊 وارد کردن {getTypeLabel()} از اکسل</h3>
        <button
          onClick={handleClose}
          className="text-slate-400 hover:text-white transition-colors w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-700"
        >
          ✕
        </button>
      </div>

      {/* راهنما */}
      <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4 mb-4">
        <h4 className="text-blue-400 font-bold mb-2">📋 ستون‌های الزامی:</h4>
        <div className="flex flex-wrap gap-2 mb-3">
          {getRequiredColumns().map(col => (
            <span key={col} className="bg-blue-500/20 text-blue-300 px-3 py-1 rounded-lg text-sm">
              {col}
            </span>
          ))}
        </div>
        <h4 className="text-slate-400 font-bold mb-2 text-sm">ستون‌های اختیاری:</h4>
        <div className="flex flex-wrap gap-2">
          {getOptionalColumns().map(col => (
            <span key={col} className="bg-slate-600/30 text-slate-400 px-3 py-1 rounded-lg text-xs">
              {col}
            </span>
          ))}
        </div>
        <p className="text-slate-400 text-sm mt-3">
          فایل اکسل باید شامل ردیف اول به عنوان سرستون باشد
        </p>
      </div>

      {/* آپلود فایل */}
      <div className="mb-4">
        <label className="block text-slate-300 text-sm mb-2">انتخاب فایل اکسل (.xlsx, .xls)</label>
        <div className="relative">
          <div className="bg-slate-700/50 border-2 border-dashed border-slate-600 rounded-xl p-6 text-center cursor-pointer hover:border-green-500/50 transition-all">
            <span className="text-4xl block mb-2">📁</span>
            <span className="text-slate-400">کلیک کنید یا فایل را بکشید و رها کنید</span>
            <input
              type="file"
              accept=".xlsx,.xls"
              onChange={handleFileUpload}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
          </div>
        </div>
        {fileName && (
          <p className="text-green-400 text-sm mt-2">✓ فایل انتخاب شد: {fileName}</p>
        )}
      </div>

      {/* خطاها */}
      {errors.length > 0 && (
        <div className="bg-rose-500/10 border border-rose-500/30 rounded-xl p-4 mb-4">
          <h4 className="text-rose-400 font-bold mb-2">⚠️ خطاها:</h4>
          <div className="space-y-1 max-h-40 overflow-y-auto">
            {errors.map((error, i) => (
              <p key={i} className="text-rose-300 text-sm">{error}</p>
            ))}
          </div>
        </div>
      )}

      {/* پیش‌نمایش */}
      {preview.length > 0 && (
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-slate-300 text-sm">پیش‌نمایش (۱۰ ردیف اول از {allValidData.length} رکورد):</h4>
            <div className="bg-green-500/20 text-green-400 px-3 py-1 rounded-lg text-sm font-bold">
              ✓ {allValidData.length} رکورد آماده وارد کردن
            </div>
          </div>
          <div className="bg-slate-700/30 rounded-xl overflow-x-auto max-h-96 overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-700/50 sticky top-0">
                <tr>
                  <th className="px-3 py-2 text-right text-slate-300 font-medium">#</th>
                  {Object.keys(preview[0]).map(key => (
                    <th key={key} className="px-3 py-2 text-right text-slate-300 font-medium">
                      {key}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {preview.map((row, i) => (
                  <tr key={i} className="hover:bg-slate-700/20">
                    <td className="px-3 py-2 text-slate-500 text-xs">{i + 1}</td>
                    {Object.values(row).map((value, j) => (
                      <td key={j} className="px-3 py-2 text-slate-300">
                        {String(value)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {allValidData.length > 10 && (
            <p className="text-slate-400 text-xs mt-2 text-center">
              ... و {allValidData.length - 10} رکورد دیگر
            </p>
          )}
        </div>
      )}

      {/* دکمه وارد کردن */}
      {allValidData.length > 0 && (
        <button
          onClick={handleImport}
          className="w-full bg-gradient-to-r from-green-600 to-emerald-700 py-3 rounded-xl font-bold text-white shadow-lg shadow-green-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all"
        >
          ✓ وارد کردن {allValidData.length} رکورد
        </button>
      )}
    </div>
  );
}
