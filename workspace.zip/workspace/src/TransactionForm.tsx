import { useState } from 'react';
import { Transaction } from './types';
import { categories, generateId, getTodayString } from './utils';

interface TransactionFormProps {
  onAdd: (transaction: Transaction) => void;
}

export default function TransactionForm({ onAdd }: TransactionFormProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [date, setDate] = useState(getTodayString());
  const [description, setDescription] = useState('');

  const filteredCategories = categories.filter(c => c.type === type || c.type === 'both');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !amount || !category) return;

    const transaction: Transaction = {
      id: generateId(),
      title,
      amount: Number(amount),
      type,
      category,
      date,
      description,
    };

    onAdd(transaction);
    setTitle('');
    setAmount('');
    setCategory('');
    setDate(getTodayString());
    setDescription('');
    setIsOpen(false);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="w-full bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 text-white rounded-2xl p-4 flex items-center justify-center gap-3 shadow-lg shadow-blue-500/20 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
      >
        <span className="text-2xl">➕</span>
        <span className="text-lg font-bold">ثبت تراکنش جدید</span>
      </button>
    );
  }

  return (
    <div className="bg-slate-800/80 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50 shadow-xl animate-fadeIn">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">ثبت تراکنش جدید</h3>
        <button
          onClick={() => setIsOpen(false)}
          className="text-slate-400 hover:text-white transition-colors w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-700"
        >
          ✕
        </button>
      </div>

      {/* نوع تراکنش */}
      <div className="flex gap-3 mb-5">
        <button
          type="button"
          onClick={() => { setType('income'); setCategory(''); }}
          className={`flex-1 py-3 rounded-xl font-bold transition-all duration-300 ${
            type === 'income'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/30'
              : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
          }`}
        >
          📥 درآمد
        </button>
        <button
          type="button"
          onClick={() => { setType('expense'); setCategory(''); }}
          className={`flex-1 py-3 rounded-xl font-bold transition-all duration-300 ${
            type === 'expense'
              ? 'bg-rose-600 text-white shadow-lg shadow-rose-500/30'
              : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
          }`}
        >
          📤 هزینه
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* عنوان */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">عنوان</label>
          <input
            type="text"
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder="مثلاً: حقوق ماهانه"
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
            required
          />
        </div>

        {/* مبلغ */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">مبلغ (تومان)</label>
          <input
            type="number"
            value={amount}
            onChange={e => setAmount(e.target.value)}
            placeholder="۰"
            min="0"
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
            required
          />
        </div>

        {/* دسته‌بندی */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">دسته‌بندی</label>
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
            {filteredCategories.map(cat => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setCategory(cat.id)}
                className={`p-2 rounded-xl text-center transition-all duration-200 ${
                  category === cat.id
                    ? 'bg-slate-600 border-2 border-blue-500 shadow-lg'
                    : 'bg-slate-700/50 border border-slate-600 hover:bg-slate-600'
                }`}
              >
                <span className="text-xl block">{cat.icon}</span>
                <span className="text-xs text-slate-300 mt-1 block">{cat.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* تاریخ */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">تاریخ</label>
          <input
            type="date"
            value={date}
            onChange={e => setDate(e.target.value)}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
            required
          />
        </div>

        {/* توضیحات */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">توضیحات (اختیاری)</label>
          <textarea
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="توضیحات بیشتر..."
            rows={2}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all resize-none"
          />
        </div>

        {/* دکمه ثبت */}
        <button
          type="submit"
          className={`w-full py-3 rounded-xl font-bold text-white transition-all duration-300 shadow-lg hover:scale-[1.02] active:scale-[0.98] ${
            type === 'income'
              ? 'bg-gradient-to-r from-emerald-600 to-emerald-700 shadow-emerald-500/30'
              : 'bg-gradient-to-r from-rose-600 to-rose-700 shadow-rose-500/30'
          }`}
        >
          ✓ ثبت تراکنش
        </button>
      </form>
    </div>
  );
}
