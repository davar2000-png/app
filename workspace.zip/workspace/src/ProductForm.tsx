import { useState } from 'react';
import { Product } from './types';
import { productCategories, generateId, formatNumber } from './utils';

interface ProductFormProps {
  onAdd: (product: Product) => void;
  products: Product[];
}

export default function ProductForm({ onAdd, products }: ProductFormProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [name, setName] = useState('');
  const [category, setCategory] = useState<'phone' | 'laptop' | 'console'>('phone');
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [buyPrice, setBuyPrice] = useState('');
  const [sellPrice, setSellPrice] = useState('');
  const [stock, setStock] = useState('1');
  const [description, setDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !brand || !model || !buyPrice || !sellPrice) return;

    const product: Product = {
      id: generateId(),
      code: `PRD-${Date.now()}`,
      name,
      category,
      brand,
      model,
      buyPrice: Number(buyPrice),
      sellPrice: Number(sellPrice),
      stock: Number(stock),
      minStock: 0,
      reorderPoint: 0,
      allowNegativeStock: false,
      serialNumbers: [],
      description,
      createdAt: new Date().toISOString(),
    };

    onAdd(product);
    setName('');
    setBrand('');
    setModel('');
    setBuyPrice('');
    setSellPrice('');
    setStock('1');
    setDescription('');
    setIsOpen(false);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-2xl p-4 flex items-center justify-center gap-3 shadow-lg shadow-emerald-500/20 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
      >
        <span className="text-2xl">📦</span>
        <span className="text-lg font-bold">افزودن محصول جدید</span>
      </button>
    );
  }

  return (
    <div className="bg-slate-800/80 backdrop-blur-lg rounded-2xl p-6 border border-slate-700/50 shadow-xl animate-fadeIn">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">افزودن محصول جدید</h3>
        <button
          onClick={() => setIsOpen(false)}
          className="text-slate-400 hover:text-white transition-colors w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-700"
        >
          ✕
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* دسته‌بندی */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">دسته‌بندی</label>
          <div className="grid grid-cols-3 gap-2">
            {productCategories.map(cat => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setCategory(cat.id as any)}
                className={`p-3 rounded-xl text-center transition-all ${
                  category === cat.id
                    ? 'bg-blue-600 text-white shadow-lg'
                    : 'bg-slate-700/50 text-slate-300 hover:bg-slate-600'
                }`}
              >
                <span className="text-2xl block">{cat.icon}</span>
                <span className="text-xs mt-1 block">{cat.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* نام محصول */}
        <div>
          <label className="block text-slate-300 text-sm mb-2">نام محصول</label>
          <input
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="مثلاً: آیفون ۱۵ پرو مکس"
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
            required
          />
        </div>

        {/* برند و مدل */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-slate-300 text-sm mb-2">برند</label>
            <input
              type="text"
              value={brand}
              onChange={e => setBrand(e.target.value)}
              placeholder="Apple"
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
              required
            />
          </div>
          <div>
            <label className="block text-slate-300 text-sm mb-2">مدل</label>
            <input
              type="text"
              value={model}
              onChange={e => setModel(e.target.value)}
              placeholder="Pro Max 256GB"
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
              required
            />
          </div>
        </div>

        {/* قیمت خرید و فروش */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-slate-300 text-sm mb-2">قیمت خرید (تومان)</label>
            <input
              type="number"
              value={buyPrice}
              onChange={e => setBuyPrice(e.target.value)}
              placeholder="۰"
              min="0"
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
              required
            />
          </div>
          <div>
            <label className="block text-slate-300 text-sm mb-2">قیمت فروش (تومان)</label>
            <input
              type="number"
              value={sellPrice}
              onChange={e => setSellPrice(e.target.value)}
              placeholder="۰"
              min="0"
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
              required
            />
          </div>
        </div>

        {/* تعداد و توضیحات */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-slate-300 text-sm mb-2">تعداد موجودی</label>
            <input
              type="number"
              value={stock}
              onChange={e => setStock(e.target.value)}
              min="0"
              className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-all"
              required
            />
          </div>
          <div>
            <label className="block text-slate-300 text-sm mb-2">سود (%)</label>
            <div className="bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-emerald-400 font-bold">
              {buyPrice && sellPrice ? Math.round(((Number(sellPrice) - Number(buyPrice)) / Number(buyPrice)) * 100) : 0}%
            </div>
          </div>
        </div>

        <div>
          <label className="block text-slate-300 text-sm mb-2">توضیحات (اختیاری)</label>
          <textarea
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="مشخصات بیشتر..."
            rows={2}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all resize-none"
          />
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-emerald-600 to-teal-700 py-3 rounded-xl font-bold text-white shadow-lg shadow-emerald-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all"
        >
          ✓ افزودن محصول
        </button>
      </form>
    </div>
  );
}
